<?php echo $this->view_template( 'common/reset-button-template.php' );
