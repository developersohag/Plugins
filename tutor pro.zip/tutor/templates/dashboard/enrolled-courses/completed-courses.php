<?php
/**
 * Completed Courses Template
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\Enrolled_Courses
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

$active_tab = 'enrolled-courses/completed-courses';
require dirname( __DIR__ ) . DIRECTORY_SEPARATOR . 'enrolled-courses.php';

