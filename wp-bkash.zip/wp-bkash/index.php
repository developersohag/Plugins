<?php 

	die('Permission not granted');