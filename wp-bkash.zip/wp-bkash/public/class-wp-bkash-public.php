<?php

class Wp_Bkash_Public extends WC_Payment_Gateway{

	private $plugin_name;

	private $version;

	public function __construct($plugin_name='',$version='') {
		if (!isValid()) {
			return;
		} 

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	    $this->id                 = 'wp_bkash'; 
	    $this->icon               = plugins_url("wp-bkash/admin/images/bkash.png"); 
	    $this->has_fields         = false; 
	    $this->method_title       = 'WP Bkash'; 
        $this->method_description = __('Receive payment by WP Bkash','wp_bkash');

	    $this->init_form_fields();
	    $this->init_settings();

	    $this->title       = $this->get_option( 'title' );
	    $this->description = $this->get_option( 'description' );

	    $this->enabled = $this->get_option( 'enabled' );
        

	    add_filter( 'woocommerce_payment_gateways', array( $this, 'add_wp_bkash_gateway' ) );
	    add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	    add_action( 'wp_ajax_wp-bkash-execute-payment-request', [$this,'execute_payment_request'] );
	    add_action( 'wp_ajax_nopriv_wp-bkash-execute-payment-request', [$this,'execute_payment_request'] );
		add_action( 'wp_bkash_execute_payment_success', [ $this, 'after_execute_payment' ], 10, 2 );

	}
	public function after_execute_payment( $order, $execute_payment ) {

		if ( ! $order instanceof \WC_Order ) {
			$order = wc_get_order( $order );
		}
		
		try {
			$payment_id        = sanitize_text_field( $execute_payment['paymentId'] );
			$order_grand_total = (float) $order->get_total();

			$insert_data = [
				'order_id'            => $order->get_id(),
				'payment_id'          => isset( $execute_payment['customerPhoneNumber'] ) ? $execute_payment['customerPhoneNumber'] : $payment_id,
				'trx_id'              => isset( $execute_payment['trxId'] ) ? $execute_payment['trxId'] : '',
				'status'              => isset( $execute_payment['transactionStatus'] ) ? $execute_payment['transactionStatus'] : 'Completed',
				'invoice_id'          => $execute_payment['invoiceNumber'],
				'amount'              => isset( $execute_payment['amount'] ) ? floatval( $execute_payment['amount'] ) : $order_grand_total,
			];
			$this->wp_bkash_insert_transaction( $insert_data );

			if ( (float) $execute_payment['amount'] >= $order_grand_total ) {
				$order_note_text = sprintf(
					/* translators: %1$s: Transaction ID, %2$s: Grand Total. */
					__( 'bKash payment completed. Transaction ID #%1$s. Amount: %2$s', 'wp-bkash' ),
					$execute_payment['trxId'],
					$order_grand_total
				);

				$order->add_order_note( $order_note_text );

				if ( $order->get_parent_id() ) {
					$parent_order = wc_get_order( $order->get_parent_id() );

					if ( $parent_order instanceof \WC_Order ) {
						$parent_order->add_order_note( $order_note_text );
					}
				}

				if ($this->get_option('is_digital') === 'yes') {
					$order->update_status('completed', __("Payment was successfully completed. Payment Method: {Bkash}, Amount: {$execute_payment['amount']}, Transaction ID: {$execute_payment['trxId']}, Sender Number: {$execute_payment['customerPhoneNumber']}", 'wp-bkash'));
					// Reduce stock levels
					wc_maybe_reduce_stock_levels($order->get_parent_id());
					$order->payment_complete();
				} else {
					$order->update_status('processing', __("Payment was successfully processed. Payment Method: {Bkash}, Amount: {$execute_payment['amount']}, Transaction ID: {$execute_payment['trxId']}, Sender Number: {$execute_payment['customerPhoneNumber']}", 'wp-bkash'));
					// Reduce stock levels
					wc_maybe_reduce_stock_levels($order->get_parent_id());

					$order->payment_complete();
				}

			} else {
				$order->update_status(
					'on-hold',
					sprintf(
						/* translators: %1$s: Transaction ID, %2$s: Payment Amount. */
						__( 'Partial payment. Transaction ID #%1$s! Amount: %2$s', 'dc-bkash' ),
						$execute_payment['trxId'],
						$execute_payment['amount']
					)
				);
			}

		} catch ( \Exception $e ) {
			error_log( 'wp_bkash_after_execute_payment ' . print_r( $e->getMessage() ) ); //phpcs:ignore
		}
	}
	public function wp_bkash_insert_transaction( $data ) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'bkash_transactions';

		$data = apply_filters( 'wp_bkash_before_insert_transaction', $data );

		$insert = $wpdb->insert(
			$table_name,
			[
				'order_id'            => sanitize_text_field( $data['order_id'] ),
				'payment_id'          => sanitize_text_field( $data['payment_id'] ),
				'trx_id'              => sanitize_text_field( $data['trx_id'] ),
				'status'              => sanitize_text_field( $data['status'] ),
				'invoice_id'          => sanitize_text_field( $data['invoice_id'] ),
				'amount'              => sanitize_text_field( $data['amount'] ),
				'currency'            => 'BDT',
				'datetime'            => current_time('mysql',1)
			]
		);

		if ( is_wp_error( $insert ) ) {
			return $insert;
		}

		return $insert;
	}
	
	public function execute_payment( $payment_id ,$transactionId) {
		
		$data = [];

		$data = [ 'transactionId' => $transactionId ];

		return $this->wo_execute_payment_request( $payment_id, $data );
	}
	public function wo_execute_payment_request( $payment_id, $data = [] ) {
		$headers = [
	            'Content-Type' => 'application/json',
	        ];
		$response = $this->make_request( "https://cpp.bka.sh/customer-portal-middleware/execute-payment", $data, $headers );
		
		return $response;
	}
	public function execute_payment_request() { 
		
		try {
			$post_data = wp_unslash( $_POST );

			if ( ! wp_verify_nonce( $post_data['_nonce'], 'wp-bkash-nonce' ) ) {
				$this->send_json_error( __( 'Something went wrong here!', 'wp-bkash' ) );
			}

			if ( ! $this->validate_fields( $post_data ) ) {
				$this->send_json_error( __( 'Empty value is not allowed', 'wp-bkash' ) );
			}

			$payment_id   = ( isset( $post_data['payment_id'] ) ) ? sanitize_text_field( $post_data['payment_id'] ) : '';
			$order_number = ( isset( $post_data['order_number'] ) ) ? sanitize_text_field( $post_data['order_number'] ) : '';
			$transactionId = ( isset( $post_data['transactionId'] ) ) ? sanitize_text_field( $post_data['transactionId'] ) : '';

			$order = wc_get_order( $order_number );

			if ( ! is_object( $order ) ) {
				$this->send_json_error( __( 'Wrong or invalid order ID', 'wp-bkash' ) );
			}

			$execute_payment = $this->execute_payment( $payment_id, $transactionId);

			if ( isset($execute_payment) ) {

				do_action( 'wp_bkash_execute_payment_success', $order, $execute_payment );

				$execute_payment['order_success_url'] = $order->get_checkout_order_received_url();
				wp_send_json_success( $execute_payment );
			}

			
			wp_send_json_success( $execute_payment );


			$this->send_json_error( __( 'Something went wrong!', 'dc-bkash' ) );

		} catch ( \Exception $e ) {
			$this->send_json_error( $e->getMessage() );
		}
	}
	public function add_wp_bkash_gateway( $gateways ) {

	    $gateways[] = 'Wp_Bkash_Public';
	    add_action( 'wp_enqueue_scripts', [$this,'enqueue_scripts'] );


	    return $gateways;
	}
	public function send_json_error( $text ) {
		wp_send_json_error( $text );
		wp_die();
	}
	
	
	public function init_form_fields(){

        $this->form_fields = array(
            'enabled' => array(
                'title'       => 'Enable/Disable',
                'label'       => 'Enable WP Bkash',
                'type'        => 'checkbox',
                'description' => 'Enable WP Bkash Plugin',
                'default'     => 'no',
                'desc_tip'    => true,

            ),
            'is_digital' => array(
                'title'       => 'Enable/Disable Digital product',
                'label'       => 'Enable Digital product',
                'type'        => 'checkbox',
                'description' => 'Check to sell digital product',
                'default'     => 'no',
                'desc_tip'    => true,

            ),
            'title' => array(
                'title'       => 'Title',
                'type'        => 'text',
                'description' => 'This controls the title which the user sees during checkout.',
                'default'     => 'WP Bkash',
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => 'Description',
                'type'        => 'textarea',
                'description' => 'This controls the description which the user sees during checkout.',
                'default'     => 'Pay With WP Bkash',
                'desc_tip'    => true,
            ),
            'currency_rate' => array(
                'title'       => 'Enter USD Rate',
                'type'        => 'number',
                'description' => '',
                'default'     => '110',
                'desc_tip'    => true,
            ),
            
        );
    }
    public function enqueue_scripts() {
		if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) ) {
			return;
		}

		// if our payment gateway is disabled.
		if ( 'no' === $this->enabled ) {
			return;
		}

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-bkash-public.css', array(), $this->version, 'all' );

		$this->localize_scripts();
	}
    public function get_script() {
		$env    = 'pay';
		$suffix = '';

		$script = sprintf( 'https://scripts.%s.bka.sh/versions/1.2.0-beta/checkout/bKash-checkout%s.js', $env, $suffix );

		return $script;
	}

    public function localize_scripts() {
		global $woocommerce;

		$bkash_script_url = $this->get_script();

		$custom_logo_id = get_site_icon_url(); 
		if ($custom_logo_id) {
			$logo_url = $custom_logo_id;
		} else {
			$logo_url = "";
		}

		$data = [
			'orgName'          => get_bloginfo( 'name' ),
			'orgLogo'          => $logo_url,
			'amount'           => $woocommerce->cart->cart_contents_total,
			'nonce'            => wp_create_nonce( 'wp-bkash-nonce' ),
			'ajax_url'         => admin_url( 'admin-ajax.php' ),
			'script_url'       => $bkash_script_url,
			'merchant'         => $this->RemoveSpecialChar(get_option('wp_bkash_payment_link'))
		];
		wp_enqueue_script('sweetalert','//cdn.jsdelivr.net/npm/sweetalert2@10', array('jquery'), false,true);

		wp_enqueue_script('jquery-blockui-js', plugin_dir_url(__FILE__) . 'js/jquery.blockUI.min.js', array('jquery'),true, $this->version);
		wp_enqueue_script($this->plugin_name . '-frontend', plugin_dir_url(__FILE__) . 'js/wp-bkash-public.js', array('jquery'),true, $this->version);


		wp_localize_script( $this->plugin_name.'-frontend', 'wp_bkash', $data );
	}
    public function RemoveSpecialChar($str)
	{
	    $res = str_replace(array('https://shop.bkash.com/', '/paymentlink'), '', $str);
	    return $res;
	}



    //function to complete payment
    public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );


		$create_payment_data = $this->create_payment_request( $order );

		if ( is_wp_error( $create_payment_data ) ) {
			$create_payment_data = false;
		}

		return [
			'result'              => 'success',
			'order_number'        => $order_id,
			'amount'              => (float) $order->get_total(),
			'checkout_order_pay'  => $order->get_checkout_payment_url(),
			'redirect'            => $this->get_return_url( $order ),
			'create_payment_data' => $create_payment_data,
		];
	}
    public function create_payment_request(\WC_Order $order) {
	    try {
	        $amount = (float) $order->get_total();
	        $invoice_id = $order->get_order_number();

	        $data = [
	            'amount' => $amount,
	            'currency' => 'BDT',
	            'intent' => 'sale',
	            'merchantInvoiceNumber' => $invoice_id,
	        ];

	        $response = $this->create_payment($data);

	        if (is_wp_error($response)) {
	            return $response;
	        }

	        return $response;
	    } catch (\Exception $e) {
	        return new \WP_Error('wp_bkash_create_payment_error', $e);
	    }
	}

	public function create_payment($data) {
	    try {
	        $url = "https://checkout.pay.bka.sh/1.2.0-beta/checkout/payment/create"; 
	        $headers = [
	            'Content-Type' => 'application/json',
	        ];

	        $response = $this->make_request($url, $data, $headers);

	        return $response;
	    } catch (\Exception $e) {
	        return new \WP_Error('wp_bkash_create_payment_error', $e);
	    }
	}

	public function make_request($url, $data, $headers = []) {

	    $args = [
	        'body'        => wp_json_encode($data),
	        'timeout'     => '30',
	        'redirection' => '30',
	        'httpversion' => '1.0',
	        'blocking'    => true,
	        'headers'     => $headers,
	        'cookies'     => [],
	    ];

	    $response = wp_remote_post(esc_url_raw($url), $args);

	    if (is_wp_error($response)) {
	        return $response;
	    }

	    $body = wp_remote_retrieve_body($response);

	    return json_decode($body, true);
	}

    
    // function end

}
