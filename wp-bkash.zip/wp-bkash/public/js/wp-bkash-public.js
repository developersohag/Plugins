(function ($, window, document) {
  var script_loaded = false;
  var loader;

  const wp_bkash = window.wp_bkash;

  const wp_bkash_payment = {
    checkout_form: $("form.checkout, form#order_review"),
    is_bkash_selected: function () {
      return (
        "wp_bkash" ===
        $(".woocommerce-checkout")
          .find('input[name="payment_method"]:checked')
          .val()
      );
    },
    set_loading_on: function () {
      wp_bkash_payment.checkout_form.addClass("processing").block({
        message: null,
        overlayCSS: {
          background: "#fff",
          opacity: 0.6,
        },
      });
    },
    set_loading_done: function () {
      wp_bkash_payment.checkout_form.removeClass("processing").unblock();
    },
    submit_error: function (errorMessage) {
      wp_bkash_payment.set_loading_done();
      loader.style.display = "none";

      $(
        ".woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-message"
      ).remove();

      wp_bkash_payment.checkout_form.prepend(
        '<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">' +
          errorMessage +
          "</div>"
      );

      wp_bkash_payment.checkout_form.removeClass("processing");
      wp_bkash_payment.checkout_form
        .find(".input-text, select, input:checkbox")
        .trigger("validate")
        .blur();

      wp_bkash_payment.scroll_to_notice();
      $(document.body).trigger("checkout_error");
    },
    scroll_to_notice: function () {
      $("html, body").animate(
        {
          scrollTop: $("form.checkout, form#order_review").offset().top - 100,
        },
        1000
      );
    },
    set_order: function (urlPath = wc_checkout_params.checkout_url) {
      $.ajax({
        type: "POST",
        url: urlPath,
        data: wp_bkash_payment.checkout_form.serialize(),
        dataType: "json",
      })
        .done(function (result) {
          try {
            if ("success" === result.result || result.success) {
              if ("object" === typeof result.data) {
                result = result.data;
              }

              if (!result.create_payment_data) {
                throw new Error("cannot make payment");
              }

              wp_bkash_payment.init_bkash(
                result.order_number,
                result.amount,
                result.create_payment_data
              );

              return;
            } else if ("failure" === result.result) {
              throw new Error("Result failure");
            } else {
              throw new Error("Invalid response");
            }
          } catch (err) {
            // Reload page
            if (true === result.reload) {
              window.location.reload();
              return;
            }

            // Trigger update in case we need a fresh nonce
            if (true === result.refresh) {
              $(document.body).trigger("update_checkout");
            }

            // Add new errors
            if (result.messages) {
              wp_bkash_payment.submit_error(result.messages);
            } else {
              wp_bkash_payment.submit_error(
                '<div class="woocommerce-error">' +
                  wc_checkout_params.i18n_checkout_error +
                  "</div>"
              );
            }
          }
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
          wp_bkash_payment.submit_error(
            '<div class="woocommerce-error">' + errorThrown + "</div>"
          );
        });
    },
    do_submit: function () {
      wp_bkash_payment.set_loading_on();
      let set_order;

      if ($(document.body).hasClass("woocommerce-order-pay")) {
        wp_bkash_payment.set_order(wp_bkash.ajax_url);
      } else {
        wp_bkash_payment.set_order();
      }
    },
    load_bkash_script: function () {
      if (!script_loaded) {
        //create loader for bKash
        wp_bkash_payment.create_bkash_loader();

        loader.style.display = "block";
        window.$ = $.noConflict(true);

        //fetching script
        $.getScript(wp_bkash.script_url, function () {
          loader.style.display = "none";
          wp_bkash_payment.create_wp_bkash_button();
          script_loaded = true;
        });
      }
    },
    create_bkash_loader: function () {
      var elem = document.createElement("div");
      elem.className = "wp-bkash-loader";
      elem.id = "wp-bkash-loader";
      document.body.appendChild(elem);
      loader = document.getElementById("wp-bkash-loader");
    },
    create_wp_bkash_button: function () {
      var bkashBtn = document.createElement("button");
      bkashBtn.id = "bKash_button";
      bkashBtn.className = "btn btn-danger";
      bkashBtn.setAttribute("disabled", "disabled");
      bkashBtn.style.display = "none";
      document.body.appendChild(bkashBtn);
    },
    execute_bkash_request: function (order_number, payment_id, transactionId) {
      let execute_payment_data = {
        payment_id: payment_id,
        order_number: order_number,
        transactionId: transactionId,
        action: "wp-bkash-execute-payment-request",
        _nonce: wp_bkash.nonce,
      };

      $.ajax({
        url: wp_bkash.ajax_url,
        method: "POST",
        data: execute_payment_data,
        success: function (response) {
          if (null != response.data.customerPhoneNumber) {
            let data = response.data;
            window.location.href = data.order_success_url;
          } else {
            bKash.execute().onError(); //run clean up code
            wp_bkash_payment.show_alert(
              "Payment Failed...!",
              response.data.errorMessage
            );
          }
        },
        error: function () {
          bKash.execute().onError(); // Run clean up code

          wp_bkash_payment.show_alert(
            "Payment Failed!",
            "Something went wrong!"
          );
        },
      });
    },

    init_bkash: function (order_number, amount, create_payment = false) {
      loader.style.display = "block";

      let payment_request = {
        intent: "sale",
        basePath: wp_bkash.merchant,
        urlFragment: "paymentlink",
        trxType: "AMOUNT",
        amount: amount,
        price: amount,
        packageName: "Customer Provided Amount",
        quantity: 0,
        customerName: "BKASH",
        customerPhoneNumber: "",
        customerEmail: "",
        customerReference: order_number,
        customerAddress: "",
        customerMembershipId: "",
        customerBillMonth: "",
        useWalletAsContact: true,
        references: [],
      };

      bKash.init({
        paymentMode: "checkout",
        paymentRequest: payment_request,
        createRequest: function (request) {
          payment_id = create_payment.paymentID;

          $.ajax({
            url: "https://cpp.bka.sh/customer-portal-middleware/create-payment",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(payment_request),
            success: function (data) {
              if (data && data.paymentID != null) {
                data.orgName = wp_bkash.orgName;
                if(wp_bkash.orgLogo){
                  data.orgLogo = wp_bkash.orgLogo;
                }
                paymentID = data.paymentID;
                transactionId = data.transactionId;
                bKash.create().onSuccess(data);
              } else {
                bKash.create().onError();
              }
            },
            error: function () {
              bKash.create().onError();
            },
          });
        },
        executeRequestOnAuthorization: function () {
          wp_bkash_payment.execute_bkash_request(
            order_number,
            payment_id,
            transactionId
          );
        },
        onClose: function () {
          loader.style.display = "none";

          wp_bkash_payment.show_alert("Opps...", "Payment Cancelled!");
        },
      });

      bKash.reconfigure({
        paymentRequest: payment_request,
      });

      $("#bKash_button").removeAttr("disabled");
      $("#bKash_button").click();
    },
    show_alert: function (title, text) {
      Swal.fire({
        icon: "error",
        title: title,
        text: text,
        confirmButtonText: "OK",
      }).then((result) => {
        loader.style.display = "none";
        $(wp_bkash_payment.checkout_form).removeClass("processing").unblock();
      });
    },
    init: function () {
      if (wp_bkash_payment.is_bkash_selected()) {
        wp_bkash_payment.load_bkash_script();
      }

      //on change load payment script
      wp_bkash_payment.checkout_form.on(
        "change",
        'input[name="payment_method"]',
        function (e) {
          $("body").trigger("update_checkout");

          if (wp_bkash_payment.is_bkash_selected()) {
            wp_bkash_payment.load_bkash_script();
          }
        }
      );

      wp_bkash_payment.checkout_form.on("click", "#place_order", function (e) {
        if (wp_bkash_payment.is_bkash_selected()) {
          e.preventDefault();

          wp_bkash_payment.do_submit();
        }
      });
    },
  };

  wp_bkash_payment.init();
})(jQuery, window, document);
