<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.youtube.com/@ITASSIST360
 * @since      1.0.0
 *
 * @package    Wp_Bkash
 * @subpackage Wp_Bkash/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wp_Bkash
 * @subpackage Wp_Bkash/includes
 * @author     IT ASSIST 360 <info@bkash.shopofbd.com>
 */
class Wp_Bkash_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
