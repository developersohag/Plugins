(function ($) {
    'use strict';

    $(document).ready(function () {
        $('#myTable').DataTable({
        	responsive: true,
        });
        
    });

})(jQuery);
