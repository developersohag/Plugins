<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://github.com/mehedibuet11
 * @since      1.0.0
 *
 * @package    Wp_Bkash
 * @subpackage Wp_Bkash/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wp_Bkash
 * @subpackage Wp_Bkash/admin
 * @author     IT ASSIST 360 <info@bkash.shopofbd.com>
 */
class Wp_Bkash_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}



	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		$allowed = array('wp-bkash-transactions','wp-bkash');
		if (isset($_GET['page']) && in_array($_GET['page'],$allowed)) {
			wp_enqueue_style( $this->plugin_name.'-stle', plugin_dir_url( __FILE__ ) . 'css/bkash-style.css', array(), $this->version, 'all' );
			wp_enqueue_style( $this->plugin_name.'-datatable', plugin_dir_url( __FILE__ ) . 'css/datatables.min.css', array(), $this->version, 'all' );
		}

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-bkash-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		$allowed = array('wp-bkash-transactions','wp-bkash');
		if (isset($_GET['page']) && in_array($_GET['page'],$allowed)) {
			wp_enqueue_script( $this->plugin_name.'-datatable', plugin_dir_url( __FILE__ ) . 'js/datatables.min.js', array( 'jquery' ), $this->version, false );
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-bkash-admin.js', array( 'jquery' ), $this->version, false );
		}


	}

	public function bkash_admin_menu()
	{

		add_menu_page( 'WP Bkash', 'WP Bkash', 'manage_options', 'wp-bkash', array($this, 'bkash_menu'),plugin_dir_url( __FILE__ ) . 'images/bkash-logo.png' );
		add_submenu_page( 'wp-bkash', 'Bkash Settings', 'Bkash Settings', 'manage_options', 'wp-bkash',  array($this,'bkash_menu'));
		add_submenu_page( 'wp-bkash', 'Bkash Transactions', 'Bkash Transactions', 'manage_options', 'wp-bkash-transactions',  array($this,'bkash_transactions'));
	}

	public function wp_bkash_settings_init()
	{
		add_settings_section(
			'bkash_setting_first_section',
			'Setup Your WP Bkash', null,
			'wp-bkash'
		);
		// payment link
		register_setting('wp_bkash_settings', 'wp_bkash_payment_link',array('sanitize_callback'=>'sanitize_text_field'));		
		add_settings_field(
			'wp_bkash_payment_link',
			'Bkash Payment Link', array($this,'payment_link_html'),
			'wp-bkash',
			'bkash_setting_first_section'
		);
		// license
		register_setting('wp_bkash_settings', 'wp_bkash_license',array('sanitize_callback'=>'sanitize_text_field'));		
		add_settings_field(
			'wp_bkash_license',
			'License ', array($this,'license_html'),
			'wp-bkash',
			'bkash_setting_first_section'
		);
	}
	public function license_html()
	{
		$wp_bkash_license = get_option('wp_bkash_license');
        ?>
        <input  type="password" size="50" name='wp_bkash_license' value="<?php echo esc_attr($wp_bkash_license); ?>" required>
        <?php
	}
	public function payment_link_html() {
        $payment_link = get_option('wp_bkash_payment_link');
        ?>
        <input type="text" size="50" name='wp_bkash_payment_link' value="<?php echo esc_attr($payment_link); ?>" required>
        <?php
    }


    public function license_check()
    {
    	
    	if (isValid()) {
    		?>
    		<div class="wp-bkash-activate">License Activated 
	    		<span class="dashicons dashicons-yes-alt"></span>
	    	</div>
	    	<?php 
    	}else{
    		?>
    		<div class="wp-bkash-deactivate">License Not Activated 
	    		<span class="dashicons dashicons-no-alt"></span>
	    	</div>
        	<a href="<?=BASE_SITE?>">Get License from: <?=BASE_SITE?></a>
	    	<?php
    	}
    }

	public function bkash_menu()
	{
		?>
    <div class="wrap">
    	<?php $this->license_check(); ?>
    	

        <form method="POST" action="options.php">
            <?php
            settings_fields('wp_bkash_settings');
            
            do_settings_sections('wp-bkash');

            submit_button('Save Settings');
            ?>
        </form>
    </div>

		<?php
	}
	private function fetch_data($table_name, $condition = null, $return_type = OBJECT)
	{
	    global $wpdb;

	    $full_table_name = $wpdb->prefix . $table_name;

	    $query = "SELECT * FROM $full_table_name";

	    if ($condition) {
	        $query .= " WHERE $condition";
	    }

	    $results = $wpdb->get_results($query, $return_type);

	    return $results;
	}
	public function bkash_transactions()
	{
		$items = $this->fetch_data('bkash_transactions');

		ob_start();
		require_once plugin_dir_path( __FILE__ ) . 'partials/wp-bkash-admin-display.php';
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}

}
