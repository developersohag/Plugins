<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.youtube.com/@ITASSIST360
 * @since             1.0.0
 * @package           Wp_Bkash
 *
 * @wordpress-plugin
 * Plugin Name:       Bkash POP UP Payment Gateway for WooCommerce
 * Plugin URI:        https://bkash.shopofbd.com
 * Description:       It helps to Complete Wocommerce Payment using Bkash Payment Link which you will find in your Bkash Business Dashboard.
 * Version:           1.0.0
 * Author:            IT ASSIST 360
 * Author URI:        https://www.youtube.com/@ITASSIST360
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wp-bkash
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WP_BKASH_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wp-bkash-activator.php
 */
function activate_wp_bkash() {
	if (is_ionCube_compatible()) {
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-bkash-activator.php';
		Wp_Bkash_Activator::activate();
	}
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wp-bkash-deactivator.php
 */
function deactivate_wp_bkash() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-bkash-deactivator.php';
	Wp_Bkash_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wp_bkash' );
register_deactivation_hook( __FILE__, 'deactivate_wp_bkash' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wp-bkash.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
//admin notices
add_action('admin_notices', 'wpbkash_check_requirements');
function wpbkash_check_requirements()
{
	if (!is_ioncube_available()) {
		$message = 'ionCube Loader function is missing! This plugin requires ionCube Loader function to run. Please check and enable the extension or contact your hosting provider.';
		echo '<div class="error"><p>' . esc_html($message) . '</p></div>';
	}
	if (!is_ionCube_compatible()) {
		$current_version = get_ioncube_loader_version();
		$message = "Current ionCube Loader version is {$current_version}! The minimum required version for this Plugin is 12.0.0. Please check and upgrade your ionCube Loader version or contact your hosting provider.";
		echo '<div class="error"><p>' . esc_html($message) . '</p></div>';
	}
}
function is_ioncube_available()
{
	return function_exists('ioncube_loader_version');
}
function is_ionCube_compatible()
{
	if (version_compare(get_ioncube_loader_version(), '10.0.0') < 0) {
		return false;
	}
	return true;
}
function get_ioncube_loader_version()
{
	if (function_exists('ioncube_loader_version')) {
		$version = ioncube_loader_version();
		$a = explode('.', $version);
		$count = count($a);
		if ($count == 3) {
			return $version;
		} elseif ($count == 2) {
			return $version . ".0";
		} elseif ($count == 1) {
			return $version . ".0.0";
		}
		$version = implode('.', array_slice($a, 0, 3));
		return $version;
	}
	return 'Not Found!';
}
if (is_ionCube_compatible()) {
	add_filter('plugin_action_links_' . plugin_basename(__FILE__),  'settings_link', 10, 2);
}

function settings_link($links_array, $plugin_file_name)
{

	if (!is_woocommerce_exists()) {
		array_unshift($links_array, '<a href="' . esc_url(admin_url('plugin-install.php?tab=plugin-information&plugin=woocommerce')) . '">' . __('Please activate woocommerce first', 'wp-bkash') . '</a>');		
	}else{
		if (strpos($plugin_file_name, basename(__FILE__))) {
			array_unshift($links_array, '<a href="' . esc_url(admin_url('admin.php?page=wp-bkash')) . '">' . __('Settings', 'wp-bkash') . '</a>');

			$links_array[] = sprintf(
				'<a href="%s">%s</a>',
				admin_url('admin.php?page=wc-settings&tab=checkout&section=wp_bkash'),
				__('Woocommerce Settings', 'wp-bkash')
			);

			$links_array[] = sprintf(
				'<a href="%s" target="_blank">%s</a>',
				BASE_SITE,
				__('<b style="color:blue;font-weight:800">Get License</b>', 'upbkash')
			);
		}
	}

	return $links_array;
}

function is_woocommerce_exists()
{
	if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
		return true;
	}
	return false;
}
function run_wp_bkash() {
	$plugin = new Wp_Bkash();
	$plugin->run();
}
if (is_ionCube_compatible()) {
	run_wp_bkash();
}

