<?php
/* 
 * WP Circular Menu - Meta box Tab options
 */
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
wp_nonce_field('wpcm_save_settings','wpcm_meta_nonce');
$wpcm_settings = get_post_meta($post->ID,'_wpcm_settings');
$wpcm_specific_pages = get_post_meta($post->ID,'_wpcm_specific_pages');
/*$this->print_array($wpcm_settings);*/
/*Build Settings*/
$wpcm_select_menu = isset( $wpcm_settings[0]['wpcm_select_menu'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_menu'] ) : '';

/*Layout Settings*/
$wpcm_select_template = isset( $wpcm_settings[0]['wpcm_select_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_template'] ) : 'wpcm-template-1';
$wpcm_initial_top = isset( $wpcm_settings[0]['wpcm_initial_top'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_initial_top'] ) : '';
$wpcm_initial_left = isset( $wpcm_settings[0]['wpcm_initial_left'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_initial_left'] ) : '';

/*Since 1.0.3*/
$wpcm_keep_open = isset( $wpcm_settings[0]['wpcm_keep_open'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_keep_open'] ) : 0;
$wpcm_hide_toggle = isset( $wpcm_settings[0]['wpcm_hide_toggle'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_hide_toggle'] ) : 0;
$wpcm_menu_fixed = isset( $wpcm_settings[0]['wpcm_menu_fixed'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_fixed'] ) : 0;
$wpcm_disable_draggable = isset( $wpcm_settings[0]['wpcm_disable_draggable'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_disable_draggable'] ) : 0;
$wpcm_disable_responsive = isset( $wpcm_settings[0]['wpcm_disable_responsive'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_disable_responsive'] ) : 0;

$wpcm_position = isset( $wpcm_settings[0]['wpcm_position'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_position'] ) : 'wpcm-bottom-left';
/*Mapping Template 8 position to Template 9*/
if($wpcm_select_template == 'wpcm-template-9'){
	switch($wpcm_position){
		case 'wpcm-top-middle':
		$wpcm_position = 'wpcm-top-right';
		break;
		case 'wpcm-middle-left':
		$wpcm_position = 'wpcm-top-left';
		break;
		case 'wpcm-middle-right':
		$wpcm_position = 'wpcm-bottom-right';
		break;
		case 'wpcm-bottom-middle':
		$wpcm_position = 'wpcm-bottom-left';
		break;
	}
}

/*Mapping Template 9 position to Template 8*/
if($wpcm_select_template == 'wpcm-template-8'){
	switch($wpcm_position){
		case 'wpcm-top-right':
		$wpcm_position = 'wpcm-top-middle';
		break;
		case 'wpcm-top-left':
		$wpcm_position = 'wpcm-middle-left';
		break;
		case 'wpcm-bottom-right':
		$wpcm_position = 'wpcm-middle-right';
		break;
		case 'wpcm-bottom-left':
		$wpcm_position = 'wpcm-bottom-middle';
		break;
	}
}

$wpcm_select_animation = isset( $wpcm_settings[0]['wpcm_select_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_animation'] ) : 'wpcm-animation-1';

/*Toggle button settings*/
$wpcm_enable_custom_toggle = isset( $wpcm_settings[0]['wpcm_enable_custom_toggle'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_toggle'] ) : '0';  
$wpcm_toggle_icon_open_color = isset( $wpcm_settings[0]['wpcm_toggle_icon_open_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_icon_open_color'] ) : '';  
$wpcm_toggle_icon_close_color = isset( $wpcm_settings[0]['wpcm_toggle_icon_close_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_icon_close_color'] ) : ''; 
$wpcm_toggle_icon_hover_color = isset( $wpcm_settings[0]['wpcm_toggle_icon_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_icon_hover_color'] ) : ''; 

$wpcm_toggle_bg_open_color = isset( $wpcm_settings[0]['wpcm_toggle_bg_open_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_bg_open_color'] ) : ''; 
$wpcm_toggle_bg_close_color = isset( $wpcm_settings[0]['wpcm_toggle_bg_close_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_bg_close_color'] ) : ''; 
$wpcm_toggle_bg_hover_color = isset( $wpcm_settings[0]['wpcm_toggle_bg_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_bg_hover_color'] ) : ''; 

$wpcm_toggle_border_open_color = isset( $wpcm_settings[0]['wpcm_toggle_border_open_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_open_color'] ) : ''; 
$wpcm_toggle_border_close_color = isset( $wpcm_settings[0]['wpcm_toggle_border_close_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_close_color'] ) : ''; 
$wpcm_toggle_border_hover_color = isset( $wpcm_settings[0]['wpcm_toggle_border_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_hover_color'] ) : ''; 
$wpcm_toggle_border_size = isset( $wpcm_settings[0]['wpcm_toggle_border_size'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_size'] ) : ''; 
$wpcm_toggle_animation = isset( $wpcm_settings[0]['wpcm_toggle_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_animation'] ) : 'wpcm-toggle-animation-1';


/*Menu items*/
$wpcm_enable_custom_menu = isset( $wpcm_settings[0]['wpcm_enable_custom_menu'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_menu'] ) : '0';  
$wpcm_menu_item_icon_color = isset( $wpcm_settings[0]['wpcm_menu_item_icon_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_icon_color'] ) : '';  
$wpcm_menu_item_icon_active_color = isset( $wpcm_settings[0]['wpcm_menu_item_icon_active_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_icon_active_color'] ) : ''; 
$wpcm_menu_item_icon_hover_color = isset( $wpcm_settings[0]['wpcm_menu_item_icon_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_icon_hover_color'] ) : ''; 

$wpcm_menu_item_bg_color = isset( $wpcm_settings[0]['wpcm_menu_item_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_bg_color'] ) : ''; 
$wpcm_menu_item_bg_active_color = isset( $wpcm_settings[0]['wpcm_menu_item_bg_active_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_bg_active_color'] ) : ''; 
$wpcm_menu_item_bg_hover_color = isset( $wpcm_settings[0]['wpcm_menu_item_bg_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_bg_hover_color'] ) : ''; 

$wpcm_menu_item_border_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_color'] ) : ''; 
$wpcm_menu_item_border_active_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_active_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_active_color'] ) : ''; 
$wpcm_menu_item_border_hover_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_hover_color'] ) : '';

$wpcm_menu_center_image = isset( $wpcm_settings[0]['wpcm_menu_center_image'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_center_image'] ) : '';
$wpcm_menu_center_url = isset( $wpcm_settings[0]['wpcm_menu_center_url'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_center_url'] ) : '';
$wpcm_menu_bg_color = isset( $wpcm_settings[0]['wpcm_menu_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_bg_color'] ) : '';

$wpcm_menu_arrow_color = isset( $wpcm_settings[0]['wpcm_menu_arrow_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_arrow_color'] ) : '';
$wpcm_menu_arrow_hover_color = isset( $wpcm_settings[0]['wpcm_menu_arrow_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_arrow_hover_color'] ) : '';



/*Notification Label*/
$wpcm_enable_custom_notification = isset( $wpcm_settings[0]['wpcm_enable_custom_notification'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_notification'] ) : '0';  
$wpcm_label_color = isset( $wpcm_settings[0]['wpcm_label_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_color'] ) : ''; 
$wpcm_label_bg_color = isset( $wpcm_settings[0]['wpcm_label_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_bg_color'] ) : ''; 
$wpcm_label_animation = isset( $wpcm_settings[0]['wpcm_label_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_animation'] ) : ''; 
$wpcm_label_template = isset( $wpcm_settings[0]['wpcm_label_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_template'] ) : 'wpcm_label_template_1'; 

/*Tooltip*/
$wpcm_enable_custom_tooltip = isset( $wpcm_settings[0]['wpcm_enable_custom_tooltip'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_tooltip'] ) : '0';  
$wpcm_tooltip_color = isset( $wpcm_settings[0]['wpcm_tooltip_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_tooltip_color'] ) : ''; 
$wpcm_tooltip_bg_color = isset( $wpcm_settings[0]['wpcm_tooltip_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_tooltip_bg_color'] ) : ''; 

/*Text Settings*/
$wpcm_enable_custom_typo = isset( $wpcm_settings[0]['wpcm_enable_custom_typo'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_typo'] ) : '0'; 
$wpcm_font_family = isset( $wpcm_settings[0]['wpcm_font_family'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_font_family'] ) : ''; 
$wpcm_text_transform = isset( $wpcm_settings[0]['wpcm_text_transform'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_text_transform'] ) : ''; 


/*Display Settings*/
$wpcm_permission = isset( $wpcm_settings[0]['wpcm_permission'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_permission'] ) : 'wpcm_everyone';
$wpcm_checkbox_display = isset( $wpcm_settings[0]['wpcm_checkbox_display'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_checkbox_display'] ) : 'wpcm_hide_menu';
$wpcm_user_roles = isset( $wpcm_settings[0]['wpcm_user_roles'] ) ? $wpcm_settings[0]['wpcm_user_roles']  : array();


$wpcm_use_shortcode = isset( $wpcm_settings[0]['wpcm_use_shortcode'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_use_shortcode'] ) : '0';
$wpcm_front_pages = isset( $wpcm_settings[0]['wpcm_front_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_front_pages'] ) : '0';
$wpcm_blog_pages  = isset( $wpcm_settings[0]['wpcm_blog_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_blog_pages'] ) : '0';
$wpcm_archive_pages = isset( $wpcm_settings[0]['wpcm_archive_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_archive_pages'] ) : '0';
$wpcm_404_pages   = isset( $wpcm_settings[0]['wpcm_404_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_404_pages'] ) : '0';
$wpcm_search_pages = isset( $wpcm_settings[0]['wpcm_search_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_search_pages'] ) : '0';
$wpcm_single_pages = isset( $wpcm_settings[0]['wpcm_single_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_single_pages'] ) : '0';
$wpcm_custom_terms = isset( $wpcm_settings[0]['wpcm_custom_terms'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_custom_terms'] ) : '';

/*Custom CSS*/
$wpcm_enable_custom_css = isset( $wpcm_settings[0]['wpcm_enable_custom_css'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_css'] ) : '0';
$wpcm_custom_css = isset( $wpcm_settings[0]['wpcm_custom_css'] ) ? wp_kses_post( $wpcm_settings[0]['wpcm_custom_css'] ) : '';

for($i=1;$i<6;$i++){
	$wpcm_draggable_templates[] = 'wpcm-template-'.$i;	
}
/*$this->print_array($wpcm_draggable_templates);*/
/*Position Option*/
if(in_array($wpcm_select_template, $wpcm_draggable_templates)){
	$position_flag = '1';
}else{
	$position_flag = '0';
}

/*Text Option*/
if(!($wpcm_select_template == 'wpcm-template-8')){
	$wpcm_hide_text_option = '1';
}else{
	$wpcm_hide_text_option = '0';
}

/*Border Option*/
if(!($wpcm_select_template == 'wpcm-template-2' || $wpcm_select_template == 'wpcm-template-3' || $wpcm_select_template == 'wpcm-template-7' || $wpcm_select_template == 'wpcm-template-9')){
	$wpcm_hide_border_option = '1';
}else{
	$wpcm_hide_border_option = '0';
}

/*Center Image*/
if(!($wpcm_select_template == 'wpcm-template-1' || $wpcm_select_template == 'wpcm-template-4' || $wpcm_select_template == 'wpcm-template-8')){
	$wpcm_hide_center_image = '1';
}else{
	$wpcm_hide_center_image = '0';
}

/*Background Color*/
if(!($wpcm_select_template == 'wpcm-template-1' || $wpcm_select_template == 'wpcm-template-4' || $wpcm_select_template == 'wpcm-template-7' || $wpcm_select_template == 'wpcm-template-8')){
	$wpcm_hide_bg_color = '1';
}else{
	$wpcm_hide_bg_color = '0';
}

/*Icon Background Color*/
if($wpcm_select_template == 'wpcm-template-5'){
	$wpcm_hide_icon_bg_color = '1';
}else{
	$wpcm_hide_icon_bg_color = '0';
}
?>
<div class="wpcm-postbox-wrapper inside">
	<div class="wpcm-postbox-wrapper-inner">
		<ul class="nav-tab-wrapper">
			<li class="nav-tab nav-tab-active" data-tab="wpcm-tab-1"><img src="<?php echo WPCM_IMG_DIR; ?>/backend-menu-icons/wpcm-icon-1.png" alt="wpcm-icon-1"><?php _e( 'Select Menu', 'wp-circular-menu' ); ?></li>
			<li class="nav-tab" data-tab="wpcm-tab-2"><img src="<?php echo WPCM_IMG_DIR; ?>/backend-menu-icons/wpcm-icon-2.png" alt="wpcm-icon-3"><?php _e( 'Layout Settings', 'wp-circular-menu' ); ?></li>	
			<li class="nav-tab " data-tab="wpcm-tab-3"><img src="<?php echo WPCM_IMG_DIR; ?>/backend-menu-icons/wpcm-icon-3.png" alt="wpcm-icon-3"><?php _e( 'Display Settings', 'wp-circular-menu' ); ?></li>	
			<li class="nav-tab" data-tab="wpcm-tab-4"><img src="<?php echo WPCM_IMG_DIR; ?>/backend-menu-icons/wpcm-icon-4.png" alt="wpcm-icon-4"><?php _e( 'Custom CSS', 'wp-circular-menu' ); ?></li>			
		</ul>	
		<div id="wpcm-tab-1" class="wpcm-tab-content wpcm-current">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-build-settings.php'); ?>
		</div>
		<div id="wpcm-tab-2" class="wpcm-tab-content">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-layout-settings.php'); ?>	
		</div>
		<div id="wpcm-tab-3" class="wpcm-tab-content">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-display-settings.php'); ?>	
		</div>
		<div id="wpcm-tab-4" class="wpcm-tab-content">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-custom-css.php'); ?>	
		</div>
	</div>
</div>