<?php
/* WP Circular Menu -  Layout Settings*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-section">
	<div class="wpcm-postbox-fields">
		<label><?php _e('Select Template','wp-circular-menu');?></label>
		<select name="wpcm_select_template" class="wpcm_select_template">
			<?php
			for($i=1;$i<10;$i++){
				if($i==1){
					?>
					<optgroup label="<?php _e('Draggable Templates','wp-circular-menu');?>">

					<?php	
				}elseif($i==6){
					?>
					<optgroup label="<?php _e('Fixed Templates','wp-circular-menu');?>">
					
					<?php	
				}
				
			?>
			<option value="<?php esc_attr_e('wpcm-template-'.$i);?>" <?php if ( $wpcm_select_template ==  esc_attr('wpcm-template-'.$i)) _e( 'selected="selected"' ); ?>><?php esc_attr_e('Template '.$i);?></option>
			<?php
			}
			?>
		</select>
		
	</div>
	<div class="wpcm-initial-position-wrapper" <?php if(!$position_flag) {_e('style="display:none;"');}?>>
		<label><?php _e('Initial Position','wp-circular-menu')?></label>
		<div class="wpcm-info"><?php _e('Please enter the initial position for the menu to appear on load. Valid for Template 1 to Template 5','wp-circular-menu')?></div>
		<div class="wpcm-postbox-fields">
			<h2 for="wpcm_initial_top"><?php _e('Top','wp-circular-menu');?></h2>
			<input type="number" name="wpcm_initial_top" placeholder="50px" value="<?php esc_attr_e( $wpcm_initial_top); ?>"/>
		</div>
		<div class="wpcm-postbox-fields">
			<h2 for="wpcm_initial_left"><?php _e('Left','wp-circular-menu');?></h2>
			<input type="number" name="wpcm_initial_left" placeholder="50px" value="<?php esc_attr_e( $wpcm_initial_left); ?>"/>
		</div>
	</div>
	<div class="wpcm-initial-position-wrapper" <?php if(!$position_flag) {_e('style="display:none;"');}?>>
		<div class="wpcm-postbox-fields">
			<h2><?php _e( 'Keep open?', 'wp-circular-menu' ); ?></h2>
			<div class="wpcm-info"><?php _e( 'Menu is initially in open state', 'wp-circular-menu' ); ?></div>
			<div class="wpcm-slide-checkbox-wrapper">
				<div class="wpcm-slide-checkbox-wrapper-inner">
					<div class="wpcm-slide-checkbox">  
						<input type="checkbox" id="wpcm-keep-open" name="wpcm_keep_open" <?php if ( $wpcm_keep_open == 1) _e( 'checked="checked"' ); ?>>
						<label for="wpcm-keep-open"></label>
					</div>
				</div>
			</div>	
		</div>
		<div class="wpcm-postbox-fields">
			<h2><?php _e( 'Hide Toggle Button?', 'wp-circular-menu' ); ?></h2>
			<div class="wpcm-info"><?php _e( 'Hiding keeps menu initial state', 'wp-circular-menu' ); ?></div>
			<div class="wpcm-slide-checkbox-wrapper">
				<div class="wpcm-slide-checkbox-wrapper-inner">
					<div class="wpcm-slide-checkbox">  
						<input type="checkbox" id="wpcm-hide-toggle" name="wpcm_hide_toggle" <?php if ( $wpcm_hide_toggle == 1) _e( 'checked="checked"' ); ?>>
						<label for="wpcm-hide-toggle"></label>
					</div>
				</div>
			</div>	
		</div>
		<div class="wpcm-postbox-fields">
			<h2><?php _e( 'Fixed / Scroll?', 'wp-circular-menu' ); ?></h2>
			<div class="wpcm-info"><?php _e( 'Fixed in initial position / Scroll with page', 'wp-circular-menu' ); ?></div>
			<div class="wpcm-slide-checkbox-wrapper">
				<div class="wpcm-slide-checkbox-wrapper-inner">
					<div class="wpcm-slide-checkbox">  
						<input type="checkbox" id="wpcm-menu-fixed" name="wpcm_menu_fixed" <?php if ( $wpcm_menu_fixed == 1) _e( 'checked="checked"' ); ?>>
						<label for="wpcm-menu-fixed"></label>
					</div>
				</div>
			</div>	
		</div>
		<div class="wpcm-postbox-fields">
			<h2><?php _e( 'Disable Draggable?', 'wp-circular-menu' ); ?></h2>
			<div class="wpcm-info"><?php _e( 'Remove draggable feature', 'wp-circular-menu' ); ?></div>
			<div class="wpcm-slide-checkbox-wrapper">
				<div class="wpcm-slide-checkbox-wrapper-inner">
					<div class="wpcm-slide-checkbox">  
						<input type="checkbox" id="wpcm-disable-draggable" name="wpcm_disable_draggable" <?php if ( $wpcm_disable_draggable == 1) _e( 'checked="checked"' ); ?>>
						<label for="wpcm-disable-draggable"></label>
					</div>
				</div>
			</div>	
		</div>
	</div>
	<div class="wpcm-position-field-wrapper" <?php if($position_flag) {_e('style="display:none;"');}?>>
		<label><?php _e('Position','wp-circular-menu')?></label>
		<div class="wpcm-position-field-inner-wrapper">
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Top Left','wp-circular-menu');?>" id="wpcm-position-1" value="wpcm-top-left" <?php if ( $wpcm_position == "wpcm-top-left" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-8') esc_attr_e('disabled="disabled"');?>>
			<label for="wpcm-position-1"><?php _e('Top Left','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Top Middle','wp-circular-menu');?>" id="wpcm-position-2" value="wpcm-top-middle" <?php if ( $wpcm_position == "wpcm-top-middle" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-9') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-2"><?php _e('Top Middle','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Top Right','wp-circular-menu');?>" id="wpcm-position-3" value="wpcm-top-right" <?php if ( $wpcm_position == "wpcm-top-right" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-8') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-3"><?php _e('Top Right','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Middle Left','wp-circular-menu');?>" id="wpcm-position-4" value="wpcm-middle-left" <?php if ( $wpcm_position == "wpcm-middle-left" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-9') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-4"><?php _e('Middle Left','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Middle Middle','wp-circular-menu');?>" id="wpcm-position-5" disabled="disabled" value="wpcm-middle-middle" <?php if ( $wpcm_position == "wpcm-middle-middle" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-8') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-5"><?php _e('Middle Middle','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Middle Right','wp-circular-menu');?>" id="wpcm-position-6" value="wpcm-middle-right" <?php if ( $wpcm_position == "wpcm-middle-right" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-9') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-6"><?php _e('Middle Right','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Bottom Left','wp-circular-menu');?>" id="wpcm-position-7" value="wpcm-bottom-left" <?php if ( $wpcm_position == "wpcm-bottom-left" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-8') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-7"><?php _e('Bottom Left','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Bottom Middle','wp-circular-menu');?>" id="wpcm-position-8" value="wpcm-bottom-middle" <?php if ( $wpcm_position == "wpcm-bottom-middle" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-9') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-8"><?php _e('Bottom Middle','wp-circular-menu');?></label>
		</div>
		<div class="wpcm-position-fields">
			<input type="radio" name="wpcm_position" title="<?php _e('Bottom Right','wp-circular-menu');?>" id="wpcm-position-9" value="wpcm-bottom-right" <?php if ( $wpcm_position == "wpcm-bottom-right" ) _e('checked="checked"'); if($wpcm_select_template == 'wpcm-template-8') esc_attr_e('disabled="disabled"'); ?>>
			<label for="wpcm-position-9"><?php _e('Bottom Right','wp-circular-menu');?></label>
		</div>
		</div>
	</div>
	<div class="wpcm-postbox-fields">
		<label><?php _e('Animation','wp-circular-menu');?></label>
		<select name="wpcm_select_animation">
			<?php
			$animation_name = array(__('Slide','wp-circular-menu'),__('Zoom In','wp-circular-menu'),__('Fade In','wp-circular-menu'),__('Pulse','wp-circular-menu'));
			for($i=1;$i<5;$i++){
			?>
			<option value="<?php esc_attr_e('wpcm-animation-'.$i);?>" <?php if ( $wpcm_select_animation ==  esc_attr('wpcm-animation-'.$i)) _e( 'selected="selected"' ); ?>><?php _e($animation_name[$i-1]);?></option>
			<?php
			}
			?>
		</select>
	</div>
	<div class="wpcm-postbox-fields">
		<label><?php _e( 'Disable for small screen devices?', 'wp-circular-menu' ); ?></label>
		<div class="wpcm-info"><?php _e( 'Disable screen size 600px or less', 'wp-circular-menu' ); ?></div>
		<div class="wpcm-slide-checkbox-wrapper">
			<div class="wpcm-slide-checkbox-wrapper-inner">
				<div class="wpcm-slide-checkbox">  
					<input type="checkbox" id="wpcm-disable-responsive" name="wpcm_disable_responsive" <?php if ( $wpcm_disable_responsive == 1) _e( 'checked="checked"' ); ?>>
					<label for="wpcm-disable-responsive"></label>
				</div>
			</div>
		</div>	
	</div>
	<div class="wpcm-customize-wrapper">
		<ul class="wpcm-nav-tab-wrapper">
			<li class="wpcm-nav-tab wpcm-nav-tab-active" data-tab="wpcm-customizer-1" tabindex="0"><?php _e( 'Toggle Button', 'wp-circular-menu' ); ?></li>
			<li class="wpcm-nav-tab" data-tab="wpcm-customizer-2" tabindex="0"><?php _e( 'Menu item', 'wp-circular-menu' ); ?></li>
			<li class="wpcm-nav-tab" data-tab="wpcm-customizer-3" tabindex="0"><?php _e( 'Notification Label', 'wp-circular-menu' ); ?></li>
			<li class="wpcm-nav-tab" data-tab="wpcm-customizer-4" tabindex="0"><?php _e( 'Tooltip', 'wp-circular-menu' ); ?></li>
			<li class="wpcm-nav-tab" data-tab="wpcm-customizer-5" tabindex="0"><?php _e( 'Typography', 'wp-circular-menu' ); ?></li>
		</ul>
		<div id="wpcm-customizer-1" class="wpcm-customizer-content wpcm-current" tabindex="0">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-layouts/wpcm-button-settings.php'); ?>
		</div>
		<div id="wpcm-customizer-2" class="wpcm-customizer-content" tabindex="0">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-layouts/wpcm-menu-items-settings.php'); ?>
		</div>
		<div id="wpcm-customizer-3" class="wpcm-customizer-content" tabindex="0">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-layouts/wpcm-notification-label.php'); ?>
		</div>
		<div id="wpcm-customizer-4" class="wpcm-customizer-content" tabindex="0">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-layouts/wpcm-tooltip-settings.php'); ?>
		</div>
		<div id="wpcm-customizer-5" class="wpcm-customizer-content" tabindex="0">
			<?php include(WPCM_PATH . '/inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-tabs/wpcm-layouts/wpcm-text-settings.php'); ?>
		</div>
	</div>
</div>