<?php
/* WP Circular Menu - Toggle Button Settings */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-fields">
	<label><?php _e('Toggle Animation','wp-circular-menu');?></label>
	<select name="wpcm_toggle_animation" class="wpcm-toggle-animation">
		<?php
		$togle_animations=array(__('Default','wp-circular-menu'),__('Magnet','wp-circular-menu'),__('Expand','wp-circular-menu'),__('Stand','wp-circular-menu'),__('Emphatic','wp-circular-menu'));
		for($i=1;$i<6;$i++){
			?>
			<option value="<?php esc_attr_e('wpcm-toggle-animation-'.$i);?>" <?php if ( $wpcm_toggle_animation ==  esc_attr('wpcm-toggle-animation-'.$i)) _e( 'selected="selected"' ); ?>><?php esc_attr_e($togle_animations[$i-1]);?></option>
			<?php
		}
		?>
	</select>
	<div class="wpcm-toggle-preview">
		<img src="<?php esc_attr_e(WPCM_IMG_DIR.'/toggle-animation/'.$wpcm_toggle_animation.'.gif');?>"/>
	</div>
</div>

<div class="wpcm-postbox-fields">
	<label><?php _e( 'Customize?', 'wp-circular-menu' ); ?></label>
	<div class="wpcm-info"><?php _e( 'Check to customize toggle settings', 'wp-circular-menu' ); ?></div>
	<div class="wpcm-slide-checkbox-wrapper">
		<div class="wpcm-slide-checkbox-wrapper-inner">
			<div class="wpcm-slide-checkbox">  
				<input type="checkbox" id="wpcm-enable-custom-toggle" name="wpcm_enable_custom_toggle" <?php if ( $wpcm_enable_custom_toggle == 1) _e( 'checked="checked"' ); ?>>
				<label for="wpcm-enable-custom-css"></label>
			</div>
		</div>
	</div>
</div>

<div class="wpcm-postbox-field-wrapper" <?php if (!( $wpcm_enable_custom_toggle == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Icon Color', 'wp-circular-menu' );?></label>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Open', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_icon_open_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_icon_open_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Close', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_icon_close_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_icon_close_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Hover', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_icon_hover_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_icon_hover_color); ?>">
	</div>
</div>
<div class="wpcm-postbox-field-wrapper" <?php if (!( $wpcm_enable_custom_toggle == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Background', 'wp-circular-menu' );?></label>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Open', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_bg_open_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_bg_open_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Close', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_bg_close_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_bg_close_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Hover', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_bg_hover_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_bg_hover_color); ?>">
	</div>
</div>
<div class="wpcm-postbox-field-wrapper" <?php if (!( $wpcm_enable_custom_toggle == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Border', 'wp-circular-menu' );?></label>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Open', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_border_open_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_border_open_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Close', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_border_close_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_border_close_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Hover', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_toggle_border_hover_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_toggle_border_hover_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Border width', 'wp-circular-menu' ); ?></h2>
		<input type="number" name="wpcm_toggle_border_size" value="<?php esc_attr_e( $wpcm_toggle_border_size); ?>">
	</div>
</div> 

