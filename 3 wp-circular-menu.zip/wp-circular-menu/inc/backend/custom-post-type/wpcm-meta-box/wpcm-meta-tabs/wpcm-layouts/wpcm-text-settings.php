<?php
/* WP Circular Menu - Text Settings */
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

$font_array = get_option('wpcm_font_list');
/*echo '$wpcm_font_family : '.$wpcm_font_family ;*/
?>
<div class="wpcm-postbox-fields">
	<label><?php _e( 'Customize?', 'wp-circular-menu' ); ?></label>
	<div class="wpcm-info"><?php _e( 'Check to customize Font settings', 'wp-circular-menu' ); ?></div>
	<div class="wpcm-slide-checkbox-wrapper">
		<div class="wpcm-slide-checkbox-wrapper-inner">
			<div class="wpcm-slide-checkbox">  
				<input type="checkbox" id="wpcm-enable-custom-typo" name="wpcm_enable_custom_typo" <?php if ( $wpcm_enable_custom_typo == 1) _e( 'checked="checked"' ); ?>>
				<label for="wpcm-enable-custom-typo"></label>
			</div>
		</div>
	</div>
</div>
<div class="wpcm-postbox-fields" <?php if (!( $wpcm_enable_custom_typo == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Font Family', 'wp-circular-menu' ); ?></label>
	<select class="wpcm-typography-selected" name="wpcm_font_family">
		<?php
		if(!empty($font_array)){
			foreach ( $font_array as $wpcm_font ) {
				$wpcm_separated = explode('=',$wpcm_font);
				$wpcm_family = $wpcm_separated[0];
				$wpcm_subset = $wpcm_separated[1];
				$wpcm_variant = $wpcm_separated[2];

				?>
				<option value="<?php _e( $wpcm_font ); ?>" <?php if ( $wpcm_font_family == $wpcm_font ) _e( 'selected' ); ?>><?php _e( $wpcm_family.' '.$wpcm_subset.' '.$wpcm_variant); ?></option>
				<?php
			}
		}
		?>
	</select> 
</div>
<div class="wpcm-postbox-fields" <?php if (!( $wpcm_enable_custom_typo == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Text Transform', 'wp-circular-menu' ); ?></label>
	<select class="wpcm-text-transform" name="wpcm_text_transform">
		<option value="none" <?php if ( $wpcm_text_transform == 'none' ) _e( 'selected' ); ?>><?php _e('
			None', 'wp-circular-menu');?></option>
		 <option value="capitalize" <?php if ( $wpcm_text_transform == 'capitalize' ) _e( 'selected' ); ?>><?php _e('
		 	Capitalize', 'wp-circular-menu');?></option>
		 <option value="uppercase" <?php if ( $wpcm_text_transform == 'uppercase' ) _e( 'selected' ); ?>><?php _e('
		 	UPPERCASE', 'wp-circular-menu');?></option>
		 <option value="lowercase" <?php if ( $wpcm_text_transform == 'lowercase' ) _e( 'selected' ); ?>><?php _e('
		 	lowercase', 'wp-circular-menu');?></option>
	</select> 
</div>
<div class="wpcm-typography-preview wpcm-postbox-fields" <?php if (!( $wpcm_enable_custom_typo == 1)) echo 'style="display:none;"'; ?>></div>

