<?php
/* WP Circular Menu - Notification Label */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-fields">
	<label><?php _e( 'Choose Template', 'wp-circular-menu' ); ?></label>
	<div class="wpcm-postbox-fields-radio">
		<input type="radio" name="wpcm_label_template"  value="wpcm_label_template_1" id="wpcm_label_template_1" <?php if ( $wpcm_label_template == "wpcm_label_template_1" ) _e('checked="checked"'); ?>/>
		<label for="wpcm_label_template_1"><span class="wpcm-notification-preview <?php if ( $wpcm_label_template == "wpcm_label_template_1" ) esc_attr_e($wpcm_label_animation);?>"><img src="<?php echo WPCM_IMG_DIR; ?>/notification-labels/notification-label-template-1.png" alt="Layout 1"></span></label>
	</div>
	<div class="wpcm-postbox-fields-radio">
		<input type="radio" name="wpcm_label_template" value="wpcm_label_template_2" id="wpcm_label_template_2" <?php if ( $wpcm_label_template == "wpcm_label_template_2" ) _e('checked="checked"'); ?>>
		<label for="wpcm_label_template_2"><span class="wpcm-notification-preview <?php if ( $wpcm_label_template == "wpcm_label_template_2" ) esc_attr_e($wpcm_label_animation);?>"><img src="<?php echo WPCM_IMG_DIR; ?>/notification-labels/notification-label-template-2.png" alt="Layout 2"></span></label>
	</div>
	<div class="wpcm-postbox-fields-radio">
		<input type="radio" name="wpcm_label_template" value="wpcm_label_template_3" id="wpcm_label_template_3" <?php if ( $wpcm_label_template == "wpcm_label_template_3" ) _e('checked="checked"'); ?>>
		<label for="wpcm_label_template_3"><span class="wpcm-notification-preview <?php if ( $wpcm_label_template == "wpcm_label_template_3" ) esc_attr_e($wpcm_label_animation);?>"><img src="<?php echo WPCM_IMG_DIR; ?>/notification-labels/notification-label-template-3.png" alt="Layout 3"></span></label>
	</div>
	<div class="wpcm-postbox-fields-radio">
		<input type="radio" name="wpcm_label_template" value="wpcm_label_template_4" id="wpcm_label_template_4" <?php if ( $wpcm_label_template == "wpcm_label_template_4" ) _e('checked="checked"'); ?>>
		<label for="wpcm_label_template_4"><span class="wpcm-notification-preview <?php if ( $wpcm_label_template == "wpcm_label_template_4" ) esc_attr_e($wpcm_label_animation);?>"><img src="<?php echo WPCM_IMG_DIR; ?>/notification-labels/notification-label-template-4.png" alt="Layout 4"></span></label>
	</div>
	<div class="wpcm-postbox-fields-radio">
		<input type="radio" name="wpcm_label_template" value="wpcm_label_template_5" id="wpcm_label_template_5" <?php if ( $wpcm_label_template == "wpcm_label_template_5" ) _e('checked="checked"'); ?>>
		<label for="wpcm_label_template_5"><span class="wpcm-notification-preview <?php if ( $wpcm_label_template == "wpcm_label_template_5" ) esc_attr_e($wpcm_label_animation);?>"><img src="<?php echo WPCM_IMG_DIR; ?>/notification-labels/notification-label-template-5.png" alt="Layout 5"></span></label>
	</div>
</div> 
<div class="wpcm-postbox-field-wrapper">
	<div class="wpcm-postbox-fields">
		<label><?php _e( 'Notification animation', 'wp-circular-menu' ); ?></label>
		<select name="wpcm_label_animation" class="wpcm-label-animation">
			<option value="wpcm_label_animation_none" <?php if ( $wpcm_label_animation == 'wpcm_label_animation_none' ) _e('selected="selected"'); ?>><?php _e( 'None', 'wp-circular-menu' ); ?></option>
			<option value="wpcm_label_animation_1" <?php if ( $wpcm_label_animation == 'wpcm_label_animation_1' ) _e('selected="selected"'); ?>><?php _e( 'Pulse', 'wp-circular-menu' ); ?></option>
			<option value="wpcm_label_animation_2" <?php if ( $wpcm_label_animation == 'wpcm_label_animation_2' ) _e('selected="selected"'); ?>><?php _e( 'Bounce', 'wp-circular-menu' ); ?></option>
			<option value="wpcm_label_animation_3" <?php if ( $wpcm_label_animation == 'wpcm_label_animation_3' ) _e('selected="selected"'); ?>><?php _e( 'Tada', 'wp-circular-menu' ); ?></option>
			<option value="wpcm_label_animation_4" <?php if ( $wpcm_label_animation == 'wpcm_label_animation_4' ) _e('selected="selected"'); ?>><?php _e( 'Rubber band', 'wp-circular-menu' ); ?></option>
			<option value="wpcm_label_animation_5" <?php if ( $wpcm_label_animation == 'wpcm_label_animation_5' ) _e('selected="selected"'); ?>><?php _e( 'Swing', 'wp-circular-menu' ); ?></option>
		</select>
	</div>
</div>
<div class="wpcm-postbox-fields">
	<label><?php _e( 'Customize?', 'wp-circular-menu' ); ?></label>
	<div class="wpcm-info"><?php _e( 'Check to customize Notification Label settings', 'wp-circular-menu' ); ?></div>
	<div class="wpcm-slide-checkbox-wrapper">
		<div class="wpcm-slide-checkbox-wrapper-inner">
			<div class="wpcm-slide-checkbox">  
				<input type="checkbox" id="wpcm-enable-custom-notification" name="wpcm_enable_custom_notification" <?php if ( $wpcm_enable_custom_notification == 1) _e( 'checked="checked"' ); ?>>
				<label for="wpcm-enable-custom-css"></label>
			</div>
		</div>
	</div>
</div>
<div class="wpcm-postbox-field-wrapper wpcm-notification-color" <?php if (!( $wpcm_enable_custom_notification == 1)) echo 'style="display:none;"'; ?>>
	<div class="wpcm-postbox-fields">
		<label><?php _e( 'Text color', 'wp-circular-menu' ); ?></label>
		<input type="text" name="wpcm_label_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_label_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		
		<label><?php _e( 'Background color', 'wp-circular-menu' ); ?></label>
		<input type="text" name="wpcm_label_bg_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_label_bg_color); ?>">
		
	</div>
</div>
