<?php
/* WP Circular Menu - Tooltip Settings */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-fields">
	<label><?php _e( 'Customize?', 'wp-circular-menu' ); ?></label>
	<div class="wpcm-info"><?php _e( 'Check to customize tooltip settings', 'wp-circular-menu' ); ?></div>
	<div class="wpcm-slide-checkbox-wrapper">
		<div class="wpcm-slide-checkbox-wrapper-inner">
			<div class="wpcm-slide-checkbox">  
				<input type="checkbox" id="wpcm-enable-custom-tooltip" name="wpcm_enable_custom_tooltip" <?php if ( $wpcm_enable_custom_tooltip == 1) _e( 'checked="checked"' ); ?>>
				<label for="wpcm-enable-custom-css"></label>
			</div>
		</div>
	</div>
</div>
<div class="wpcm-postbox-field-wrapper" <?php if (!( $wpcm_enable_custom_tooltip == 1)) echo 'style="display:none;"'; ?>>
<label><?php _e('Color','wp-circular-menu');?></label>
<div class="wpcm-postbox-fields">
	<h2><?php _e('Text','wp-circular-menu');?></h2>
	<input type="text" name="wpcm_tooltip_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e($wpcm_tooltip_color);?>">
</div>
<div class="wpcm-postbox-fields">
	<h2><?php _e('Background','wp-circular-menu');?></h2>
	<input type="text" name="wpcm_tooltip_bg_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e($wpcm_tooltip_bg_color);?>">
</div>
</div>