<?php
/* WP Circular Menu - Menu item settings */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-fields">
	<label><?php _e( 'Customize?', 'wp-circular-menu' ); ?></label>
	<div class="wpcm-info"><?php _e( 'Check to customize menu settings', 'wp-circular-menu' ); ?></div>
	<div class="wpcm-slide-checkbox-wrapper">
		<div class="wpcm-slide-checkbox-wrapper-inner">
			<div class="wpcm-slide-checkbox">  
				<input type="checkbox" id="wpcm-enable-custom-menu" name="wpcm_enable_custom_menu" <?php if ( $wpcm_enable_custom_menu == 1) _e( 'checked="checked"' ); ?>>
				<label for="wpcm-enable-custom-css"></label>
			</div>
		</div>
	</div>
</div>
<div class="wpcm-postbox-field-wrapper" <?php if (!( $wpcm_enable_custom_menu == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Icon Color', 'wp-circular-menu' );?></label>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_icon_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_icon_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Active color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_icon_active_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_icon_active_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Hover color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_icon_hover_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_icon_hover_color); ?>">
	</div>
</div>

<div class="wpcm-postbox-field-wrapper wpcm_menu_icon_bg_color" <?php if (!( $wpcm_enable_custom_menu == 1)) echo 'style="display:none;"'; if($wpcm_hide_icon_bg_color == 1) {_e('style="display:none;"');}?>>
	<label><?php _e( 'Background', 'wp-circular-menu' );?></label>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_bg_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_bg_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Active color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_bg_active_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_bg_active_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Hover color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_bg_hover_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_bg_hover_color); ?>">
	</div>
</div>
<div class="wpcm-postbox-field-wrapper wpcm_center_image" <?php if($wpcm_hide_center_image && $wpcm_hide_bg_color) {_e('style="display:none;"');}?> <?php if (!( $wpcm_enable_custom_menu == 1)) echo 'style="display:none;"'; ?>>
	<div class="wpcm-postbox-fields wpcm_menu_center_image" <?php if($wpcm_hide_center_image) {_e('style="display:none;"');}?>>
		<h2><?php _e( 'Center image', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_center_image" class="wpcm-center-image" value="<?php esc_attr_e( $wpcm_menu_center_image ); ?>">
		<button class="wpcm-image-upload"><i class="fa fa-upload" aria-hidden="true"></i></button>
	</div>
	<div class="wpcm-postbox-fields wpcm_menu_bg_color" <?php if($wpcm_hide_bg_color) {_e('style="display:none;"');}?>>
		<h2><?php _e( 'Center color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_bg_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_bg_color); ?>">
	</div>
	<div class="wpcm-postbox-fields wpcm_menu_center_image" <?php if($wpcm_hide_center_image) {_e('style="display:none;"');}?>>
		<h2><?php _e( 'Center URL', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_center_url" class="wpcm-center-image" value="<?php esc_attr_e( $wpcm_menu_center_url ); ?>">
	</div>
</div> 
<div class="wpcm-postbox-field-wrapper wpcm_menu_item_border" <?php if($wpcm_hide_border_option) {_e('style="display:none;"');}?> <?php if (!( $wpcm_enable_custom_menu == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Border', 'wp-circular-menu' );?></label>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_border_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_border_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Active color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_border_active_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_border_active_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Hover color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_item_border_hover_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_item_border_hover_color); ?>">
	</div>
</div>
<div class="wpcm-postbox-field-wrapper wpcm_menu_arrow" <?php if($wpcm_select_template != 'wpcm-template-7') {_e('style="display:none;"');}?> <?php if (!( $wpcm_enable_custom_menu == 1)) echo 'style="display:none;"'; ?>>
	<label><?php _e( 'Arrow', 'wp-circular-menu' );?></label>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_arrow_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_arrow_color); ?>">
	</div>
	<div class="wpcm-postbox-fields">
		<h2><?php _e( 'Hover color', 'wp-circular-menu' ); ?></h2>
		<input type="text" name="wpcm_menu_arrow_hover_color" data-alpha="true" class="wpcm-color-picker" value="<?php esc_attr_e( $wpcm_menu_arrow_hover_color); ?>">
	</div>
</div> 

