<?php
/* WP Circular Menu - Custom CSS Settings */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-section">
	<div class="wpcm-postbox-fields">
		<label for="wpcm-enable-custom-css"><?php _e( 'Enable Custom CSS Section', 'wp-circular-menu' ); ?></label>
		<div class="wpcm-info"><?php _e( 'Check to Enable Custom CSS Section', 'wp-circular-menu' ); ?></div>
		<div class="wpcm-slide-checkbox-wrapper">
			<div class="wpcm-slide-checkbox-wrapper-inner">
				<div class="wpcm-slide-checkbox">  
					<input type="checkbox" id="wpcm-enable-custom-css" name="wpcm_enable_custom_css" <?php if ( $wpcm_enable_custom_css == 1) _e( 'checked="checked"' ); ?>>
					<label for="wpcm-enable-custom-css"></label>
				</div>
			</div>
		</div>
	</div>
	<div class="wpcm-postbox-fields <?php if (!( $wpcm_enable_custom_css == 1)) _e('wpcm-css-diabled'); ?>" >
		<label for="wpcm-codemirror-textarea">
			<h4><?php _e('Custom CSS');?></h4>
		</label>
		<textarea class="wpcm-codemirror-textarea" name="wpcm_custom_css"><?php echo $wpcm_custom_css;?></textarea>
	</div>
</div>