<?php
/* WP Circular Menu -  Display Settings*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-section">
	<div class="wpcm-postbox-fields">
		<label><?php _e('Permission Settings','wp-circular-menu');?></label>
		<h2><?php _e('Show Circular Menu to','wp-circular-menu');?></h2>
		<select name="wpcm_permission" class="wpcm_permission">
			<option value="wpcm_everyone" <?php if ( $wpcm_permission == 'wpcm_everyone' ) _e( 'selected="selected"' ); ?>><?php _e('Everyone','wp-circular-menu');?></option>
			<option value="wpcm_loggedin" <?php if ( $wpcm_permission == 'wpcm_loggedin' ) _e( 'selected="selected"' ); ?>><?php _e('Logged in Users','wp-circular-menu');?></option>
			<option value="wpcm_loggedout" <?php if ( $wpcm_permission == 'wpcm_loggedout' ) _e( 'selected="selected"' ); ?>><?php _e('Logged out Users','wp-circular-menu');?></option>
		</select>
	</div>
	<div class="wpcm-postbox-fields wpcm-user-roles" <?php if ($wpcm_permission != 'wpcm_loggedin' ) _e('style="display:none;"');?>>
		<h2><?php _e('But Hide For','wp-circular-menu');?></h2>

		<?php
			$user_role_list = $this->get_editable_roles();
			foreach($user_role_list as $key => $value){
				?>
				<div class="wpcm-single-checkbox">
					<input type="checkbox" id="wpcm-post-type-<?php esc_attr_e($key);?>" name="wpcm_user_roles[]" value="<?php esc_attr_e($key);?>" <?php if(in_array($key,$wpcm_user_roles)) echo 'checked';?>>
					<label for="wpcm-post-type-<?php esc_attr_e($key);?>"><?php esc_html_e($user_role_list[$key]['name']);?></label>
				</div>
				<?php
			}
								
		?>
	</div>

	<div class="wpcm-postbox-fields">
		<div class="wpcm-single-checkbox">
			<h2><?php _e('Use as Shortcode','wp-circular-menu');?></h2>
			<input type="checkbox" name="wpcm_use_shortcode" id="wpcm_use_shortcode" <?php if ( $wpcm_use_shortcode == 1) _e( 'checked="checked"' ); ?>>
			<label for="wpcm_use_shortcode"><?php _e('Use as shortcode and hide everywhere else','wp-circular-menu');?></label>
		</div>
	</div>
	<div class="wpcm-postbox-fields">
		<label><?php _e( 'What should the selected checkbox do?', 'wp-circular-menu' ); ?></label>
		<div class="wpcm-single-checkbox">
			<input type="radio" name="wpcm_checkbox_display"  value="wpcm_hide_menu" id="wpcm_hide_menu" <?php if ( $wpcm_checkbox_display == "wpcm_hide_menu" ) _e('checked="checked"'); ?>/>
			<label for="wpcm_hide_menu">Hide Menu in these Pages</label>
		</div>
		<div class="wpcm-single-checkbox">
			<input type="radio" name="wpcm_checkbox_display" value="wpcm_show_menu" id="wpcm_show_menu" <?php if ( $wpcm_checkbox_display == "wpcm_show_menu" ) _e('checked="checked"'); ?>>
			<label for="wpcm_show_menu">Show Menu in these Pages</label>
		</div>
	</div>
	<div class="wpcm-postbox-fields-wrapper">
		<label><?php _e('Hide Circular Menu in','wp-circular-menu');?></label>
		<div class="wpcm-postbox-fields">
			<div class="wpcm-toggle-tab-header wpcm-toggle-active"><h4><?php _e('Default WordPress Pages','wp-circular-menu');?><span class="toggle-indicator" aria-hidden="true"></span></h4></div>
			<div class="wpcm-postbox-fields wpcm-toggle-tab-body">
				<p><input type="checkbox" name="wpcm_front_pages" id="wpcm_front_pages" <?php if ( $wpcm_front_pages == 1) _e( 'checked="checked"' ); ?>><label for="wpcm_front_pages"><?php _e('Front Page','wp-circular-menu');?></label></p>
				<p><input type="checkbox" name="wpcm_blog_pages" id="wpcm_blog_pages" <?php if ( $wpcm_blog_pages == 1 ) _e( 'checked="checked"' ); ?>/><label for="wpcm_blog_pages"><?php _e('Home/Blog Page','wp-circular-menu');?></label></p>
				<p><input type="checkbox" name="wpcm_archive_pages" id="wpcm_archive_pages" <?php if ( $wpcm_archive_pages == 1 ) _e( 'checked="checked"' ); ?>/><label for="wpcm_archive_pages"><?php _e('Archive Page','wp-circular-menu');?></label></p>
				<p><input type="checkbox" name="wpcm_404_pages"  id="wpcm_404_pages" <?php if ( $wpcm_404_pages == 1 ) _e( 'checked="checked"' ); ?>/><label for="wpcm_404_pages"><?php _e('404 Page','wp-circular-menu');?></label></p>
				<p><input type="checkbox" name="wpcm_search_pages"  id="wpcm_search_pages" <?php if ( $wpcm_search_pages == 1 ) _e( 'checked="checked"' ); ?>/><label for="wpcm_search_pages"><?php _e('Search Page','wp-circular-menu');?></label></p>
				<p><input type="checkbox" name="wpcm_single_pages" id="wpcm_single_pages" <?php if ( $wpcm_single_pages == 1 ) _e( 'checked="checked"' ); ?>/><label for="wpcm_single_pages"><?php _e('All Single Page','wp-circular-menu');?></label></p>
			</div>
		</div>
		<?php
		$wpcm_specific_page = array();
		if(!empty($wpcm_specific_pages)){
			foreach($wpcm_specific_pages as $key => $values){
				foreach($values as $value){
					$wpcm_specific_page[] = $value;
				}
			}	
		}
		$post_types = get_post_types(array('public'=>'false'));
		sort($post_types);
		foreach($post_types as $post_type){
			if(!($post_type == 'attachment')){
				$loop = new WP_Query( array( 'post_type' => $post_type, 'posts_per_page' => -1, 'post_status'=>'publish' ) );
				if(!empty($loop->posts)):
					?>
					<div class="wpcm-postbox-fields wpcm-hide-singular" <?php if ($wpcm_single_pages == 1 ) _e('style="display:none;"');?>>
						<div class="wpcm-toggle-tab-header">
							<h4>
								<?php _e('Specific ','wp-circular-menu'); _e(ucwords($post_type));?>
								<span class="toggle-indicator" aria-hidden="true">
								</span>
							</h4>
						</div>
						<div class="wpcm-postbox-fields wpcm-toggle-tab-body" style="display:none;">
							<?php
							while ( $loop->have_posts() ) : $loop->the_post();
								$post_id = get_the_ID();
								?>
								<p>
									<input type="checkbox" name="wpcm_specific_pages[]" id="wpcm-post-<?php esc_attr_e($post_id);?>" value="<?php esc_attr_e($post_id);?>" <?php if( isset($wpcm_specific_pages) && in_array($post_id,$wpcm_specific_page)) echo 'checked';?>	/>
									<label for="wpcm-post-<?php esc_attr_e($post_id);?>"><?php the_title();?></label>
								</p>
								<?php
							endwhile; 
							wp_reset_query();
							?>
						</div>
					</div>
					<?php
				endif;
			}	
		}
		?>
	</div>
	<div class="wpcm-postbox-fields">
		<label><?php _e('Exclude Circular menu from given categories','wp-circular-menu');?></label>
		<input type="text" name="wpcm_custom_terms" value="<?php esc_attr_e( $wpcm_custom_terms ); ?>"/>
		<div class="wpcm-description"><?php _e('Manually enter the custom slugs of the desired terms where you do not want to show Circular menu. For example: category-1,category-2','wp-circular-menu');?></div>
	</div>
</div>