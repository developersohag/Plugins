<?php
/* WP Circular Menu - Build setings */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="wpcm-postbox-fields">
	<label><?php _e('Select Menu','wp-circular-menu');?></label>
	<div class="wpcm-info"><?php _e('Select a circular menu. If you have not created a circular menu, please click ');?> <a href="<?php echo admin_url().'nav-menus.php';?>" target="_blank">here</a><?php _e(' to create a circular menu.','wp-circular-menu');?></div>
	<?php $selected_menu = get_option('wpcm_selected_menu');?>
	<select name="wpcm_select_menu" <?php if(empty($selected_menu)) esc_attr_e('disabled="disabled"'); ?>>
		<?php
		$nav_menus = wp_get_nav_menus();
		$all_nav_menu =array();
		if(!empty($nav_menus)){
			foreach($nav_menus as $nav_menu){
				$all_nav_menu[] = $nav_menu->term_id;
			}
		}
		$wpcm_selected_menu = get_option('wpcm_selected_menu');	
		if(!empty($wpcm_selected_menu)){

			foreach($wpcm_selected_menu as $menu_id){
				if(in_array($menu_id, $all_nav_menu)){
					$menu_object = wp_get_nav_menu_object( $menu_id );	
					?>
					<option value="<?php esc_attr_e($menu_object->term_id);?>" <?php if ( $wpcm_select_menu == esc_attr($menu_object->term_id) ) _e( 'selected="selected"' ); ?>><?php echo $menu_object->name;?></option>
					<?php
				}
			}
		}else{
			?>
			<option value="no-menu"><?php _e('Circular Menu not set','wp-circular-menu');?></option>
			<?php
		}
		?>
	</select>
</div>