<?php
/* WP Circular Menu - Save all backend meta box values */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
if(!isset($_POST['wpcm_meta_nonce'])){
	return;
}

if(! wp_verify_nonce( $_POST['wpcm_meta_nonce'],'wpcm_save_settings')){
	return;
}

if(! current_user_can( 'edit_post',$post_id)){
	return;
}

/*$this->print_array($_POST);
die();*/

$wpcm_settings = array();
/*Build Settings*/
$wpcm_settings['wpcm_select_menu'] = isset($_POST['wpcm_select_menu'])? sanitize_text_field($_POST['wpcm_select_menu']):'';   

/*Layout Settings*/
$wpcm_settings['wpcm_select_template'] = isset($_POST['wpcm_select_template'])? sanitize_text_field($_POST['wpcm_select_template']):'wpcm-template-1'; 
$wpcm_settings['wpcm_position'] = isset($_POST['wpcm_position'])? sanitize_text_field($_POST['wpcm_position']):'wpcm-bottom-middle'; 
$wpcm_settings['wpcm_initial_top'] = isset($_POST['wpcm_initial_top'])? sanitize_text_field($_POST['wpcm_initial_top']):''; 
$wpcm_settings['wpcm_initial_left'] = isset($_POST['wpcm_initial_left'])? sanitize_text_field($_POST['wpcm_initial_left']):''; 
$wpcm_settings['wpcm_select_animation'] = isset($_POST['wpcm_select_animation'])? sanitize_text_field($_POST['wpcm_select_animation']):'wpcm-animation-1'; 

/*Since version 1.0.3*/
$wpcm_settings['wpcm_keep_open'] = isset($_POST['wpcm_keep_open'])? 1:0; 
$wpcm_settings['wpcm_hide_toggle'] = isset($_POST['wpcm_hide_toggle'])? 1:0; 
$wpcm_settings['wpcm_menu_fixed'] = isset($_POST['wpcm_menu_fixed'])? 1:0; 
$wpcm_settings['wpcm_disable_draggable'] = isset($_POST['wpcm_disable_draggable'])? 1:0; 
$wpcm_settings['wpcm_disable_responsive'] = isset($_POST['wpcm_disable_responsive'])? 1:0; 


/*Toggle button settings*/
$wpcm_settings['wpcm_enable_custom_toggle'] = isset($_POST['wpcm_enable_custom_toggle'])? 1:0;
$wpcm_settings['wpcm_toggle_icon_open_color'] = isset($_POST['wpcm_toggle_icon_open_color'])? sanitize_text_field($_POST['wpcm_toggle_icon_open_color']):'';  
$wpcm_settings['wpcm_toggle_icon_close_color'] = isset($_POST['wpcm_toggle_icon_close_color'])? sanitize_text_field($_POST['wpcm_toggle_icon_close_color']):'';  
$wpcm_settings['wpcm_toggle_icon_hover_color'] = isset($_POST['wpcm_toggle_icon_hover_color'])? sanitize_text_field($_POST['wpcm_toggle_icon_hover_color']):'';  

$wpcm_settings['wpcm_toggle_bg_open_color'] = isset($_POST['wpcm_toggle_bg_open_color'])? sanitize_text_field($_POST['wpcm_toggle_bg_open_color']):'';  
$wpcm_settings['wpcm_toggle_bg_close_color'] = isset($_POST['wpcm_toggle_bg_close_color'])? sanitize_text_field($_POST['wpcm_toggle_bg_close_color']):'';  
$wpcm_settings['wpcm_toggle_bg_hover_color'] = isset($_POST['wpcm_toggle_bg_hover_color'])? sanitize_text_field($_POST['wpcm_toggle_bg_hover_color']):''; 

$wpcm_settings['wpcm_toggle_border_open_color'] = isset($_POST['wpcm_toggle_border_open_color'])? sanitize_text_field($_POST['wpcm_toggle_border_open_color']):'';  
$wpcm_settings['wpcm_toggle_border_close_color'] = isset($_POST['wpcm_toggle_border_close_color'])? sanitize_text_field($_POST['wpcm_toggle_border_close_color']):'';  
$wpcm_settings['wpcm_toggle_border_hover_color'] = isset($_POST['wpcm_toggle_border_hover_color'])? sanitize_text_field($_POST['wpcm_toggle_border_hover_color']):''; 
$wpcm_settings['wpcm_toggle_border_size'] = isset($_POST['wpcm_toggle_border_size'])? sanitize_text_field($_POST['wpcm_toggle_border_size']):''; 

$wpcm_settings['wpcm_toggle_animation'] = isset($_POST['wpcm_toggle_animation'])? sanitize_text_field($_POST['wpcm_toggle_animation']):'wpcm-toggle-animation-1';   

/*Menu items*/
$wpcm_settings['wpcm_enable_custom_menu'] = isset($_POST['wpcm_enable_custom_menu'])? 1:0;
$wpcm_settings['wpcm_menu_item_icon_color'] = isset($_POST['wpcm_menu_item_icon_color'])? sanitize_text_field($_POST['wpcm_menu_item_icon_color']):''; 
$wpcm_settings['wpcm_menu_item_icon_active_color'] = isset($_POST['wpcm_menu_item_icon_active_color'])? sanitize_text_field($_POST['wpcm_menu_item_icon_active_color']):''; 
$wpcm_settings['wpcm_menu_item_icon_hover_color'] = isset($_POST['wpcm_menu_item_icon_hover_color'])? sanitize_text_field($_POST['wpcm_menu_item_icon_hover_color']):''; 

$wpcm_settings['wpcm_menu_item_bg_color'] = isset($_POST['wpcm_menu_item_bg_color'])? sanitize_text_field($_POST['wpcm_menu_item_bg_color']):''; 
$wpcm_settings['wpcm_menu_item_bg_active_color'] = isset($_POST['wpcm_menu_item_bg_active_color'])? sanitize_text_field($_POST['wpcm_menu_item_bg_active_color']):''; 
$wpcm_settings['wpcm_menu_item_bg_hover_color'] = isset($_POST['wpcm_menu_item_bg_hover_color'])? sanitize_text_field($_POST['wpcm_menu_item_bg_hover_color']):''; 

$wpcm_settings['wpcm_menu_item_border_color'] = isset($_POST['wpcm_menu_item_border_color'])? sanitize_text_field($_POST['wpcm_menu_item_border_color']):''; 
$wpcm_settings['wpcm_menu_item_border_active_color'] = isset($_POST['wpcm_menu_item_border_active_color'])? sanitize_text_field($_POST['wpcm_menu_item_border_active_color']):''; 
$wpcm_settings['wpcm_menu_item_border_hover_color'] = isset($_POST['wpcm_menu_item_border_hover_color'])? sanitize_text_field($_POST['wpcm_menu_item_border_hover_color']):''; 

$wpcm_settings['wpcm_menu_center_image'] = isset($_POST['wpcm_menu_center_image'])? sanitize_text_field($_POST['wpcm_menu_center_image']):''; 
$wpcm_settings['wpcm_menu_center_url'] = isset($_POST['wpcm_menu_center_url'])? sanitize_text_field($_POST['wpcm_menu_center_url']):''; 
$wpcm_settings['wpcm_menu_bg_color'] = isset($_POST['wpcm_menu_bg_color'])? sanitize_text_field($_POST['wpcm_menu_bg_color']):''; 

$wpcm_settings['wpcm_menu_arrow_color'] = isset($_POST['wpcm_menu_arrow_color'])? sanitize_text_field($_POST['wpcm_menu_arrow_color']):''; 
$wpcm_settings['wpcm_menu_arrow_hover_color'] = isset($_POST['wpcm_menu_arrow_hover_color'])? sanitize_text_field($_POST['wpcm_menu_arrow_hover_color']):''; 

/*Notification Label*/
$wpcm_settings['wpcm_enable_custom_notification'] = isset($_POST['wpcm_enable_custom_notification'])? 1:0;
$wpcm_settings['wpcm_label_color'] = isset($_POST['wpcm_label_color'])? sanitize_text_field($_POST['wpcm_label_color']):''; 
$wpcm_settings['wpcm_label_bg_color'] = isset($_POST['wpcm_label_bg_color'])? sanitize_text_field($_POST['wpcm_label_bg_color']):''; 
$wpcm_settings['wpcm_label_animation'] = isset($_POST['wpcm_label_animation'])? sanitize_text_field($_POST['wpcm_label_animation']):'wpcm_label_animation_1'; 
$wpcm_settings['wpcm_label_template'] = isset($_POST['wpcm_label_template'])? sanitize_text_field($_POST['wpcm_label_template']):'wpcm_label_template_1'; 

/*Tooltip*/
$wpcm_settings['wpcm_enable_custom_tooltip'] = isset($_POST['wpcm_enable_custom_tooltip'])? 1:0;
$wpcm_settings['wpcm_tooltip_color'] = isset($_POST['wpcm_tooltip_color'])? sanitize_text_field($_POST['wpcm_tooltip_color']):''; 
$wpcm_settings['wpcm_tooltip_bg_color'] = isset($_POST['wpcm_tooltip_bg_color'])? sanitize_text_field($_POST['wpcm_tooltip_bg_color']):''; 

/*Typography*/

$wpcm_settings['wpcm_enable_custom_typo'] = isset($_POST['wpcm_enable_custom_typo'])? 1:0;
$wpcm_settings['wpcm_font_family'] = isset($_POST['wpcm_font_family'])? sanitize_text_field($_POST['wpcm_font_family']):''; 
$wpcm_settings['wpcm_text_transform'] = isset($_POST['wpcm_text_transform'])? sanitize_text_field($_POST['wpcm_text_transform']):''; 

/*Display Settings*/
$wpcm_settings['wpcm_permission'] = isset($_POST['wpcm_permission'])? sanitize_text_field($_POST['wpcm_permission']):'wpcm_everyone';
$wpcm_settings['wpcm_checkbox_display'] = isset($_POST['wpcm_checkbox_display'])? sanitize_text_field($_POST['wpcm_checkbox_display']):'wpcm_hide_menu';
$wpcm_settings['wpcm_use_shortcode'] = isset($_POST['wpcm_use_shortcode'])? 1:0;
$wpcm_settings['wpcm_front_pages'] = isset($_POST['wpcm_front_pages'])? 1:0;	
$wpcm_settings['wpcm_blog_pages'] = isset($_POST['wpcm_blog_pages'])? 1:0;	
$wpcm_settings['wpcm_archive_pages'] = isset($_POST['wpcm_archive_pages'])? 1:0;	
$wpcm_settings['wpcm_single_pages'] = isset($_POST['wpcm_single_pages'])? 1:0;	
$wpcm_settings['wpcm_404_pages'] = isset($_POST['wpcm_404_pages'])? 1:0;	
$wpcm_settings['wpcm_search_pages'] = isset($_POST['wpcm_search_pages'])? 1:0;	
$wpcm_settings['wpcm_custom_terms'] = isset($_POST['wpcm_custom_terms'])? sanitize_text_field($_POST['wpcm_custom_terms']):'';

/*User roles*/

if ( isset( $_POST['wpcm_user_roles'] ) ) {
	foreach ( $_POST['wpcm_user_roles'] as $key => $value ) {
		$wpcm_settings['wpcm_user_roles'][$key] = $value;
	}
} else {
	$wpcm_settings['wpcm_user_roles'] = array();
}

/*Custom CSS*/
$wpcm_settings['wpcm_enable_custom_css'] = isset($_POST['wpcm_enable_custom_css'])? 1:0;	
$wpcm_settings['wpcm_custom_css'] = isset($_POST['wpcm_custom_css'])? wp_kses_post($_POST['wpcm_custom_css']):'';


update_post_meta($post_id,'_wpcm_settings',$wpcm_settings);

if(isset($_POST['wpcm_specific_pages'])){
	$wpcm_specific_pages = array();
	foreach($_POST['wpcm_specific_pages'] as $post_ID){
		$wpcm_specific_pages[] = $post_ID;
	}
	update_post_meta($post_id, '_wpcm_specific_pages', $wpcm_specific_pages);
}else{
	$wpcm_specific_pages = array();
	update_post_meta($post_id, '_wpcm_specific_pages', $wpcm_specific_pages);
}



