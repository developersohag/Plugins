<?php

/* 
 * WP Circular Menu - How to use plugin
 */
defined('ABSPATH') or die("No script kiddies please!");?>
<div class="wpcm-wrap wpcm-clear">
  <div class="wpcm-body-wrapper wpcm-add-bar-wrapper">
    <div class="wpcm-panel">
      <div class="wpcm-panel-head">
       <div class="wpcm-head-social-link">
        <span class="wpcm-header-close">X</span>
        <p class="wpcm-follow-us"><?php _e('Follow us for new updates','wp-circular-menu');?></p>
        <div id="fb-root"></div>
        <script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];if (d.getElementById(id)) return;js = d.createElement(s); js.id = id;js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4";fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script>
        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>

        <a href="https://twitter.com/apthemes" class="twitter-follow-button" data-show-count="false"></a>
        <div class="fb-like" data-href="https://www.facebook.com/AccessPress-Themes" data-layout="button" data-action="like" data-show-faces="true" data-share="false"></div>

      </div>
    </div>
    <div class="wpcm-panel-body">
      <div class="wpcm-backend-h-title"><?php _e('How to use','wpcm-plugin-pro');?></div>
      <div class="wpcm-use-content-wrap">
        <h1><span>WP Circular Menu - Responsive Circular Menu Plugin for WordPress</span><span class="wpcm-version">Version <?php echo WPCM_VERSION;?></span></h1>
        <h2 id="createmenu"><strong>Creating a Menu for WP Circular Menu</strong></h2>
        <p>You will need to need to configure a WordPress Menu before you can begin creating your circular menu. So,</p>
        <ul>
          <li><span>Go to Dashboard-&gt; Appearance-&gt; Menus.</span></li>
          <li><span>Click on Create a Menu, to create a new menu.</span></li>
          <li><span>Provide a menu name and click on Create Menu.</span></li>
          <li><span>Go to Screen Option on the top of the Menu Page and check WP Circular Menu under Boxes.</span></li>
          <li><span>Locate the WP Circular Menu Meta boxes, Check on Use as circular menu option if you want use the current menu as Circular menu.</span></li>
          <li><span>Select the Menu items you want to add to be menu and click on save menu. The menu supports 12 menu items except for template 9 which supports 8 menu item dues to design limitation. The plugin does not support sub-menus.</span></li>
          <li><span>You will need to first save the menu after any menu item change to see the WP Circular Menu option in the newly added menu items.</span></li>
          <li><span>You will see the WP Circular Menu icon on each Menu item, click on it to open a modular setting menu.</span><br/>
            <p>Unlike a normal menu this menu allows you to add things like, an icon, background image, alter Tooltip text to your individual menu item.</p>
            <h5>Menu Settings</h5>
            <ul>
              <li>
                <h5>Menu Icon</h5>
                <ul>
                  <h5>Icon Type</h5>
                  <li><strong>Font Icons: </strong> Circular Menu Supports a wide range of font icons including Dashicons, Font Awesome, Genericons, Linear Icons and Themify icons. Click button to select a font icon. You can also directly add icon code such as dashicons|dashicons-admin-site or fa|fa-envelope-o or genericon|genericon-aside or lnr|lnr-home or ti|ti-home </li>
                  <li><strong>Custom Icon: </strong> If icons are not a thing for you, you can upload your own icons images from the WordPress media library. Click button to upload media from media library or even directly place an image URL.</li>
                </ul>
              </li>
              <li>
                <h5>Menu Name</h5>
                <ul>
                  <li><strong>Hide/ Show Menu Name: </strong> In default, the circular menu will show the menu name label when you hover hover it. If you don't want this feature, check this option to hide showing of the menu name on hover.</li>
                  <li><strong>Custom Name: </strong> If you want to alter the menu name text then simply add text here to overwrite the default menu name.</li>
                </ul>
              </li>
              <li>
                <h5>Notification Label</h5>
                <strong>Notification Text: </strong>Want to focus your viewers to a particular page? Have a hot sale going on your store? Circular menu allows to to added static Notification label to let people know what is going on with each particular link.
              </li>
              <li>
                <h5>Background</h5>
                <strong>Image Background: </strong> Best suited for template 2 and not supported in template 3, 4 and 5, you can add background images in each of the menu list items.
              </li>
            </ul>
          </li>
        </ul>
        <p>Once you have created your menu items, let's create your first ever circular menu.</p>
        <hr>
        <h2 id="configuresettings"><strong>Configure WP Circular Menu</strong></h2>
        <ul>
          <li>Click on WP Circular Menu on the left admin panel.</li>
          <li>Click on add new.</li>
          <li><span>Enter title for your Circular menu.</span></li>
          <p>You can configure the Circular menu in couple of steps, Let's begin with</p>
        </ul>
          
          <h2 id="buildmenu"><strong>1. Build Circular Menu</strong></h2>
    <p>Select the assigned Circular Menu here and begin configuring your circular menu.</p>
    <p>Check <a href="#createmenu">Creating a Menu for WP Circular Menu</a> to learn how to create a Circular menu.</p>
    <hr>
    <h2 id="layout"><strong>2. Layout Settings</strong></h2>
    <ul>
      <li><strong>Select Template: </strong> Select any one of 9 prebuild ready to go templates. We offer 5 draggable templates and 4 fixed templates.</li>
      <li><strong>Initial position: </strong> Only available for draggable templates. You can set the initial position of the menu on page load.</li>
      <li><strong>Positions:</strong> Only available for fixed templates. Set a suitable fixed position for your menu to load on.</li>
      <li><strong>Animation: </strong> Select open and close animation.</li>
      <li>
        <strong>Toggle Button: </strong>
        <ul>
          <li><strong>Toggle Animation: </strong> Select a animation for toggle button</li>
          <li><strong>Customize? </strong> Check to customize the toggle button.
          <ul>
            <li><strong>Icon colors: </strong> set open, close and hover color for the toggle bars.</li>
            <li><strong>Background: </strong> set open, close and hover color for toggle button background.</li>
            <li><strong>Border: </strong> set open, close and hover color and width for toggle button border.</li>
          </ul>
          </li>
        </ul>
      </li>
      <li>
        <strong>Menu item: </strong>
        <ul>
          <li><strong>Customize? </strong> Check to customize the Menu items.
            <ul>
              <li><strong>Icon colors: </strong> set icon color, active color and hover color for the menu icons.</li>
              <li><strong>Background: </strong> set icon color, active color and hover color for the menu icon background.</li>
              <li><strong>Border: </strong> set icon color, active color and hover color for the menu icon background. Option available only in template 2, 3, 6 and 9.</li>
              <li><strong>Center Image: </strong> set an image background in the menu center. Option available only in template 1, 4 and 8</li>
              <li><strong>Center color: </strong> set an background color in the menu center. Option available only in template 1, 4 and 8</li>
            </ul>
          </li>
        </ul>
      </li>
      <li>
        <strong>Notification label: </strong>
        <ul>
          <li><strong>Choose template: </strong> Choose one of five template for your notification label.</li>
          <li><strong>Notificaition animation: </strong> Choose one of five animation for your notification label.</li>
          <li><strong>Customize? </strong> Check to customize the notification label.
            <ul>
              <li><strong>Text colors: </strong> set text color for your notification label.</li>
              <li><strong>Background color: </strong> set background color for your notification label.</li>
            </ul>
          </li>
        </ul>
      </li>
      <li>
        <strong>Tooltip: </strong>
        <ul>
          <li><strong>Customize? </strong> Check to customize the tooltip.
            <ul>
              <li><strong>Text colors: </strong> set text color for your tooltip.</li>
              <li><strong>Background color: </strong> set background color for your tooltip.</li>
            </ul>
          </li>
        </ul>
      </li>
      <li>
        <strong>Typography: </strong>
        <ul>
          <li><strong>Customize? </strong> Check to customize the typography.
            <ul>
              <li><strong>Font family: </strong> select a font family.</li>
              <li><strong>Text transform: </strong> set top capitalize, lowercase or uppercase your tooltip and notification label.</li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
      <hr/>

          <h2 id="display"><strong>3. Display Settings</strong></h2>
      <p>You can set where to show or hide the Circular menu. These settings can be used to manage multiple menus in different pages. By default all menus are set to show in all pages. You can set where to show the menu and whom to show the menu to.</p>
      <ul>
        <li><strong>Permission Settings: </strong> Set to show the menu to All users/ Logged in users or Logged out users.</li>
        <li><strong>Hide Circular Menu in: </strong> Select the pages where you do not want to show this particular menu. The list should cover all the default WordPress Standard Pages and all the single pages of any custom post type. If you select the All Single Page option no menu will be shown in the single pages regardless of th particular page option below.</li>
      </ul>
      <hr>
      <h2 id="css"><strong>4. Custom CSS</strong></h2>
      <p>Custom CSS section can be handy to provide CSS rules or modify any of the default settings or cover any settings that we might have missed in the Custom Settings.</p>
      <p>Turn the style you have written on or off from Enable Custom CSS Section option.</p>
      <hr>
      <h2 id="css"><strong>Documentation link</strong></h2>
      <p>Follow this link for detail documentation: <a href="https://accesspressthemes.com/documentation/wp-circular-menu/" target="_blank">https://accesspressthemes.com/documentation/wp-circular-menu/</a></p>
      <hr>
      <h2 id="css"><strong>Need Help?</strong></h2>
      <p>If you have any confusion or need our help, drop us a mail at: <a href="support@accesspressthemes.com" target="_blank">support@accesspressthemes.com</a></p>
      <hr>

          </div>
        </div>
      </div>
    </div>
  </div>

