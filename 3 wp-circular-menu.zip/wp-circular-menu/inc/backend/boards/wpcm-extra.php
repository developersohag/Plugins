<?php
$wpcm_disable_flat_design = get_option( 'wpcm_disable_flat_design');
$wpcm_disable_flat_design = !empty($wpcm_disable_flat_design)? $wpcm_disable_flat_design : 0;
?>
<div class="wpcm-panel-body">
	<div class="wpcm-backend-h-title"><?php _e('Extra','wp-circular-menu');?></div>
	<div class="wpcm-about-content-wrap">
		<div class="wpcm-about-left-block">
			<div class="wpcm-postbox-fields">
				<label><?php _e( 'Disable responsive design?', 'wp-circular-menu' ); ?><span class="spinner is-active wpcm-loader"></span></label>
				<div class="wpcm-info"><?php _e( 'Disable the default flat menu design for small devices. This settings apply to all Circular menus', 'wp-circular-menu' ); ?></div>
				<div class="wpcm-slide-checkbox-wrapper">
					<div class="wpcm-slide-checkbox-wrapper-inner">
						<div class="wpcm-slide-checkbox">  
							<input type="checkbox" id="wpcm-disable-flat-design" name="wpcm_disable_flat_design" class="wpcm-disable-flat-design"<?php if ( $wpcm_disable_flat_design == 1) _e( 'checked="checked"' ); ?>>
							<label for="wpcm-enable-custom-css"></label>
						</div>
					</div>
				</div>	
				<div class="wpcm-saved" style="display:none;"><?php _e('Saved','wp-circular-menu');?></div>	
			</div>
			
			
		</div>
	</div>
</div>