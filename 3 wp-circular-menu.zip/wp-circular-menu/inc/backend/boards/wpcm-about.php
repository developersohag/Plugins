<?php
/* 
 * WP Circular Menu - About plugin
 */
defined('ABSPATH') or die("No script kiddies please!");?>

<!-- Facebook link -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


<div class="wpcm-wrap wpcm-clear">
    <div class="wpcm-body-wrapper wpcm-add-bar-wrapper">
        <div class="wpcm-panel">
        <div class="wpcm-panel-body">
            <div class="wpcm-backend-h-title"><?php _e('About','wp-circular-menu');?></div>
            <div class="wpcm-about-content-wrap">
                <div class="wpcm-about-left-block">
                    <p>
                        <?php _e('<strong>WP Circular menu</strong> is a premium circular structure menu for easy and quick navigation within your site.','wp-circular-menu');?>
                    </p>
                    <p>
                        <?php _e('<strong>WP Circular menu</strong> makes use of the default WordPress menu function to create menus. You can add up to 12 menu items and can include additional elements to the default menu items such as Menu Icons and Tooltip.','wp-circular-menu');?>
                    </p>

                    <p>
                        <?php _e('<strong>Please visit our product page for more details here:</strong>','wp-circular-menu');?><br/>
                        <a href="https://accesspressthemes.com/wordpress-plugins/wp-circular-menu/" target="_blank"> https://accesspressthemes.com/wordpress-plugins/wp-circular-menu/</a>
                    </p>

                    <p>
                        <?php _e('<strong>Plugin documentation can be found here:</strong>','wp-circular-menu');?><br/>
                        <a href="https://accesspressthemes.com/documentation/wp-circular-menu/" target="_blank"> https://accesspressthemes.com/documentation/wp-circular-menu/</a>
                    </p>

                    <p><?php _e('<strong>Plugin Demo Link can be found here:</strong>','wp-circular-menu');?><br/>
                        <a href="https://demo.accesspressthemes.com/wordpress-plugins/wp-circular-menu/" target="_blank">https://demo.accesspressthemes.com/wordpress-plugins/wp-circular-menu/</a>
                    </p>
                </div>
                <div class="wpcm-about-right-block">
                    <h3><?php _e('Get in touch','wp-circular-menu');?></h3>
                    <p><?php _e('If you have any question/feedback, please get in touch:','wp-circular-menu');?></p>
                    <p>
                        <strong><?php _e('General enquiries:','wp-circular-menu');?></strong> 
                        <a href="mailto:info@accesspressthemes.com">info@accesspressthemes.com</a><br />
                        <strong><?php _e('Support:','wp-circular-menu');?></strong> 
                        <a href="mailto:support@accesspressthemes.com">support@accesspressthemes.com</a><br />
                        <strong><?php _e('Sales:','wp-circular-menu');?></strong> 
                        <a href="mailto:sales@accesspressthemes.com">sales@accesspressthemes.com</a>
                    </p>

                    <div class="wpcmpro-col-one-third">
                        <h3><?php _e('Get social','wp-circular-menu');?></h3>
                        <p><?php _e('Get connected with us on social media. Facebook is the best place to find updates on our themes/plugins: ','wp-circular-menu');?></p>

                        <p>
                            <strong><?php _e('Like us on facebook:','wp-circular-menu');?></strong>
                            <br />
                            <div class="fb-page" data-href="https://www.facebook.com/AccessPress-Themes" data-small-header="false" 
                            data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                            <div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/AccessPress-Themes">
                                <a href="https://www.facebook.com/AccessPress-Themes">AccessPress Themes</a></blockquote>
                            </div>
                        </div>
                    </p>

                    <ul class="wpcmpro-about-social-icon wpcmpro-unstyled wpcmpro-inlinelist">
                        <li><a href="https://www.facebook.com/AccessPress-Themes" 
                            target="_blank"><img src="<?php echo WPCM_IMG_DIR; ?>/icon-sets/facebook.png" alt="facebook"></a>
                        </li>
                        <li><a href="https://twitter.com/apthemes" target="_blank">
                            <img src="<?php echo WPCM_IMG_DIR; ?>/icon-sets/twitter.png" alt="twitter"></a>
                        </li>
                        <li><a href="http://www.pinterest.com/accesspresswp/" 
                            target="_blank"><img src="<?php echo WPCM_IMG_DIR; ?>/icon-sets/pinterest.png" alt="pinterest"></a>
                        </li>
                        <li><a href="https://plus.google.com/u/0/+Accesspressthemesprofile/about" 
                            target="_blank"><img src="<?php echo WPCM_IMG_DIR; ?>/icon-sets/googlePlus.png" alt="googlePlus"></li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>
</div>
</div>



