<?php
/*
* WP Circular Menu - Nav.php Modal Box Options
*/
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
$menu_id = sanitize_text_field( $_POST[menu_id] );
$menu_item_id = sanitize_text_field( $_POST[menu_item_id] );
$menu_item_title = sanitize_text_field( $_POST[menu_item_title] );

$wpcm_menu_item_settings = get_post_meta( $menu_item_id, '_wpcmItemSettings' );

/*$this->print_array($wpcm_menu_item_settings);*/

/*Menu Name tab*/
$wpcm_popup_show_title = isset( $wpcm_menu_item_settings['0']['wpcm_popup_show_title'] ) ? sanitize_text_field( $wpcm_menu_item_settings['0']['wpcm_popup_show_title'] ) : 0;
echo $wpcm_popup_show_title;
$wpcm_tooltip_text = isset( $wpcm_menu_item_settings['0']['wpcm_tooltip_text'] ) ? sanitize_text_field( $wpcm_menu_item_settings['0']['wpcm_tooltip_text'] ) : '';

/*Icon Menu*/
$wpcm_icon_type = isset( $wpcm_menu_item_settings['0']['wpcm_icon_type'] ) ? sanitize_text_field( $wpcm_menu_item_settings['0']['wpcm_icon_type'] ) : 'wpcm_none';
$wpcm_font_icon = isset( $wpcm_menu_item_settings['0']['wpcm_font_icon'] ) ? sanitize_text_field( $wpcm_menu_item_settings['0']['wpcm_font_icon'] ) : '';
$wpcm_custom_icon = isset( $wpcm_menu_item_settings['0']['wpcm_custom_icon'] ) ? sanitize_text_field( $wpcm_menu_item_settings['0']['wpcm_custom_icon'] ) : '';

/*Background color*/
$wpcm_bg_image = isset( $wpcm_menu_item_settings['0']['wpcm_bg_image'] ) ? sanitize_text_field( $wpcm_menu_item_settings['0']['wpcm_bg_image'] ) : '';

/*Notification Label*/
$wpcm_notification_text = isset( $wpcm_menu_item_settings['0']['wpcm_notification_text'] ) ? sanitize_text_field( $wpcm_menu_item_settings['0']['wpcm_notification_text'] ) : '';
?>
<div class="wpcm-nav-menu-response">
	<form class="wpcm-menu-item-data" action="" method="POST" enctype="multipart/form-data">
		<div class="wpcm-nav-menu-header">
			<h2>
				<?php
				_e( 'Menu Settings - ', 'wp-circular-menu' );
				_e( $menu_item_title );
				?>
			</h2>
		</div>
		<div class="wpcm-nav-menu-content">
			<ul class="nav-tab-wrapper">
				<li class="nav-tab nav-tab-active" data-tab="tab-2"><?php _e( 'Menu Icon', 'wp-circular-menu' ); ?></li>
				<li class="nav-tab" data-tab="tab-1"><?php _e( 'Menu Name', 'wp-circular-menu' ); ?></li>
				<li class="nav-tab" data-tab="tab-4"><?php _e( 'Notification Label', 'wp-circular-menu' ); ?></li>
				<li class="nav-tab" data-tab="tab-3"><?php _e( 'Background', 'wp-circular-menu' ); ?></li>
			</ul>
			<!-- Menu Name Settings -->
			<div id="tab-1" class="wpcm-tab-content">
				<div class="wpcm-popup-field">
					<label for="wpcm_popup_show_title_<?php esc_attr_e( $menu_item_id ); ?>"><?php _e( 'Show/hide menu name', 'wp-circular-menu' ); ?></label>
					<div class="wpcm-slide-checkbox-wrapper">
						<div class="wpcm-slide-checkbox-wrapper-inner">
							<div class="wpcm-slide-checkbox">  
								<input type="checkbox" id="wpcm_popup_show_title_<?php esc_attr_e( $menu_item_id ); ?>" name="wpcm_popup_show_title" class="wpcm-popup-checkbox" <?php if ( $wpcm_popup_show_title == 1 ) echo 'checked'; ?>/>
								<label for="wpcm-enable-custom-css"></label>
							</div>
						</div>
					</div>
					<div class="wpcm-info"><?php _e( 'Check to hide menu name in frontend', 'wp-circular-menu' ); ?></div>
				</div>
				<div class="wpcm-popup-field">
					<label for="wpcm_tooltip_text_<?php esc_attr_e( $menu_item_id ); ?>"><?php _e( 'Custom Name', 'wp-circular-menu' ); ?></label>
					<input type="text" id="wpcm_tooltip_text_<?php esc_attr_e( $menu_item_id ); ?>" name="wpcm_tooltip_text" value="<?php esc_attr_e( $wpcm_tooltip_text); ?>">
				</div>
			</div>
			<!-- end of Menu Name Settings -->

			<!-- Menu Icon Settings -->
			<div id="tab-2" class="wpcm-tab-content wpcm-current">
				<div class="wpcm-popup-field">
					<label for="wpcm_tooltip_bg_color_<?php esc_attr_e( $menu_item_id ); ?>"><?php _e( 'Icon Type', 'wp-circular-menu' ); ?></label>
					<select name="wpcm_icon_type" class="wpcm-icon-select" id="wpcm_icon_type_<?php esc_attr_e( $menu_item_id ); ?>">
						<option value="wpcm_none" <?php if ( $wpcm_icon_type == 'wpcm_none' ) echo 'selected'; ?>><?php _e( 'None', 'wp-circular-menu' ); ?></option>
						<option value="wpcm_font_icon" <?php if ( $wpcm_icon_type == 'wpcm_font_icon' ) echo 'selected'; ?>><?php _e( 'Font icon', 'wp-circular-menu' ); ?></option>
						<option value="wpcm_custom_icon" <?php if ( $wpcm_icon_type == 'wpcm_custom_icon' ) echo 'selected'; ?>><?php _e( 'Custom icon', 'wp-circular-menu' ); ?></option>
					</select>
				</div>
				<div class="wpcm-popup-field wpcm_font_icon" <?php if($wpcm_icon_type != 'wpcm_font_icon') echo 'style="display:none;"';?>>
					<label for="wpcm_font_icon_<?php esc_attr_e( $menu_item_id ); ?>"><?php _e( 'Font Icon', 'wp-circular-menu' ); ?></label>
					<div class="wpcm-info"><?php _e( 'Click button to select a font icon. You can also directly add icon code such as dashicons|dashicons-admin-site or fa|fa-envelope-o or genericon|genericon-aside or lnr|lnr-home or ti|ti-home', 'wp-circular-menu' ); ?></div>
					<div id="wpcm-menu-icon-div-2" data-target="#wpcm_font_icon_<?php esc_attr_e( $menu_item_id ); ?>" class="button icon-picker <?php
						if ( !empty($wpcm_font_icon) ) {
							$v = explode( '|', $wpcm_font_icon );
							echo $v[0] . ' ' . $v[1];
						}
						?>">
					</div>
					<input class="wpcm-icon-picker" type="text" id="wpcm_font_icon_<?php esc_attr_e( $menu_item_id ); ?>" name="wpcm_font_icon" value="<?php esc_attr_e( $wpcm_font_icon); ?>"/>
				</div>
				<div class="wpcm-popup-field wpcm_custom_icon" <?php if($wpcm_icon_type != 'wpcm_custom_icon') echo 'style="display:none;"';?>>
					<label for="wpcm_custom_icon_<?php esc_attr_e( $menu_item_id ); ?>"><?php _e( 'Custom Icon', 'wp-circular-menu' ); ?></label>
					<div class="wpcm-info"><?php _e( 'Click button to upload media from media library or directly place image URL', 'wp-circular-menu' ); ?></div>
					<div class="button custom_image_background_button">
						<div class="current-background-image">
							<?php if(!empty($wpcm_custom_icon)) { ?>
							<img src="<?php esc_attr_e( $wpcm_custom_icon ); ?>"/>
							<?php } ?>
						</div>
					</div>
					<input type="text" class="wpcm_upload_background_url" name="wpcm_custom_icon" id="wpcm_custom_icon_<?php esc_attr_e( $menu_item_id ); ?>" value="<?php esc_attr_e( $wpcm_custom_icon); ?>"/>
				</div>
			</div>
			<!-- end of Menu Icon Settings -->

			<!-- Menu Background Settings -->
			<div id="tab-3" class="wpcm-tab-content">
				<div class="wpcm-popup-field wpcm_bg_image">
					<label for="wpcm_bg_image_<?php esc_attr_e( $menu_item_id ); ?>"><?php _e('Image Background','wp-circular-menu');?></label>
					<div class="wpcm-info"><?php _e('Click on icon to upload image from the library or directly insert the image URL.','wp-circular-menu');?></div>
					<input type="text" name="wpcm_bg_image" class="wpcm-custom-image-path" value="<?php esc_attr_e( $wpcm_bg_image); ?>"/>
					<button class="wpcm-meta-box-upload button-secondary"><i class="fa fa-upload" aria-hidden="true"></i></button>
					<?php
					if(!empty($wpcm_bg_image)){
						?>
						<div class="wpcm-custom-image-preview">
							<img src="<?php esc_attr_e( $wpcm_bg_image);?>"/>
						</div>	
						<?php
					}?>
				</div>
			</div>
			<!-- end of Menu Background Settings -->
			<!-- end of Notification Label Settings -->
			<div id="tab-4" class="wpcm-tab-content">
				<div class="wpcm-popup-field">
					<label for="wpcm_notification_text_<?php esc_attr_e( $menu_item_id ); ?>"><?php _e('Notification Text','wp-circular-menu');?></label>
					<input type="text" id="wpcm_notification_text_<?php esc_attr_e( $menu_item_id ); ?>" name="wpcm_notification_text" value="<?php esc_attr_e( $wpcm_notification_text); ?>">	
				</div>	
			</div>
		</div>
		<div class="wpcm-nav-menu-footer major-publishing-actions publishing-action">
			<div>
				<input type="submit" class="button button-primary button-large menu-save" value="<?php esc_attr_e( 'Save', 'wp-circular-menu' ); ?>"/>
				<button class="button button-primary button-large wpcm_close_btn"><?php esc_attr_e( 'Close after Save', 'wp-circular-menu' ); ?></button><div class="wpcm-spinner spinner" style="float:none;"></div>
			</div>
		</div>
	</form>
</div>