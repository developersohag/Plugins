<?php
/* WP Circular Menu -  Shortcode*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

include(WPCM_PATH . '/inc/frontend/wpcm-walker-class.php');
$query = new WP_Query( array('post_type' => 'wpcm_menu', 'posts_per_page' => 1 )); 
if ( $query->have_posts() ) : 
	while ( $query->have_posts() ) : 
		$query->the_post(); 

		$postid = get_the_ID(); 
	endwhile;
	wp_reset_postdata();

	$wpcm_shortcode_atts = shortcode_atts( array(
	'id' => $postid
	), $attr );

	$postid = $wpcm_shortcode_atts['id'];
	if ( FALSE === get_post_status( $postid ) ) {
		_e( 'The given post does not exist.','wp-circular-menu' ); 
	} else {
		if( 'wpcm_menu' == get_post_type($postid )){
			$wpcm_settings = get_post_meta($postid,'_wpcm_settings');
			if(!empty($wpcm_settings)){
				$wpcm_select_menu = isset( $wpcm_settings[0]['wpcm_select_menu'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_menu'] ) : '';
				$wpcm_select_template = isset( $wpcm_settings[0]['wpcm_select_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_template'] ) : 'wpcm-template-1';
				$wpcm_position = isset( $wpcm_settings[0]['wpcm_position'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_position'] ) : 'wpcm-bottom-middle';

				/*Since 1.0.3*/
				$wpcm_keep_open = isset( $wpcm_settings[0]['wpcm_keep_open'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_keep_open'] ) : 0;
				$wpcm_hide_toggle = isset( $wpcm_settings[0]['wpcm_hide_toggle'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_hide_toggle'] ) : 0;
				$wpcm_menu_fixed = isset( $wpcm_settings[0]['wpcm_menu_fixed'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_fixed'] ) : 0;
				$wpcm_disable_draggable = isset( $wpcm_settings[0]['wpcm_disable_draggable'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_disable_draggable'] ) : 0;
				$wpcm_disable_responsive = isset( $wpcm_settings[0]['wpcm_disable_responsive'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_disable_responsive'] ) : 0;

				$wpcm_select_animation = isset( $wpcm_settings[0]['wpcm_select_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_animation'] ) : 'wpcm-animation-1';
				$wpcm_toggle_animation = isset( $wpcm_settings[0]['wpcm_toggle_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_animation'] ) : 'wpcm-toggle-animation-1';

				$wpcm_menu_center_image = isset( $wpcm_settings[0]['wpcm_menu_center_image'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_center_image'] ) : '';
				$wpcm_menu_center_url = isset( $wpcm_settings[0]['wpcm_menu_center_url'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_center_url'] ) : '';

				/*Toggle button settings*/
				$wpcm_enable_custom_toggle = isset( $wpcm_settings[0]['wpcm_enable_custom_toggle'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_toggle'] ) : '0';  
				$wpcm_toggle_icon_open_color = isset( $wpcm_settings[0]['wpcm_toggle_icon_open_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_icon_open_color'] ) : '';  
				$wpcm_toggle_icon_close_color = isset( $wpcm_settings[0]['wpcm_toggle_icon_close_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_icon_close_color'] ) : ''; 
				$wpcm_toggle_icon_hover_color = isset( $wpcm_settings[0]['wpcm_toggle_icon_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_icon_hover_color'] ) : ''; 

				$wpcm_toggle_bg_open_color = isset( $wpcm_settings[0]['wpcm_toggle_bg_open_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_bg_open_color'] ) : ''; 
				$wpcm_toggle_bg_close_color = isset( $wpcm_settings[0]['wpcm_toggle_bg_close_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_bg_close_color'] ) : ''; 
				$wpcm_toggle_bg_hover_color = isset( $wpcm_settings[0]['wpcm_toggle_bg_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_bg_hover_color'] ) : ''; 

				$wpcm_toggle_border_open_color = isset( $wpcm_settings[0]['wpcm_toggle_border_open_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_open_color'] ) : ''; 
				$wpcm_toggle_border_close_color = isset( $wpcm_settings[0]['wpcm_toggle_border_close_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_close_color'] ) : ''; 
				$wpcm_toggle_border_hover_color = isset( $wpcm_settings[0]['wpcm_toggle_border_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_hover_color'] ) : ''; 
				$wpcm_toggle_border_size = isset( $wpcm_settings[0]['wpcm_toggle_border_size'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_border_size'] ) : ''; 
				$wpcm_toggle_animation = isset( $wpcm_settings[0]['wpcm_toggle_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_toggle_animation'] ) : 'wpcm-toggle-animation-1';


				/*Menu items*/
				$wpcm_enable_custom_menu = isset( $wpcm_settings[0]['wpcm_enable_custom_menu'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_menu'] ) : '0';  
				$wpcm_menu_item_icon_color = isset( $wpcm_settings[0]['wpcm_menu_item_icon_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_icon_color'] ) : '';  
				$wpcm_menu_item_icon_active_color = isset( $wpcm_settings[0]['wpcm_menu_item_icon_active_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_icon_active_color'] ) : ''; 
				$wpcm_menu_item_icon_hover_color = isset( $wpcm_settings[0]['wpcm_menu_item_icon_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_icon_hover_color'] ) : ''; 

				$wpcm_menu_item_bg_color = isset( $wpcm_settings[0]['wpcm_menu_item_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_bg_color'] ) : ''; 
				$wpcm_menu_item_bg_active_color = isset( $wpcm_settings[0]['wpcm_menu_item_bg_active_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_bg_active_color'] ) : ''; 
				$wpcm_menu_item_bg_hover_color = isset( $wpcm_settings[0]['wpcm_menu_item_bg_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_bg_hover_color'] ) : ''; 

				$wpcm_menu_item_border_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_color'] ) : ''; 
				$wpcm_menu_item_border_active_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_active_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_active_color'] ) : ''; 
				$wpcm_menu_item_border_hover_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_hover_color'] ) : '';

				$wpcm_menu_center_image = isset( $wpcm_settings[0]['wpcm_menu_center_image'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_center_image'] ) : '';
				$wpcm_menu_bg_color = isset( $wpcm_settings[0]['wpcm_menu_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_bg_color'] ) : '';

				/*Notification Label*/
				$wpcm_enable_custom_notification = isset( $wpcm_settings[0]['wpcm_enable_custom_notification'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_notification'] ) : '0';  
				$wpcm_label_color = isset( $wpcm_settings[0]['wpcm_label_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_color'] ) : ''; 
				$wpcm_label_bg_color = isset( $wpcm_settings[0]['wpcm_label_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_bg_color'] ) : ''; 
				$wpcm_label_animation = isset( $wpcm_settings[0]['wpcm_label_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_animation'] ) : ''; 
				$wpcm_label_template = isset( $wpcm_settings[0]['wpcm_label_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_template'] ) : ''; 

				/*Tooltip*/
				$wpcm_enable_custom_tooltip = isset( $wpcm_settings[0]['wpcm_enable_custom_tooltip'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_tooltip'] ) : '0';  
				$wpcm_tooltip_color = isset( $wpcm_settings[0]['wpcm_tooltip_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_tooltip_color'] ) : ''; 
				$wpcm_tooltip_bg_color = isset( $wpcm_settings[0]['wpcm_tooltip_bg_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_tooltip_bg_color'] ) : ''; 

				/*Text Settings*/
				$wpcm_enable_custom_typo = isset( $wpcm_settings[0]['wpcm_enable_custom_typo'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_typo'] ) : '0'; 
				$wpcm_font_family = isset( $wpcm_settings[0]['wpcm_font_family'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_font_family'] ) : ''; 
				$wpcm_text_transform = isset( $wpcm_settings[0]['wpcm_text_transform'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_text_transform'] ) : '';

				$wpcm_permission = isset( $wpcm_settings[0]['wpcm_permission'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_permission'] ) : 'wpcm_everyone';
				$wpcm_front_pages = isset( $wpcm_settings[0]['wpcm_front_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_front_pages'] ) : '0';
				$wpcm_blog_pages  = isset( $wpcm_settings[0]['wpcm_blog_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_blog_pages'] ) : '0';
				$wpcm_archive_pages = isset( $wpcm_settings[0]['wpcm_archive_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_archive_pages'] ) : '0';
				$wpcm_404_pages   = isset( $wpcm_settings[0]['wpcm_404_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_404_pages'] ) : '0';
				$wpcm_search_pages = isset( $wpcm_settings[0]['wpcm_search_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_search_pages'] ) : '0';
				$wpcm_single_pages = isset( $wpcm_settings[0]['wpcm_single_pages'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_single_pages'] ) : '0';
				$wpcm_custom_terms_obj = isset( $wpcm_settings[0]['wpcm_custom_terms'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_custom_terms'] ) : '';
				$wpcm_specific_pages = get_post_meta($postid,'_wpcm_specific_pages');

				$wpcm_enable_custom_css = isset( $wpcm_settings[0]['wpcm_enable_custom_css'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_enable_custom_css'] ) : '0';
				$wpcm_custom_css = isset( $wpcm_settings[0]['wpcm_custom_css'] ) ? wp_kses_post( $wpcm_settings[0]['wpcm_custom_css'] ) : '';

				/*Permission Settings*/
				$wpcm_permission = isset( $wpcm_settings[0]['wpcm_permission'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_permission'] ) : 'wpcm_everyone';
				$wpcm_user_roles = isset( $wpcm_settings[0]['wpcm_user_roles'] ) ? $wpcm_settings[0]['wpcm_user_roles']  : array();

				if($wpcm_permission == 'wpcm_loggedin'){
					if(!is_user_logged_in())
						return;
					
					$wpcm_current_user = get_current_user_id();
					$wpcm_current_user_roles = new WP_User( $wpcm_current_user );
					if ( !empty( $wpcm_current_user_roles->roles ) && is_array( $wpcm_current_user_roles->roles ) ) {
					foreach ( $wpcm_current_user_roles->roles as $role )
						$wpcm_current_user_role[] = $role;
						
					}

					$wpcm_permission_flag = 0;
					foreach ( $wpcm_current_user_role as $user_role ) {
						
						if(!empty($wpcm_user_roles) && is_array($wpcm_user_roles)){
							if ( (in_array( $user_role, $wpcm_user_roles))) {
								$wpcm_permission_flag++;
							}	
						}
						
					}
					if($wpcm_permission_flag!=0){
						return;
					}
					
				}

				if($wpcm_permission == 'wpcm_loggedout'){
					if(is_user_logged_in())
						return;
				}

				for($i=1;$i<6;$i++){
					$wpcm_draggable_templates[] = 'wpcm-template-'.$i;	
				}
				//$this->print_array($wpcm_draggable_templates);
				if(in_array($wpcm_select_template, $wpcm_draggable_templates)){
					if($wpcm_disable_draggable){
						$wpcm_position = '';	
					}else{
						$wpcm_position = 'wpcm-draggable';
					}
				}else{
					$wpcm_position = $wpcm_position;
				}

				/*Since 1.0.3*/
				$edfm_open_menu = '';
				$edfm_open_toggle = '';
				if($wpcm_keep_open && !($wpcm_select_template == 'wpcm-template-6' || $wpcm_select_template == 'wpcm-template-7' || $wpcm_select_template == 'wpcm-template-8' || $wpcm_select_template == 'wpcm-template-9')){
					$edfm_open_menu = 'wpcm-menu-active';
					$edfm_open_toggle = 'wpcm-toggle-active';
				}

				$menu_object = wp_get_nav_menu_object($wpcm_select_menu) ;
				if(!empty($menu_object)){
					/*$this->print_array($menu_object);*/
					$menu_slug = $menu_object->slug ;
					$menu_id = $menu_object->term_id ;
					$menu_item_count =  $menu_object->count;
					
					
					?>
					<div class="wpcm-shortcode-wrapper">
					<div class="wpcm-circular-menu-wrapper wpcm-wrapper-<?php _e($postid.' '.$wpcm_position.' '.$wpcm_select_template);?>">
						<?php if($wpcm_select_template == 'wpcm-template-6' || $wpcm_select_template == 'wpcm-template-7' || $wpcm_select_template == 'wpcm-template-8' || $wpcm_select_template == 'wpcm-template-9'):?>
							<div class="wpcm-toggle-wrapper <?php esc_attr_e($wpcm_toggle_animation);?>">
								<div class="wpcm-toggle-bar"></div>
								<div class="wpcm-toggle-bar"></div>
								<div class="wpcm-toggle-bar"></div>
							</div>
							<?php if($wpcm_select_template == 'wpcm-template-7'):?>
								<div class="wpcm-trigger wpcm-rotate-0">
								</div>
								<?php
							endif;
						endif;
						?>
						<div class="<?php esc_attr_e($wpcm_select_template.' '.$edfm_open_menu.' '.$wpcm_select_animation.' '.$wpcm_position.' wpcm-circular-menu wpcm-'.$menu_slug.'-container wpcm-rotate-0 wpcm-'.$postid); ?>" data-number="<?php esc_attr_e($menu_item_count);?>">

							<?php 
							if(!($wpcm_select_template == 'wpcm-template-7')):
								if($wpcm_select_template == 'wpcm-template-1' || $wpcm_select_template == 'wpcm-template-4' || $wpcm_select_template == 'wpcm-template-8' ):
									if($wpcm_select_template == 'wpcm-template-1'):
										if(!empty($wpcm_menu_center_url)):
											?><a href="<?php esc_attr_e($wpcm_menu_center_url);?>"><?php
										endif;
									endif;
									?>
									<div class="wpcm-toggle-outer-wrapper <?php if(!empty($wpcm_menu_center_image) || ($wpcm_select_template == 'wpcm-template-4')){_e('wpcm_has_bg_image');} ?>" <?php if(!empty($wpcm_menu_center_image) && $wpcm_enable_custom_menu==1) _e('style="background-image:url('.$wpcm_menu_center_image.');"');?>>
									</div>
									<?php
									if($wpcm_select_template == 'wpcm-template-1'):
										if(!empty($wpcm_menu_center_url)):
											?></a><?php
										endif;
									endif;
									?>
								<?php endif;
								if(($wpcm_select_template == 'wpcm-template-1' || $wpcm_select_template == 'wpcm-template-2' || $wpcm_select_template == 'wpcm-template-3' || $wpcm_select_template == 'wpcm-template-4' || $wpcm_select_template == 'wpcm-template-5') && !$wpcm_hide_toggle):?>
								<div class="wpcm-toggle-wrapper <?php esc_attr_e($wpcm_toggle_animation.' '.$edfm_open_toggle);?>">
									<div class="wpcm-toggle-bar"></div>
									<div class="wpcm-toggle-bar"></div>
									<div class="wpcm-toggle-bar"></div>
								</div>
								<?php
							endif;
							endif;

							$args = array(
								'menu' => $menu_slug,
								'container' => 'div',
								'container_class' => '',
								'container_id' => 'efcm-'.$postid,
								'menu_id'=>'wpcm-'.$menu_slug,
								'menu_class' => 'wpcm-menu',
								'echo' => true,
								'fallback_cb' => 'wp_page_menu',
								'before' => '',
								'after' => '',
								'link_before' => '',
								'link_after' => '',
								'items_wrap' => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
								'depth' => 1,
								'walker' => new Walker_WPCM_Class()
							);
							wp_nav_menu( $args );

							/*Custom Settings CSS*/
							include(WPCM_PATH . '/inc/frontend/wpcm-frontend-style.php');

							/*Custom CSS*/
							if($wpcm_enable_custom_css){
								?>
								<style>
									<?php _e($wpcm_custom_css);?>		
								</style>
								<?php
							}
							?>
						</div>
					</div>
					</div>
					<?php

				}
			}
		}
	}
else : 
	_e( 'No menus have been created.','wp-circular-menu' ); 
endif; 


