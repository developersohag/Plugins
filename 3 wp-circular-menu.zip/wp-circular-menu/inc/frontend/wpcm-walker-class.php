<?php
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/*
 * Eight Degree extended Walker Class
 */

if ( !class_exists( 'Walker_WPCM_Class' ) ) {


	class Walker_WPCM_Class extends Walker_Nav_Menu {
		/* 
		 * WP Circular Menu - Modify <ul> in wp_menu
		 */

		var $counter = 0;
		function start_lvl( &$output, $depth = 0, $arg = array() ) {

			$indent = str_repeat( "\t", $depth );
			$submenu = ($depth >= 0) ? 'sub-menu' : '';
			$output .= "\n$indent<ul class=\"wpcm-dropdown-$submenu wpcm_depth_$depth\">\n";
		}

		function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
			$post_id[] = $args->container_id;
			$postid[] = explode('-', $post_id[0]);
			$postID = isset($postid[0][1])?trim($postid[0][1]):'';
			
			$wpcm_settings = get_post_meta($postID,'_wpcm_settings'); 
			/*$this->print_array($wpcm_settings[0]['wpcm_label_template']);*/
			$wpcm_select_template = isset( $wpcm_settings[0]['wpcm_select_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_template'] ) : 'wpcm-template-1';

			/*Limit numbe rof items on template 9*/
			$limit_reached = 0;

			if($wpcm_select_template == 'wpcm-template-9'){
				$counter = $this->counter;
				$counter++;

				if($counter > 8){
					$limit_reached = 1;
				}
				$this->counter = $counter;
			}

			if(!$limit_reached ){
				if($item->post_type == 'nav_menu_item'){
				$wpcm_item_settings = get_post_meta( $item->ID, '_wpcmItemSettings' );
				/*$this->print_array($wpcm_item_settings);*/

				$wpcm_popup_show_title = isset( $wpcm_item_settings['0']['wpcm_popup_show_title'] ) ? sanitize_text_field( $wpcm_item_settings['0']['wpcm_popup_show_title'] ) : '0';
				$wpcm_tooltip_text = isset( $wpcm_item_settings['0']['wpcm_tooltip_text'] ) ? sanitize_text_field( $wpcm_item_settings['0']['wpcm_tooltip_text'] ) : '';
				$wpcm_icon_type = isset( $wpcm_item_settings['0']['wpcm_icon_type'] ) ? sanitize_text_field( $wpcm_item_settings['0']['wpcm_icon_type'] ) : 'wpcm_none';
				$wpcm_font_icon = isset( $wpcm_item_settings['0']['wpcm_font_icon'] ) ? sanitize_text_field( $wpcm_item_settings['0']['wpcm_font_icon'] ) : '';
				$wpcm_custom_icon = isset( $wpcm_item_settings['0']['wpcm_custom_icon'] ) ? sanitize_text_field( $wpcm_item_settings['0']['wpcm_custom_icon'] ) : '';
				$wpcm_notification_text = isset( $wpcm_item_settings['0']['wpcm_notification_text'] ) ? sanitize_text_field( $wpcm_item_settings['0']['wpcm_notification_text'] ) : '';
				$wpcm_notification_animation = isset( $wpcm_settings[0]['wpcm_label_animation'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_animation'] ) : 'wpcm_label_animation_1';
				$wpcm_notification_template = isset( $wpcm_settings[0]['wpcm_label_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_label_template'] ) : 'wpcm_label_template_1'; 
				
				$wpcm_bg_image = '';
				$wpcm_has_bg_image = '';
				if(!($wpcm_select_template == 'wpcm-template-3' || $wpcm_select_template == 'wpcm-template-4' || $wpcm_select_template == 'wpcm-template-5')){
					$wpcm_bg_image = isset( $wpcm_item_settings['0']['wpcm_bg_image'] ) ? sanitize_text_field( $wpcm_item_settings['0']['wpcm_bg_image'] ) : '';
					if(!empty($wpcm_bg_image)){
						$wpcm_has_bg_image = 'wpcm_has_bg_image';	
					}
					
				}
				

				$indent = ($depth) ? str_repeat( "\t", $depth ) : '';
				$li_attributes = '';
				$class_names = $value = '';
				$classes = empty( $item->classes ) ? array() : (array) $item->classes;
				$classes[] = ($args->walker->has_children) ? 'wpcm-dropdown' : '';
				$classes[] = ($item->current || $item->current_item_anchestor) ? 'wpcm-active' : '';
				$classes[] = 'wpcm-menu-item-' . $item->ID;
				if ( $depth && $args->walker->has_children ) {
					$classes[] = 'wpcm-dropdown-submenu';
				}
				$class_names = join( ' ', apply_filters( 'wpcm_nav_menu_css_class', array_filter( $classes ), $item, $args ) );
				$class_names = ' class="' . esc_attr( $class_names ) . '"';
				$id = apply_filters( 'wpcm_nav_menu_item_id', 'wpcm-menu-item-' . $item->ID, $item, $args );
				$id = strlen( $id ) ? 'id="' . esc_attr( $id ) . '"' : '';
				$output .= $indent . '<li ' . $id . $value . $class_names . $li_attributes . '>';

				$attributes = !empty( $item->attr_title ) ? ' title="' . esc_attr( $item->attr_title ) . '"' : '';
				$attributes .= !empty( $item->target ) ? ' target="' . esc_attr( $item->target ) . '"' : '';
				$attributes .= !empty( $item->xfn ) ? ' rel="' . esc_attr( $item->xfn ) . '"' : '';
				$attributes .= !empty( $item->url ) ? ' href="' . esc_attr( $item->url ) . '"' : '';
				$attributes .= ( $args->walker->has_children ) ? ' class="wpcm-dropdown-toggle wpcm-menu-link '.$wpcm_has_bg_image.'"' : 'class="wpcm-menu-link '.$wpcm_has_bg_image.'"';
				
				if(!($wpcm_select_template == 'wpcm-template-3' || $wpcm_select_template == 'wpcm-template-4' || $wpcm_select_template == 'wpcm-template-5')){
					$attributes .= (!empty($wpcm_bg_image)) ? ' style="background-image:url('.$wpcm_bg_image.');" ' : '';
				}
				$item_output = $args->before;


				$item_output .= '<a' . $attributes . '>';

				/*Menu Icon*/
				switch($wpcm_icon_type){
					case 'wpcm_font_icon':
					$v = explode( '|', $wpcm_font_icon);		
					if(isset($v[1]) && !empty($v)){
						$item_output .= '<i class="wpcm-icon '.$v[0] . ' ' . $v[1].'"></i>';	
					}
					break;
					case 'wpcm_custom_icon':
					$item_output .= '<div class="wpcm-icon-image"><img src="'.$wpcm_custom_icon.'"/></div>';
					break;
				}

				/*Menu Name*/
				/*if($wpcm_select_template == 'wpcm-template-9'){
					if($wpcm_popup_show_title == '0'){
						$item_output .= '<span class="wpcm-title" data-hover="'.$item->title.'">';
						$item_output .= $args->link_before . apply_filters( 'wpcm_the_title', $item->title, $item->ID ) . $args->link_after;
						$item_output .= '</span>';	
					}

				}*/
				
				/*Tooltip*/
				if($wpcm_popup_show_title == '0'){
					$item_output .= !empty($wpcm_tooltip_text)?'<span class="wpcm-tooltip">'.$wpcm_tooltip_text.'</span>':'<span class="wpcm-tooltip">'.apply_filters( 'wpcm_the_title', $item->title, $item->ID ).'</span>';
				}

				/*Notification Label*/
				$item_output .= !empty($wpcm_notification_text)?'<span class="wpcm-notification-label '.$wpcm_notification_template.' '.$wpcm_notification_animation.'"><span class="wpcm-not-label-inner">'.$wpcm_notification_text:'';

				/*$item_output .= ($args->walker->has_children ) ? '<i class="wpcm-toggle-icon"></i>':'';*/
				$item_output .= '</a>';

				$item_output .= $args->after;

				
				$output .= apply_filters( 'wpcm_walker_nav_menu_start_el', $item_output, $item, $depth, $args );
				
			}
			}
		}

/* 
 * WP Circular Menu - Print Function
 */
function print_array( $array ) {
	echo "<pre>";
	print_r( $array );
	echo "</pre>";
}

}

	// End of Class
}// End of If



