<?php
/* 
 * WP Circular Menu - Frontend Dynamic CSS
 */
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/*Template 7 Arrow*/
$wpcm_menu_arrow_color = isset( $wpcm_settings[0]['wpcm_menu_arrow_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_arrow_color'] ) : '';
$wpcm_menu_arrow_hover_color = isset( $wpcm_settings[0]['wpcm_menu_arrow_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_arrow_hover_color'] ) : '';

/*Menu items*/

$wpcm_menu_item_border_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_color'] ) : ''; 
$wpcm_menu_item_border_active_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_active_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_active_color'] ) : ''; 
$wpcm_menu_item_border_hover_color = isset( $wpcm_settings[0]['wpcm_menu_item_border_hover_color'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_item_border_hover_color'] ) : '';

/*Text Settings*/
/*Font saved format 
	$wpcm_font_family : Fira Sans=cyrillic=900italic 
*/
$wpcm_font_family_array = explode("=",$wpcm_font_family);
/*
	$wpcm_font_family_array = array(
	    [0] => Fira Sans
	    [1] => cyrillic
	    [2] => 900italic
	)
	OR
	$wpcm_font_family_array = array(
		[0] => Fira Sans
	    [1] => cyrillic
	    [2] => regular
	)
*/
/*Adding + inplace of space in font family name to make format Fira+Sans*/
$wpcm_font_name= $wpcm_font_family_array[0];

$wpcm_font_name1 = preg_replace('/\s+/', '+', $wpcm_font_name);

$wpcm_font_subset= $wpcm_font_family_array[1];

$wpcm_font_variant= $wpcm_font_family_array[2];

$font_query = '<link href="https://fonts.googleapis.com/css?family='.$wpcm_font_name1.':'.$wpcm_font_variant.'&amp;subset='.$wpcm_font_subset.'" rel="stylesheet">';
/*
	echo $font_query;
	<link href="https://fonts.googleapis.com/css?family=Fira+Sans:regular&amp;subset=cyrillic" rel="stylesheet">
*/
$font_query = str_replace(':regular','',$font_query);
$font_query = str_replace('italic','i',$font_query);
/*
	<link href="https://fonts.googleapis.com/css?family=Fira+Sans&amp;subset=cyrillic" rel="stylesheet">
	or
	<link href="https://fonts.googleapis.com/css?family=Fira+Sans:700i&amp;subset=cyrillic" rel="stylesheet">
*/
_e($font_query);

$font_family_string = '"'.$wpcm_font_name.'",'.$wpcm_font_subset;

?>

<style>
	<?php 
	/*Hide is mobile*/
	if($wpcm_disable_responsive):
		?>
		@media screen and (max-width: 600px) {
			.wpcm-<?php _e($postid);?>.wpcm-circular-menu,
			.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper {
				display: none !important;
			}
		}
		<?php
	endif;
	/*Toggle Button Setting*/
	if($wpcm_enable_custom_toggle):
		?>
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper {
			background: <?php _e($wpcm_toggle_bg_close_color); ?>;
			border: <?php echo $wpcm_toggle_border_size.'px solid '. $wpcm_toggle_border_close_color; ?>;
		}
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper:hover,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper:hover,
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-active:hover,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-active:hover {
			background:<?php _e($wpcm_toggle_bg_hover_color); ?>;
			border: <?php echo $wpcm_toggle_border_size.'px solid '. $wpcm_toggle_border_hover_color ?>;
		}
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-active,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-active {
			background:<?php _e($wpcm_toggle_bg_open_color); ?>;
			border: <?php echo $wpcm_toggle_border_size.'px solid '. $wpcm_toggle_border_open_color ?>;
		}
		.wpcm-<?php _e($postid);?> .wpcm-toggle-animation-1.wpcm-toggle-wrapper.wpcm-toggle-active .wpcm-toggle-bar,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-animation-1.wpcm-toggle-wrapper.wpcm-toggle-active .wpcm-toggle-bar, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-2.wpcm-toggle-active .wpcm-toggle-bar:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-2.wpcm-toggle-active .wpcm-toggle-bar:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-2.wpcm-toggle-active .wpcm-toggle-bar:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-2.wpcm-toggle-active .wpcm-toggle-bar:after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:first-child, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:first-child, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:nth-child(3), 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:nth-child(3), 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:nth-child(2):before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:nth-child(2):after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:nth-child(2):before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3.wpcm-toggle-active .wpcm-toggle-bar:nth-child(2):after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-4.wpcm-toggle-active .wpcm-toggle-bar, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-4.wpcm-toggle-active .wpcm-toggle-bar, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:nth-child(2), 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:nth-child(2), 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:first-child:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:first-child:after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:last-child:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:last-child:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:first-child:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:first-child:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:last-child:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5.wpcm-toggle-active .wpcm-toggle-bar:last-child:after{
			background-color: <?php _e($wpcm_toggle_icon_open_color); ?>;
		}

		.wpcm-<?php _e($postid);?> .wpcm-toggle-animation-1.wpcm-toggle-wrapper .wpcm-toggle-bar,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-animation-1.wpcm-toggle-wrapper .wpcm-toggle-bar, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-2 .wpcm-toggle-bar:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-2 .wpcm-toggle-bar:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-2 .wpcm-toggle-bar:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-2 .wpcm-toggle-bar:after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:first-child, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:first-child, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:nth-child(3), 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:nth-child(3), 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:nth-child(2):before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:nth-child(2):after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:nth-child(2):before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3 .wpcm-toggle-bar:nth-child(2):after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-4 .wpcm-toggle-bar, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-4 .wpcm-toggle-bar, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:nth-child(2), 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:nth-child(2), 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:first-child:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:first-child:after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:last-child:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:last-child:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:first-child:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:first-child:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:last-child:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5 .wpcm-toggle-bar:last-child:after{
			background-color: <?php _e($wpcm_toggle_icon_close_color); ?>;
		}

		.wpcm-<?php _e($postid);?> .wpcm-toggle-animation-1.wpcm-toggle-wrapper:hover .wpcm-toggle-bar,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-animation-1.wpcm-toggle-wrapper:hover .wpcm-toggle-bar,
		.wpcm-<?php _e($postid);?> .wpcm-toggle-animation-1.wpcm-toggle-wrapper:hover .wpcm-toggle-bar,
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-animation-1.wpcm-toggle-wrapper:hover .wpcm-toggle-bar, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-2:hover .wpcm-toggle-bar:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-2:hover .wpcm-toggle-bar:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-2:hover .wpcm-toggle-bar:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-2:hover .wpcm-toggle-bar:after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:first-child, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:first-child, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:nth-child(3), 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:nth-child(3), 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:nth-child(2):before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:nth-child(2):after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:nth-child(2):before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-3:hover .wpcm-toggle-bar:nth-child(2):after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-4:hover .wpcm-toggle-bar, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-4:hover .wpcm-toggle-bar, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:nth-child(2), 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:nth-child(2), 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:first-child:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:first-child:after, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:last-child:before, 
		.wpcm-<?php _e($postid);?> .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:last-child:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:first-child:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:first-child:after, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:last-child:before, 
		.wpcm-wrapper-<?php _e($postid);?>.wpcm-circular-menu-wrapper .wpcm-toggle-wrapper.wpcm-toggle-animation-5:hover .wpcm-toggle-bar:last-child:after{
			background-color: <?php _e($wpcm_toggle_icon_hover_color); ?>;
		}
		<?php 
	endif;

	/*Menu Button Setting*/
	if($wpcm_enable_custom_menu):
		?>
		.wpcm-wrapper-<?php _e($postid);?> .wpcm-trigger{
			color:<?php _e($wpcm_menu_arrow_color); ?>;
		}
		.wpcm-wrapper-<?php _e($postid);?> .wpcm-trigger:hover{
			color:<?php _e($wpcm_menu_arrow_hover_color); ?>;
		}
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a{
			color: <?php _e($wpcm_menu_item_icon_color); ?>; 
			background-color: <?php _e($wpcm_menu_item_bg_color); ?>; 
			
		}	

		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li.wpcm-active a:hover{
			color: <?php _e($wpcm_menu_item_icon_hover_color); ?>; 
			background-color: <?php _e($wpcm_menu_item_bg_hover_color); ?>; 
			
		}

		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a:active,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li.wpcm-active a,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li.wpcm-active a:active{
			color: <?php _e($wpcm_menu_item_icon_active_color); ?>; 
			background-color: <?php _e($wpcm_menu_item_bg_active_color); ?>; 
			
		}
		.wpcm-<?php _e($postid);?> .wpcm-toggle-outer-wrapper,
		.wpcm-<?php _e($postid);?> .wpcm-toggle-outer-wrapper:before{
			background-color: <?php _e($wpcm_menu_bg_color); ?>; 
		}

		/*Border Color Template 2, Template 9*/
		.wpcm-<?php _e($postid);?>.wpcm-template-2 ul li a,
		.wpcm-<?php _e($postid);?>.wpcm-template-9 ul li a{
			border: 3px solid <?php _e($wpcm_menu_item_border_color); ?>;
		}

		.wpcm-<?php _e($postid);?>.wpcm-template-2 ul li.wpcm-active a,
		.wpcm-<?php _e($postid);?>.wpcm-template-9 ul li.wpcm-active a{
			border: 3px solid <?php _e($wpcm_menu_item_border_active_color); ?>;
		}

		.wpcm-<?php _e($postid);?>.wpcm-template-2 ul li a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-template-2 ul li.wpcm-active a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-template-9 ul li a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-template-9 ul li.wpcm-active a:hover{
			border: 3px solid <?php _e($wpcm_menu_item_border_hover_color); ?>;
		}

		


		/*Template 3*/
		.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li a{
			background: radial-gradient(transparent 40%, <?php _e($wpcm_menu_item_bg_color); ?> 40%); 
			border: 3px solid <?php _e($wpcm_menu_item_border_color); ?>;
		}
		.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li.wpcm-active a:hover{
			background: radial-gradient(transparent 40%, <?php _e($wpcm_menu_item_bg_hover_color); ?> 40%); 
			border: 3px solid <?php _e($wpcm_menu_item_border_hover_color); ?>;
		}
		.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li a:active,
		.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li.wpcm-active a,
		.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li.wpcm-active a:active{
			background: radial-gradient(transparent 40%, <?php _e($wpcm_menu_item_bg_active_color); ?> 40%); 
			border: 3px solid <?php _e($wpcm_menu_item_border_active_color); ?>;
		}

		@media screen and (max-width: 600px) {
			.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li a{
				background: radial-gradient(transparent 40%, <?php _e($wpcm_menu_item_bg_color); ?>;  40%);
			}
			.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li a:hover,
			.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li.wpcm-active a:hover{
				background: radial-gradient(transparent 40%, <?php _e($wpcm_menu_item_bg_hover_color); ?>;  40%);
			}
			.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li a:active, 
			.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li.wpcm-active a, 
			.wpcm-<?php _e($postid);?>.wpcm-template-3 ul li.wpcm-active a:active {
				background: radial-gradient(transparent 40%, <?php _e($wpcm_menu_item_bg_active_color); ?>;  40%);
			}
		}

		/*Template 4,5*/
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-4 ul li a,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-4 ul li a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-4 ul li.wpcm-active a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-4 ul li a:active,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-4 ul li.wpcm-active a,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-4 ul li.wpcm-active a:active,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-5 ul li a,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-5 ul li a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-5 ul li.wpcm-active a:hover,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-5 ul li a:active,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-5 ul li.wpcm-active a,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-5 ul li.wpcm-active a:active{
			background-color: transparent;
		}
		<?php 
	endif;

	/*Notification Setting*/
	if($wpcm_enable_custom_notification):
		?>
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a span.wpcm-notification-label{
			color: <?php _e($wpcm_label_color); ?>; 
		}
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a span.wpcm-notification-label span {
			background-color: <?php _e($wpcm_label_bg_color); ?>; 
		}
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a span.wpcm-notification-label.wpcm_label_template_1 span:before,
		.wpcm-<?php _e($postid);?>.wpcm-template-2 span.wpcm-notification-label.wpcm_label_template_1 span:after{
			border-top-color: <?php _e($wpcm_label_bg_color); ?>; 
		}
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a span.wpcm-notification-label.wpcm_label_template_5 span:before, 
		.wpcm-circular-menu.wpcm-template-1 ul li:nth-child(3) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1 ul li:nth-child(4) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-12 ul li:nth-child(3) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-12 ul li:nth-child(4) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-12 ul li:nth-child(9) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-12 ul li:nth-child(10) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-12 ul li:nth-child(11) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-2 ul li:nth-child(2) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-3 ul li:nth-child(2) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-5 ul li:nth-child(5) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-6 ul li:nth-child(3) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-6 ul li:nth-child(4) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-6 ul li:nth-child(5) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-6 ul li:nth-child(6) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-7 ul li:nth-child(6) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-7 ul li:nth-child(7) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-8 ul li:nth-child(6) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-8 ul li:nth-child(7) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-8 ul li:nth-child(8) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-9 ul li:nth-child(7) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-10 ul li:nth-child(8) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-10 ul li:nth-child(9) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-10 ul li:nth-child(10) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-11 ul li:nth-child(8) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-11 ul li:nth-child(9) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-11 ul li:nth-child(10) a span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-circular-menu.wpcm-template-1.wpcm-item-count-11 ul li:nth-child(11) a span.wpcm-notification-label.wpcm_label_template_5 span:before, 
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(3) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-4 ul li:nth-child(4) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-5 ul li:nth-child(4) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-5 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-6 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-6 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-7 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-7 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-7 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-8 ul li:first-child span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-8 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-8 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-8 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-9 ul li:first-child span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-9 ul li:nth-child(2) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-9 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-9 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-9 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-9 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-10 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-10 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-10 ul li:nth-child(10) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-11 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-11 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-11 ul li:nth-child(10) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-11 ul li:nth-child(11) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-12 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-12 ul li:nth-child(10) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-12 ul li:nth-child(11) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-3.wpcm-item-count-12 ul li:nth-child(12) span.wpcm-notification-label.wpcm_label_template_5 span:before, 
		.wpcm-template-4 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-7 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-7 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-8 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-8 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-8 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-8 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-8 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-8 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-9 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-9 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-9 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-9 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-9 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-9 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-10 ul li span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-10 ul li span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-10 ul li:nth-child(4) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-10 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-10 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-10 ul li:nth-child(4) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-10 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-10 ul li:nth-child(6) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-11 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-11 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-11 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-11 ul li:nth-child(10) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-11 ul li:nth-child(11) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-11 ul li:nth-child(7) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-11 ul li:nth-child(8) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-11 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-11 ul li:nth-child(10) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-11 ul li:nth-child(11) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-12 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-12 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-12 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-12 ul li:nth-child(10) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-12 ul li:nth-child(11) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-4.wpcm-item-count-12 ul li:nth-child(12) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-12 ul li:nth-child(9) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-12 ul li:nth-child(10) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-12 ul li:nth-child(11) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-12 ul li:nth-child(12) span.wpcm-notification-label.wpcm_label_template_5 span:before, .wpcm-template-5.wpcm-item-count-11 ul li:nth-child(5) span.wpcm-notification-label.wpcm_label_template_5 span:before, 
		.wpcm-top-left .wpcm-template-7 ul li span.wpcm-notification-label span:before {
			border-right-color: <?php _e($wpcm_label_bg_color); ?>; 
		} 
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a span.wpcm-notification-label.wpcm_label_template_5 span:after, 
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-9 ul li span.wpcm-notification-label span:before, 
		.wpcm-<?php _e($postid);?>.wpcm-template-7 ul li span.wpcm-notification-label span:before{
			border-left-color: <?php _e($wpcm_label_bg_color); ?>; 
		}
		<?php 
	endif;

	/*Tooltip Setting*/
	if($wpcm_enable_custom_tooltip):
		?>
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu ul li a span.wpcm-tooltip{
			color: <?php _e($wpcm_tooltip_color); ?>; 
			background-color: <?php _e($wpcm_tooltip_bg_color); ?>; 
		}
		.wpcm-circular-menu ul li a span.wpcm-tooltip:before{
			border-top-color: <?php _e($wpcm_tooltip_bg_color); ?>; 
		}

		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-bottom-left ul li a span.wpcm-tooltip:before,
		.wpcm-<?php _e($postid);?>.wpcm-template-6 ul li a span.wpcm-tooltip:before,
		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-middle-left ul li a span.wpcm-tooltip:before{
			border-right-color: <?php _e($wpcm_tooltip_bg_color); ?>;
			border-top-color: transparent; 
		}
		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-top-middle ul li a span.wpcm-tooltip:before{
			border-bottom-color: <?php _e($wpcm_tooltip_bg_color); ?>;
			border-right-color: transparent;
			border-top-color: transparent;
		}
		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-bottom-middle ul li a span.wpcm-tooltip:before{
			border-bottom-color: <?php _e($wpcm_tooltip_bg_color); ?>;
			border-right-color: transparent;
			border-top-color: <?php _e($wpcm_tooltip_bg_color); ?>;
		}
		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-middle-right ul li a span.wpcm-tooltip:before, 
		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-top-right ul li a span.wpcm-tooltip:before{
			border-left-color: <?php _e($wpcm_tooltip_bg_color); ?>;
			border-right-color: transparent;
			border-top-color: transparent;
		}
		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-middle-left ul li a span.wpcm-tooltip:before{
			border-top-color: transparent;
		}
		.wpcm-<?php _e($postid);?>.wpcm-template-6.wpcm-bottom-right ul li a span.wpcm-tooltip:before{
			border-left-color: <?php _e($wpcm_tooltip_bg_color); ?>;
		}
		<?php
	endif;

	/*Font Setting*/
	if($wpcm_enable_custom_typo):
		?>
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu,
		.wpcm-<?php _e($postid);?>.wpcm-circular-menu.wpcm-template-1 ul li a span,
		.wpcm-<?php _e($postid);?>.wpcm-template-3 span.wpcm-notification-label,
		.wpcm-<?php _e($postid);?>.wpcm-template-4 ul li span.wpcm-notification-label, 
		.wpcm-<?php _e($postid);?>.wpcm-template-5 ul li span.wpcm-notification-label,
		.wpcm-<?php _e($postid);?>.wpcm-template-4 ul li a span.wpcm-tooltip, 
		.wpcm-<?php _e($postid);?>.wpcm-template-5 ul li a span.wpcm-tooltip,
		.wpcm-<?php _e($postid);?>.wpcm-template-6 ul li span.wpcm-notification-label{
			font-family: <?php _e($font_family_string); ?>; 
			text-transform: <?php _e($wpcm_text_transform); ?>;
		}
		<?php
		if ( strpos($wpcm_font_variant,'italic') !== false ) {
			?>
			.wpcm-<?php _e($postid);?>.wpcm-circular-menu{
				font-style: italic;
			}
            <?php
        }else{
        	?>
        	.wpcm-<?php _e($postid);?>.wpcm-circular-menu {
				font-style: '';
			}
			<?php
        }
		if ( strpos($wpcm_font_variant,'regular') !== false ) {
			?>
			.wpcm-<?php _e($postid);?>.wpcm-circular-menu {
				font-weight: '';
			}
            <?php
        }else{
        	?>
        	.wpcm-<?php _e($postid);?>.wpcm-circular-menu{
				font-weight: <?php _e($wpcm_font_variant); ?>; 
			}
			<?php
        }
	endif;
	?>
</style>
<?php
if( 'enfold' == get_option( 'template' ) ) {
    ?>
    <style class="wpcm-enfold-fix">
    	.wpcm-circular-menu-wrapper ul li a{
    		max-width: 180%;
    	}
    	.wpcm-template-1 .wpcm-toggle-outer-wrapper{
    		width: 180px;
    		height: 180px;
    	}
    	.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(5) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(6) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(6) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(7) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(7) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(8) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(8) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(9) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(9) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(10) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(10) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(11) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(11) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(12) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-12 ul li:nth-child(12) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(5) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(6) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(6) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(7) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(7) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(8) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(8) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(9) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(9) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(10) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(10) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(11) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-11 ul li:nth-child(11) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(5) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(6) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(6) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(7) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(7) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(8) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(8) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(9) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(9) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(10) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-10 ul li:nth-child(10) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(5) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(6) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(6) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(7) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(7) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(8) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(8) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(9) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-9 ul li:nth-child(9) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(5) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(6) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(6) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(7) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(7) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(8) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-8 ul li:nth-child(8) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(5) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(6) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(6) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(7) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-7 ul li:nth-child(7) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(5) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(6) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-6 ul li:nth-child(6) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(4) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(5) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-5 ul li:nth-child(5) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-3 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-3 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-3 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-3 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-3 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-3 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-2 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-2 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-2 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-2 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-1 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-1 ul li:nth-child(1) a .wpcm-icon
		{
		    left: 280px;
		    top: 150px;
		}
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(1) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(1) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(2) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(2) a .wpcm-icon, 
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(3) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(3) a .wpcm-icon,
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(4) a .wpcm-icon-image, 
		.wpcm-template-3.wpcm-item-count-4 ul li:nth-child(4) a .wpcm-icon
		{
			left: 250px;
			top: 50px;
		}
		.wpcm-template-3 ul li a span.wpcm-tooltip {
    		top: 154px;
    		right: -44px;
    		transform: rotate(90deg);
    		-webkit-transform: rotate(90deg);
    		-moz-transform: rotate(90deg);
		}
    </style>
    <?php
  }