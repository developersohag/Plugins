/*
WP Circular Menu
Version 1.0.1

Created on : August 15, 2017, 10:23:04 AM
Author     : AccessPress Themes
*/

jQuery(document).ready(function ($) {

    /* Custom Toggle Js */
    var wpcm_json_str = wpcm_settings.wpcm_arr.replace(/&quot;/g, '"');
    var wpcm_php_arr = jQuery.parseJSON(wpcm_json_str);
    var arr = $.map(wpcm_php_arr, function(el) { return el; });

    $.each(arr, function(index, wpcm_settings) {
        var wpcm_menu_id = wpcm_settings.wpcm_postid;
        var wpcm_initial_top = wpcm_settings.wpcm_initial_top;
        var wpcm_initial_left = wpcm_settings.wpcm_initial_left;
        var wpcm_menu_fixed = wpcm_settings.wpcm_menu_fixed;
        var wpcm_disable_draggable = wpcm_settings.wpcm_disable_draggable;
        var wpcm_select_template = wpcm_settings.wpcm_select_template;
        

        var edfm_position = 'fixed';
        if(wpcm_menu_fixed == 1){
            edfm_position = 'absolute';
        }

        if(wpcm_disable_draggable && !(wpcm_select_template == 'wpcm-template-6' || wpcm_select_template == 'wpcm-template-7' || wpcm_select_template == 'wpcm-template-8' || wpcm_select_template == 'wpcm-template-9')){
            if(wpcm_menu_fixed == 1){
                console.log('if true scroll with page: '+wpcm_menu_fixed);
                $('.wpcm-circular-menu.wpcm-'+wpcm_menu_id).css('position','absolute');
            }else{
                console.log('if false stay in one place: '+wpcm_menu_fixed);
                $('.wpcm-circular-menu.wpcm-'+wpcm_menu_id).css('position','fixed');
            }
        }
        //console.log(wpcm_initial_top);
        //console.log(wpcm_initial_left);
        //.log(wpcm_menu_id);
        var screen_width = parseInt($(window).width());
        //console.log(screen_width);
        if(screen_width > 600){
            $('.wpcm-draggable.wpcm-'+wpcm_menu_id).pep({
                useCSSTranslation: false,
                constrainTo:'window',
                start:function () {
                    dragged = true;
                },
                elementsWithInteraction: '.wpcm-toggle-wrapper,.menu-item',
                startPos: { left: parseInt(wpcm_initial_left), top: parseInt(wpcm_initial_top) }
            }).css({
                'position':edfm_position,
            });
        }
    });

    function touchHandler(event) {
        var touch = event.changedTouches[0];

        var simulatedEvent = document.createEvent("MouseEvent");
        simulatedEvent.initMouseEvent({
            touchstart: "mousedown",
            touchmove: "mousemove",
            touchend: "mouseup"
        }[event.type], true, true, window, 1,
        touch.screenX, touch.screenY,
        touch.clientX, touch.clientY, false,
        false, false, false, 0, null);

        touch.target.dispatchEvent(simulatedEvent);
    }

    function init() {
        document.addEventListener("touchstart", touchHandler, true);
        document.addEventListener("touchmove", touchHandler, true);
        document.addEventListener("touchend", touchHandler, true);
        document.addEventListener("touchcancel", touchHandler, true);  
    }

    init();

    var TheDraggable = null;
    var dragged = false;
    /*jQuery draggable*/
    /*
    $('.wpcm-draggable').draggable({
        containment: "window",
        scroll: false,
        delay: 0,
        cursorAt: { top: 150, left: 150},
        start: function () {
            dragged = true;
        }
    });
    */
    
    

    /*Menu open/close*/
    $('.wpcm-toggle-wrapper').on('click',function(e) {
        if ( dragged ) {
            dragged = false; // Reset the flag
            return;
        }
        e.stopPropagation();
        $(this).toggleClass('wpcm-toggle-active');
        $(this).parents('.wpcm-circular-menu').toggleClass('wpcm-menu-active');
        $(this).siblings('.wpcm-circular-menu').toggleClass('wpcm-menu-active');
    });

    var $menu = $('.wpcm-circular-menu');
    var $trigger = $menu.siblings('.wpcm-trigger');
/*    $(document).on('click', function (e) {
      // If element is opened and click target is outside it, hide it
      if ($menu.hasClass('wpcm-menu-active') && !$menu.is(e.target) && !$menu.has(e.target).length && !$trigger.is(e.target) && !$trigger.has(e.target).length) {
        $menu.removeClass('wpcm-menu-active');
        $menu.siblings('.wpcm-toggle-wrapper').removeClass('wpcm-toggle-active');
    }
});*/



	/*interact('.wpcm-circular-menu')
	.draggable({
            // enable inertial throwing
            inertia: true,
            // keep the element within the area of it's parent
            restrict: {
            	restriction: "body",
            	endOnly: true,
            	elementRect: { top: 0, left: 0, bottom: 1, right: 1 }
            },
            // enable autoScroll
            autoScroll: true,
            onstart: function (event) {
            	//console.log('onstart');
            },
            // call this function on every dragmove event
            onmove: dragMoveListener,
            // call this function on every dragend event
            onend: function (event) {
            	//console.log('onend');
            }
        });
	function dragMoveListener (event) {

		//console.log('dragMoveListener');
		var target = event.target,
            // keep the dragged position in the data-x/data-y attributes
            x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx,
            y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;
        // translate the element
        target.style.webkitTransform =
        target.style.transform =
        'translate(' + x + 'px, ' + y + 'px)';
        // update the position attributes
        target.setAttribute('data-x', x);
        target.setAttribute('data-y', y);
    }*/



    /*Menu items count*/
    $('.wpcm-circular-menu').each(function(){
    	var selected_menu = $(this);
    	div_count = 0;
    	selected_menu.find('ul.wpcm-menu li.menu-item').each(function(){
    		div_count++;
    	});
    	selected_menu.addClass('wpcm-item-count-'+div_count);
        selected_menu.attr('data-number',div_count);
        $(this).parent('.wpcm-circular-menu-wrapper').addClass('wpcm-item-count-'+div_count);
    });

    $('body').on('click','.wpcm-trigger',function(){
        var div_count = 0;
        $('.wpcm-template-7.wpcm-circular-menu ul.wpcm-menu li.menu-item').each(function(){
            div_count++;
        });
        var noOfItems = div_count;
        
        if($(this).parent().hasClass('wpcm-bottom-right')){
            var baseroTa = '31';
            if($(this).hasClass('wpcm-rotate-270')){
                var remCls = 'wpcm-rotate-270';
                var AdCls = 'wpcm-rotate-0';
                var roTa = baseroTa;
            }else if($(this).hasClass('wpcm-rotate-180') && noOfItems>9){
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-270';
                var roTa = parseInt(baseroTa)+270;
            }else if($(this).hasClass('wpcm-rotate-90') && noOfItems>6){
                var remCls = 'wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)+180;
            }
            else if($(this).hasClass('wpcm-rotate-0') && noOfItems>3){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-90';
                var roTa = parseInt(baseroTa)+90;
            } else{
                var remCls = 'wpcm-rotate-270';
                var remCls = 'wpcm-rotate-180';
                var remCls = 'wpcm-rotate-270 wpcm-rotate-180 wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)+90;
            }
            //console.log(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '30';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '60';
            }else if(noOfItems==6 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'-'+deCr+'=');
            roTa = parseInt(roTa) - parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate(-'+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate(-'+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate(-'+roTa+'deg)');

        }
        else if($(this).parent().hasClass('wpcm-bottom-left')){
            var baseroTa = '59';
            if($(this).hasClass('wpcm-rotate-270')){
                var remCls = 'wpcm-rotate-270';
                var AdCls = 'wpcm-rotate-0';
                var roTa = baseroTa;
            }else if($(this).hasClass('wpcm-rotate-180') && noOfItems>9){
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-270';
                var roTa = parseInt(baseroTa)-270;
            }else if($(this).hasClass('wpcm-rotate-90') && noOfItems>6){
                var remCls = 'wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)-180;
            }
            else if($(this).hasClass('wpcm-rotate-0') && noOfItems>3){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-90';
                var roTa = parseInt(baseroTa)-90;
            } else{
                var remCls = 'wpcm-rotate-270';
                var remCls = 'wpcm-rotate-180';
                var remCls = 'wpcm-rotate-270 wpcm-rotate-180 wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)-90;
            }
            //alert(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '30';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '60';
            }else if(noOfItems==6 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'+'+deCr+'=');
            roTa = parseInt(roTa) + parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate('+roTa+'deg)');

        }
        else if($(this).parent().hasClass('wpcm-top-left')){
            var baseroTa = '-210';
            if($(this).hasClass('wpcm-rotate-270')){
                var remCls = 'wpcm-rotate-270';
                var AdCls = 'wpcm-rotate-0';
                var roTa = baseroTa;
            }else if($(this).hasClass('wpcm-rotate-180') && noOfItems>9){
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-270';
                var roTa = parseInt(baseroTa)-270;
            }else if($(this).hasClass('wpcm-rotate-90') && noOfItems>6){
                var remCls = 'wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)-180;
            }
            else if($(this).hasClass('wpcm-rotate-0') && noOfItems>3){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-90';
                var roTa = parseInt(baseroTa)-90;
            } else{
                var remCls = 'wpcm-rotate-270';
                var remCls = 'wpcm-rotate-180';
                var remCls = 'wpcm-rotate-270 wpcm-rotate-180 wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)-90;
            }
            //alert(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '30';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '60';
            }else if(noOfItems==6 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'+'+deCr+'=');
            roTa = parseInt(roTa) + parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate('+roTa+'deg)');

        }
        else if($(this).parent().hasClass('wpcm-top-right')){
            var baseroTa = '120';
            if($(this).hasClass('wpcm-rotate-270')){
                var remCls = 'wpcm-rotate-270';
                var AdCls = 'wpcm-rotate-0';
                var roTa = baseroTa;
            }else if($(this).hasClass('wpcm-rotate-180') && noOfItems>9){
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-270';
                var roTa = parseInt(baseroTa)+270;
            }else if($(this).hasClass('wpcm-rotate-90') && noOfItems>6){
                var remCls = 'wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)+180;
            }
            else if($(this).hasClass('wpcm-rotate-0') && noOfItems>3){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-90';
                var roTa = parseInt(baseroTa)+90;
            } else{
                var remCls = 'wpcm-rotate-270';
                var remCls = 'wpcm-rotate-180';
                var remCls = 'wpcm-rotate-270 wpcm-rotate-180 wpcm-rotate-90';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)+90;
            }
            //alert(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '30';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-180')){
                var deCr = '90';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '60';
            }else if(noOfItems==6 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==5 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==4 && $(this).hasClass('wpcm-rotate-90')){
                var deCr = '90';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'-'+deCr+'=');
            roTa = parseInt(roTa) - parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate(-'+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate(-'+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate(-'+roTa+'deg)');

        }
        else if($(this).parent().hasClass('wpcm-bottom-middle')){
            var baseroTa = '-30';
            if($(this).hasClass('wpcm-rotate-0') && noOfItems>6){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)-180;
            } else{
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)-0;
            }
            //alert(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '120';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '150';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'+'+deCr+'=');
            roTa = parseInt(roTa) + parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate('+roTa+'deg)');

        }
        else if($(this).parent().hasClass('wpcm-top-middle')){
            var baseroTa = '-210';
            if($(this).hasClass('wpcm-rotate-0') && noOfItems>6){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)-180;
            } else{
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)-0;
            }
            //alert(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '120';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '150';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'+'+deCr+'=');
            roTa = parseInt(roTa) + parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate('+roTa+'deg)');

        }
        else if($(this).parent().hasClass('wpcm-middle-left')){
            var baseroTa = '60';
            if($(this).hasClass('wpcm-rotate-0') && noOfItems>6){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)-180;
            } else{
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)-0;
            }
            //alert(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '120';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '150';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'+'+deCr+'=');
            roTa = parseInt(roTa) + parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate('+roTa+'deg)');

        }
        else if($(this).parent().hasClass('wpcm-middle-right')){
            var baseroTa = '-120';
            if($(this).hasClass('wpcm-rotate-0') && noOfItems>6){
                var remCls = 'wpcm-rotate-0';
                var AdCls = 'wpcm-rotate-180';
                var roTa = parseInt(baseroTa)-180;
            } else{
                var remCls = 'wpcm-rotate-180';
                var AdCls = 'wpcm-rotate-0';
                var roTa = parseInt(baseroTa)-0;
            }
            //alert(noOfItems);
            //console.log($(this).attr('class'));
            if(noOfItems==11 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '30';
            }else if(noOfItems==10 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '60';
            }else if(noOfItems==9 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '90';
            }else if(noOfItems==8 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '120';
            }else if(noOfItems==7 && $(this).hasClass('wpcm-rotate-0')){
                var deCr = '150';
            }else{
                var deCr = '0';
            }
            //console.log(roTa+'+'+deCr+'=');
            roTa = parseInt(roTa) + parseInt(deCr);
            //console.log(roTa);

            $(this).removeClass(remCls);
            $('.wpcm-template-7').removeClass(remCls);
            $(this).addClass(AdCls);
            $('.wpcm-template-7').addClass(AdCls);

            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-webkit-transform','scale(1) rotate('+roTa+'deg)');
            $('.wpcm-circular-menu-wrapper .wpcm-template-7').css('-moz-transform','scale(1) rotate('+roTa+'deg)');

        }

    });

var winWidth = $(window).width();
var menuWidth = $('.wpcm-circular-menu-wrapper .wpcm-template-7').width();
var subWidth = parseInt(winWidth) - parseInt(menuWidth);
var halfWidth = parseInt(subWidth)/2;
$('.wpcm-top-middle .wpcm-trigger, .wpcm-bottom-middle .wpcm-trigger').css('left', halfWidth);


var winHeight = $(window).height();
var menuHeight = $('.wpcm-circular-menu-wrapper .wpcm-template-7').height();
var subHeight = parseInt(winHeight) - parseInt(menuHeight);
var halfHeight = parseInt(subHeight)/2;
$('.wpcm-middle-right .wpcm-trigger, .wpcm-middle-left .wpcm-trigger').css('top', halfHeight);

//menu animation three

$('.wpcm-circular-menu.wpcm-animation-3 .wpcm-toggle-outer-wrapper, .wpcm-circular-menu.wpcm-animation-3 .wpcm-menu').hide();
$('.wpcm-template-1.wpcm-animation-3 .wpcm-toggle-outer-wrapper, .wpcm-circular-menu.wpcm-animation-3').css('z-index', '1');
$('.wpcm-template-1.wpcm-animation-4 .wpcm-toggle-outer-wrapper, .wpcm-circular-menu.wpcm-animation-4').css('z-index', '1');
$('.wpcm-toggle-wrapper').on('click', function(){
    if($('.wpcm-circular-menu').hasClass('wpcm-menu-active')){
        $('.wpcm-circular-menu.wpcm-animation-3 .wpcm-toggle-outer-wrapper').fadeIn(500);
        $('.wpcm-circular-menu.wpcm-animation-3 .wpcm-menu').fadeIn(500);
        $('.wpcm-template-1.wpcm-animation-3 .wpcm-toggle-outer-wrapper, .wpcm-circular-menu.wpcm-animation-3').css('z-index', '999999');
        $('.wpcm-template-1.wpcm-animation-4 .wpcm-toggle-outer-wrapper, .wpcm-circular-menu.wpcm-animation-4').css('z-index', '999999');
    }else{
        $('.wpcm-circular-menu.wpcm-animation-3 .wpcm-toggle-outer-wrapper').fadeOut(500);
        $('.wpcm-circular-menu.wpcm-animation-3 .wpcm-menu').fadeOut(500);
        $('.wpcm-template-1.wpcm-animation-3 .wpcm-toggle-outer-wrapper, .wpcm-circular-menu.wpcm-animation-3').css('z-index', '1');
        $('.wpcm-template-1.wpcm-animation-4 .wpcm-toggle-outer-wrapper, .wpcm-circular-menu.wpcm-animation-4').css('z-index', '1');
    }
});

$('.wpcm-template-7 .wpcm-toggle-animation-4').wrapInner('<div class="wpcm-toggle-inner-wrapper"></div>');

});
