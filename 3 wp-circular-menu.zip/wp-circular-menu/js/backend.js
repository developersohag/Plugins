/*
 WP Circular Menu
 Version 1.0.1
 */
/* 
 Created on : August 7, 2017, 10:23:04 AM
 Author     : AccessPress Themes
 */

 jQuery(document).ready(function ($) {

    /* How to use Social pop-up close*/
    $('.wpcm-header-close').on('click',function(){
        $(this).parent('.wpcm-head-social-link').remove();
    });
    
    /*Disable Meta Box Sortable */
    $('#wpcm_menu').closest('.meta-box-sortables').sortable({
        disabled: true
    });
    $('#wpcm_menu').find('.hndle').css('cursor', 'default');


    AjaxUrl = wpcm_admin_js_obj.wpcm_ajaxurl;
    admin_nonce = wpcm_admin_js_obj.wpcm_ajax_nonce;
    delete_confirmation = wpcm_admin_js_obj.delete_confirmation;
    delete_cancelation = wpcm_admin_js_obj.delete_cancelation;
    button_name = wpcm_admin_js_obj.button_name;
    alert1 = wpcm_admin_js_obj.alert1;
    submenu_message = wpcm_admin_js_obj.submenu_message;
    max_error = wpcm_admin_js_obj.max_error;
    save_message = wpcm_admin_js_obj.save_message;

    /*Hide Load spinner*/
    $('.wpcm-spinner').removeClass('is-active');
    $('.wpcm-loader').removeClass('is-active');

    /*Nav Menu Metabox Js*/
    if ($('#wpcm_select_menu').is(':checked')) {
        if(!$('body').hasClass('wpcm-menu-active')){
            $('body').addClass('wpcm-menu-active');    
        }
    }

    $('#wpcm-disable-flat-design').on('click',function(){
        var wpcm_disable_flat_design = 0;
        if(this.checked){
            wpcm_disable_flat_design = 1;
        }
        $('.wpcm-loader').addClass('is-active');
        $.ajax({
            url: AjaxUrl,
            type: 'post',
            data: {
                action: "wpcm_disable_flat_design",
                wpcm_disable_flat_design:wpcm_disable_flat_design,
                wp_nonce: admin_nonce
            },
            success: function (response) {
                $('.wpcm-loader').removeClass('is-active');
                $('.wpcm-saved').show('slow').hide('slow');
            }
        });
    });

    $('#wpcm_select_menu').on('click',function(){
        if(this.checked){
            if(! $('body').hasClass('wpcm-menu-active')){
                $('body').addClass('wpcm-menu-active');    
            }
            var menu_id = $(this).siblings('#wpcm_current_menu_id').val();
            var menu_name = $(this).siblings('#wpcm_menu_name').val();
            var menu_slug =$(this).siblings('#wpcm_menu_slug').val();
            $('.wpcm-spinner').addClass('is-active');
            $.ajax({
                url: AjaxUrl,
                type: 'post',
                data: {
                    action: "wpcm_selected_menu",
                    menu_id: menu_id,
                    menu_name: menu_name,
                    menu_slug: menu_slug,
                    wp_nonce: admin_nonce
                },
                success: function (response) {
                    $('.wpcm-spinner').removeClass('is-active');
                }
            });
            $('.wpcm_nav_launch').fadeIn();
        }else{
            if($('body').hasClass('wpcm-menu-active')){
                $('body').removeClass('wpcm-menu-active');    
            }
            var menu_id = $(this).siblings('#wpcm_current_menu_id').val();
            var menu_name = $(this).siblings('#wpcm_menu_name').val();
            var menu_slug =$(this).siblings('#wpcm_menu_slug').val();
            $('.wpcm-spinner').addClass('is-active');
            $.ajax({
                url: AjaxUrl,
                type: 'post',
                data: {
                    action: "wpcm_unselect_menu",
                    menu_id: menu_id,
                    menu_name: menu_name,
                    menu_slug: menu_slug,
                    wp_nonce: admin_nonce
                },
                success: function (response) {
                    $('.wpcm-spinner').removeClass('is-active');
                }
            });
            $('.wpcm_nav_launch').fadeOut()
        }
    });

    /*Handle Deletion of Circular menu*/
    $('.nav-menus-php a.menu-delete').on('click',function(){
        if($('body').hasClass('wpcm-menu-active')){
            var decision = confirm(delete_confirmation);
            if(decision){
                var wpcm_menu_url = $(this).attr('href');
                $.urlParam = function(name){
                    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(wpcm_menu_url);
                    if (results==null){
                        return null;
                    }
                    else{
                        return results[1] || 0;
                    }
                }
                var menu_id = $.urlParam('menu');
                $.ajax({
                    url: AjaxUrl,
                    type: 'post',
                    data: {
                        action: "wpcm_unselect_menu",
                        menu_id: menu_id,
                        wp_nonce: admin_nonce
                    },
                    success: function (response) {
                        var response = $(response);
                        console.log(response);
                    }
                });

                $('body').removeClass('wpcm-menu-active');
            }else{
                alert(delete_cancelation);
            }
        }
    });

    /*Nav Menu Pop-up Module Js*/
    $('#menu-to-edit li.menu-item').each(function () {
        if($('body').hasClass('wpcm-menu-active')){
            var menu_item = $(this);
            var menu_id = $('input#menu').val();
            console.log('Menu ID: ' + menu_id);
            var title = menu_item.find('.menu-item-title').text();

            if (!title) {
                title = menu_item.find('.item-title').text();
            }

            var id = parseInt(menu_item.attr('id').match(/[0-9]+/)[0], 10);

            var button = $("<span>").addClass("wpcm_nav_launch").html(button_name).on('click', function () {
                if($('body').hasClass('wpcm-menu-active')){
                    var depth = menu_item.attr('class').match(/\menu-item-depth-(\d+)\b/)[1];
                    $.ajax({
                        url: AjaxUrl,
                        type: 'post',
                        data: {
                            action: "wpcm_show_lightbox_html",
                            menu_item_id: id,
                            menu_item_title: title,
                            menu_item_depth: depth,
                            menu_id: menu_id,
                            wp_nonce: admin_nonce
                        },
                        beforeSend: function () {
                            $('.wpcm_menu_wrapper #wpcm_menu_settings_frame').css('display', 'block');
                            $('.wpcm_menu_wrapper .wpcm_overlay').css('display', 'block');
                        },
                        success: function (response) {
                            var response = $(response);

                            var form = response.find('form');
                            form.on("submit", function () {
                                var wpcm_menu_item_save = $(this).serialize();
                                /*alert(wpcm_menu_item_save);*/
                                $('.wpcm-spinner.spinner').addClass('is-active');
                                $.ajax({
                                    url: AjaxUrl,
                                    type: 'post',
                                    data: {
                                        action: "wpcm_menu_item_save",
                                        menu_item_id: id,
                                        menu_item_title: title,
                                        menu_item_depth: depth,
                                        menu_id: menu_id,
                                        wpcm_menu_item_save: wpcm_menu_item_save,
                                        wp_nonce: admin_nonce
                                    },
                                    success: function (save) {
                                        $('.wpcm-spinner.spinner').removeClass('is-active');
                                        console.log(save);
                                    }
                                }
                                );
                                return false;
                            });

                            /*Add pop-up HTML*/
                            var pop_up_content = $('.wpcm_menu_wrapper .wpcm_main_content').html(response);

                            /*Show pop-up on second click*/
                            pop_up_content.closest('.wpcm_menu_wrapper').fadeIn();

                            
                            /*Initianlize Icon Picker JS*/
                            $('.icon-picker').iconPicker();

                            /*Pop-up Module close*/
                            $('.wpcm_close_btn').on('click', function () {
                                $(this).closest('.wpcm_menu_wrapper').fadeOut();
                            });

                            /*Color Picker*/
                            $('.wpcm-color-picker').wpColorPicker();

                            /*Pop-up tab js*/
                            $('.nav-menus-php').on('click', 'ul.nav-tab-wrapper li', function () {
                                var tab_id = $(this).attr('data-tab');

                                $('ul.nav-tab-wrapper li').removeClass('nav-tab-active');
                                $('.wpcm-tab-content').removeClass('wpcm-current');

                                $(this).addClass('nav-tab-active');
                                $("#" + tab_id).addClass('wpcm-current');
                            });

                            /*Pop-up Media Uploader JS*/
                            $('.custom_image_background_button').click(function (e) {
                                e.preventDefault();
                                var uploadButton = $(this);
                                var image = wp.media({
                                    title: 'Upload Image',
                                    multiple: false
                                }).open().on('select', function () {
                                    var uploaded_image = image.state().get('selection').first();
                                    console.log(uploaded_image);
                                    var image_url = uploaded_image.toJSON().url;
                                    uploadButton.siblings('.wpcm_upload_background_url').val(image_url);
                                    if (uploadButton.siblings('.wpcm_upload_background_url').val(image_url) !== '') {
                                        uploadButton.find('.current-background-image img').remove();
                                        uploadButton.find('.current-background-image').append('<img src="'+image_url+'"/>');
                                        uploadButton.find('.current-background-image').show();
                                    } else {
                                        uploadButton.find('.current-background-image').hide();
                                    }
                                });
                            });

                            /*Pop-up Media Uploader JS*/
                            $('.wpcm-meta-box-upload').click(function (e) {
                                e.preventDefault();
                                var uploadButton = $(this);
                                var image = wp.media({
                                    title: 'Upload Image',
                                    multiple: false
                                }).open().on('select', function () {
                                    var uploaded_image = image.state().get('selection').first();
                                    console.log(uploaded_image);
                                    var image_url = uploaded_image.toJSON().url;
                                    uploadButton.closest('.wpcm-popup-field').find('.wpcm-custom-image-path').attr('value',image_url);
                                    uploadButton.closest('.wpcm-popup-field').find('.wpcm-custom-image-preview').remove();
                                    uploadButton.closest('.wpcm-popup-field').append('<div class="wpcm-custom-image-preview"><img src="'+image_url+'"/></div>');
                                });
                            });

                            /*Image Select option*/
                            $('.wpcm-icon-select').on('change',function(){
                                var icon_selector = $(this); 
                                var selected_icon = $('option:selected',this).val();
                                console.log(selected_icon);
                                switch(selected_icon){
                                    case 'wpcm_none':
                                    icon_selector.closest('.wpcm-popup-field').siblings('.wpcm-popup-field').hide();
                                    break;
                                    case 'wpcm_font_icon':
                                    icon_selector.closest('.wpcm-popup-field').siblings('.wpcm-popup-field').hide();
                                    icon_selector.closest('.wpcm-popup-field').siblings('.wpcm_font_icon').show();
                                    break;
                                    case 'wpcm_custom_icon':
                                    icon_selector.closest('.wpcm-popup-field').siblings('.wpcm-popup-field').hide();
                                    icon_selector.closest('.wpcm-popup-field').siblings('.wpcm_custom_icon').show();
                                    break;
                                    case 'wpcm_bg_color':
                                    icon_selector.closest('.wpcm-popup-field').siblings('.wpcm_bg_image').hide();
                                    break;
                                    case 'wpcm_bg_image':
                                    icon_selector.closest('.wpcm-popup-field').siblings('.wpcm_bg_image').show();
                                    break;
                                }
                            });
                        }
                    });
                }else{//end of if
                    alert('Please select menu as circular menu.');
                }
            });
            $('.item-title', menu_item).append(button);//adding button
        }//end of if
    });//end of nav menu button option

/*Metabox tab js*/
$('.wpcm-postbox-wrapper').on('click', 'ul.nav-tab-wrapper li', function () {
    var tab_id = $(this).attr('data-tab');

    $('ul.nav-tab-wrapper li').removeClass('nav-tab-active');
    $('.wpcm-tab-content').removeClass('wpcm-current');

    $(this).addClass('nav-tab-active');
    $("#" + tab_id).addClass('wpcm-current');
    codeMirrorDisplay();
});

/*Custimation settings tab js*/
$('ul.wpcm-nav-tab-wrapper li').on('click enter', function () {
    var tab_id = $(this).attr('data-tab');
    console.log('reached');
    $('ul.wpcm-nav-tab-wrapper li').removeClass('wpcm-nav-tab-active');
    $('.wpcm-customizer-content').removeClass('wpcm-current').fadeOut('fast');

    $(this).addClass('wpcm-nav-tab-active');
    $("#" + tab_id).addClass('wpcm-current').fadeIn('fast');
})
.on('keypress', function(e) {
    if(e.which === 13) {
        $(this).trigger('enter');
    }
});

/*Display Settings ToggleSlide*/
$('.wpcm-toggle-tab-header').on('click',function(){
    $(this).toggleClass('wpcm-toggle-active');
    $(this).siblings('.wpcm-toggle-tab-body').slideToggle();
});

/*Code mirror activation*/
function codeMirrorDisplay() {
    var $codeMirrorEditors = $('.wpcm-codemirror-textarea');
    $codeMirrorEditors.each(function(i, el) {
        var $active_element = $(el);
        if ($active_element.data('cm')) {
            $active_element.data('cm').doc.cm.toTextArea();
        }
        var codeMirrorEditor = CodeMirror.fromTextArea(el, {
            lineNumbers: true,
            lineWrapping: true
        });
        $active_element.data('cm', codeMirrorEditor);
    });
}



/*Enable/ Disable Custom Toggle Settings*/
$('input#wpcm-enable-custom-toggle').on('change', function() {
    var checked_value = $('input#wpcm-enable-custom-toggle:checked').val();
    if(checked_value == 'on'){
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-field-wrapper').slideDown();
        codeMirrorDisplay();
    }else{
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-field-wrapper').slideUp();
    }
});

/*Enable/ Disable Custom Menu Settings*/
$('input#wpcm-enable-custom-menu').on('change', function() {
    var checked_value = $('input#wpcm-enable-custom-menu:checked').val();
    if(checked_value == 'on'){
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-field-wrapper').slideDown();
        codeMirrorDisplay();
    }else{
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-field-wrapper').slideUp();
    }
});

/*Enable/ Disable Custom Notification Label Settings*/
$('input#wpcm-enable-custom-notification').on('change', function() {
    var checked_value = $('input#wpcm-enable-custom-notification:checked').val();
    if(checked_value == 'on'){
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-notification-color').slideDown();
        codeMirrorDisplay();
    }else{
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-notification-color').slideUp();
    }
});

/*Notification Animation Preview*/
$('.wpcm-label-animation').on('change',function(){
    var selected_animation = $(this).val();
    $this = $(this);
    //wpcm-notification-preview
    $this.closest('#wpcm-customizer-3').find('.wpcm-postbox-fields-radio input[type=radio]').siblings('label').find('.wpcm-notification-preview').removeClass().addClass('wpcm-notification-preview');
    $this.closest('#wpcm-customizer-3').find('.wpcm-postbox-fields-radio input[type=radio]:checked').siblings('label').find('.wpcm-notification-preview').removeClass().addClass('wpcm-notification-preview '+selected_animation);

});

$('#wpcm-customizer-3').find('.wpcm-postbox-fields-radio input[type=radio]').on('change',function(){
    console.log('changed');
    var selected_animation = $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-field-wrapper').find('.wpcm-label-animation').val();
    $(this).closest('.wpcm-postbox-fields-radio').siblings('.wpcm-postbox-fields-radio').find('.wpcm-notification-preview').removeClass().addClass('wpcm-notification-preview');
    $(this).closest('.wpcm-postbox-fields-radio').find('.wpcm-notification-preview').removeClass().addClass('wpcm-notification-preview '+selected_animation);;
});

/*Enable/ Disable Custom Tooltip Settings*/
$('input#wpcm-enable-custom-tooltip').on('change', function() {
    var checked_value = $('input#wpcm-enable-custom-tooltip:checked').val();
    if(checked_value == 'on'){
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-field-wrapper').slideDown();
        codeMirrorDisplay();
    }else{
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-field-wrapper').slideUp();
    }
});

/*Enable/ Disable Custom Typography Settings*/
$('input#wpcm-enable-custom-typo').on('change', function() {
    var checked_value = $('input#wpcm-enable-custom-typo:checked').val();
    if(checked_value == 'on'){
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-fields').slideDown();
        codeMirrorDisplay();
    }else{
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-fields').slideUp();
    }
});

/*Enable/ Disable Custom CSS*/
$('input#wpcm-enable-custom-css').on('change', function() {
    var checked_value = $('input#wpcm-enable-custom-css:checked').val();
    if(checked_value == 'on'){
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-fields').removeClass('wpcm-css-diabled');
        codeMirrorDisplay();
    }else{
        $(this).closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-fields').addClass('wpcm-css-diabled');
    }
});

/*Toggle animation change*/
$('.wpcm-toggle-animation').on('change',function(){
    var animation_selector = $(this); 
    var selected_animation = $('option:selected',this).val();

    /*Template Preview image*/
    var image_path = wpcm_admin_js_obj.template_image_src+'/toggle-animation/'+selected_animation+'.gif';
    animation_selector.siblings('.wpcm-toggle-preview').find('img').attr('src',image_path).fadeOut().fadeIn();
});

/*Template Options*/
$('.wpcm_select_template').on('change',function(){
    var template_selector = $(this); 
    var selected_template = $('option:selected',this).val();

    /*Template Preview image*/
    var image_path = wpcm_admin_js_obj.template_image_src+'/templates/'+selected_template+'.png';
    template_selector.closest('#post-body').find('.wpcm-template-preview').find('img').attr('src',image_path);
    
    /*Show hide position option*/
    var wpcm_draggable_templates = ['wpcm-template-1','wpcm-template-2','wpcm-template-3','wpcm-template-4','wpcm-template-5'];
    
    /*console.log($.inArray(selected_template, wpcm_draggable_templates));*/
    if($.inArray(selected_template, wpcm_draggable_templates) < 0){
        /*console.log('position');*/
        template_selector.closest('.wpcm-postbox-fields').siblings('.wpcm-position-field-wrapper').show();    
        template_selector.closest('.wpcm-postbox-fields').siblings('.wpcm-initial-position-wrapper').hide();    
    }else{
        template_selector.closest('.wpcm-postbox-fields').siblings('.wpcm-position-field-wrapper').hide();    
        template_selector.closest('.wpcm-postbox-fields').siblings('.wpcm-initial-position-wrapper').show();    
    }

    /*Position mapping for template 8 and template 9*/

    if(selected_template == 'wpcm-template-8' || selected_template == 'wpcm-template-9'){
        $('.wpcm-position-fields input[type=radio]').each(function(){
            $this = $(this);
            if($this.is(':checked')) {
                var checkedPositionID = $this.attr('id');
                console.log(checkedPositionID);
                /*Mapping Template 8 position to Template 9*/
                if(selected_template == 'wpcm-template-9'){
                    switch(checkedPositionID){
                        case 'wpcm-position-2':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-3').prop("checked", true);
                        break;
                        case 'wpcm-position-4':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-1').prop("checked", true);
                        break;
                        case 'wpcm-position-6':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-9').prop("checked", true);
                        break;
                        case 'wpcm-position-8':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-7').prop("checked", true);
                        break;
                    }
                }
                /*Mapping Template 9 position to Template 8*/
                if(selected_template == 'wpcm-template-8'){
                    switch(checkedPositionID){
                        case 'wpcm-position-3':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-2').prop("checked", true);
                        break;
                        case 'wpcm-position-1':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-4').prop("checked", true);
                        break;
                        case 'wpcm-position-9':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-6').prop("checked", true);
                        break;
                        case 'wpcm-position-7':
                        $this.prop("checked", false);
                        $this.closest('.wpcm-position-field-inner-wrapper').find('#wpcm-position-8').prop("checked", true);
                        break;
                    }
                }
            }
        });
    }

    /*Disable position options*/
    switch(selected_template){
        case 'wpcm-template-8':

        $(this).closest('.wpcm-postbox-section').find('.wpcm-position-field-wrapper input[type=radio]').prop("disabled", true);
        $(this).closest('.wpcm-postbox-section').find('#wpcm-position-2, #wpcm-position-4, #wpcm-position-6, #wpcm-position-8').prop("disabled", false);
        break;
        case 'wpcm-template-9':
        $(this).closest('.wpcm-postbox-section').find('.wpcm-position-field-wrapper input[type=radio]').prop("disabled", true);
        $(this).closest('.wpcm-postbox-section').find('#wpcm-position-1, #wpcm-position-3, #wpcm-position-7, #wpcm-position-9').prop("disabled", false);
        break;
        default:
        $(this).closest('.wpcm-postbox-section').find('.wpcm-position-field-wrapper input[type=radio]').prop("disabled", false);
        $(this).closest('.wpcm-postbox-section').find('.wpcm-position-field-wrapper #wpcm-position-5').prop("disabled", true);

    }

    /*Border Option*/
    if(!(selected_template == 'wpcm-template-2' || selected_template == 'wpcm-template-3' || selected_template == 'wpcm-template-6' || selected_template == 'wpcm-template-9')){
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_menu_item_border').hide();
    }else{
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_menu_item_border').show();
    }

    /*Center Image*/
    if(!(selected_template == 'wpcm-template-1' || selected_template == 'wpcm-template-4' || selected_template == 'wpcm-template-8')){
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_center_image').hide();
    }else{
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_center_image').show();
    }

    /*Background Color*/
    if(!(selected_template == 'wpcm-template-1' || selected_template == 'wpcm-template-4' || selected_template == 'wpcm-template-8')){
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_menu_bg_color').hide();
    }else{
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_menu_bg_color').show();
    }

    /* Icon Background Color*/
    if(selected_template == 'wpcm-template-5'){
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_menu_icon_bg_color').hide();
    }else{
        template_selector.closest('.wpcm-postbox-section').find('.wpcm_menu_icon_bg_color').show();
    }


});

/*Color Picker*/
$('.wpcm-color-picker').wpColorPicker();

$('.wpcm-image-upload').click(function (e) {
    e.preventDefault();
    var uploadButton = $(this);
    var image = wp.media({
        title: 'Upload Image',
        multiple: false
    }).open().on('select', function () {
        var uploaded_image = image.state().get('selection').first();
        console.log(uploaded_image);
        var image_url = uploaded_image.toJSON().url;
        uploadButton.siblings('.wpcm-center-image').attr('value',image_url);   
    });
});

/*Typography*/
function wpcmChangeFont(element,value){
    /*Getting Selection value*/
    var font_data = value;
    if (font_data != null) {
        var SplitChars = '=';
        /*Spliting the string*/
        if (font_data.indexOf(SplitChars) >= 0) {
            var splited_font = font_data.split(SplitChars);
            var font_family  = splited_font[0];
            var font_subset  = splited_font[1];
            var font_variant  = splited_font[2];

            /*Requesting google to load font*/
            WebFont.load({
                google: {
                    families: [font_family]
                },
                timeout: 2000,
            });  

            /*Implementing changes to preview text*/
            var previewText = font_family+' '+font_subset+' '+font_variant;
            element.closest('.wpcm-customizer-content').find('.wpcm-typography-preview').html(previewText).css({
                'font-family': font_family+','+font_subset,
                'padding':'50px',
                'background-color':'#fff',
                'font-size':'32px'
            });

            /*Handling italic fonts*/
            if ( font_variant.indexOf('italic') > -1 ) {
                element.closest('.wpcm-customizer-content').find('.wpcm-typography-preview').css({
                    'font-style':'italic'
                });
            } else{
                console.log('none italic');
                element.closest('.wpcm-customizer-content').find('.wpcm-typography-preview').css({
                    'font-style':''
                });
            }

            /*Handling regular fonts*/
            if ( font_variant.indexOf('regular') > -1 ) {
                element.closest('.wpcm-customizer-content').find('.wpcm-typography-preview').css({
                    'font-weight':''
                });
            } else{
                console.log('none regular');
                element.closest('.wpcm-customizer-content').find('.wpcm-typography-preview').css({
                    'font-weight':font_variant
                });
            }

            /*Text Transform on load*/
            element.closest('.wpcm-customizer-content').find('.wpcm-typography-preview').css({
                'text-transform': element.closest('.wpcm-customizer-content').find('.wpcm-text-transform').val()
            });
        }
    }
}

/*Font change*/
$('.wpcm-typography-selected').on('change',function() {
    element = $(this);
    value = $(this).val();
    wpcmChangeFont(element,value);
});

/*Text Transform*/
$('.wpcm-text-transform').on('change',function() {
    var val = $(this).val();
    $(this).closest('.wpcm-customizer-content').find('.wpcm-typography-preview').css({
        'text-transform':val
    });
    
});

/*Font on load*/
wpcmChangeFont($('.wpcm-typography-selected'),$('.wpcm-typography-selected').val());

/*Nav menu js*/
$('.submit-add-to-menu').on('click',function(e){
    var menuItems = $('.menu li.menu-item').length;
    if($('body').hasClass('wpcm-menu-active')){
        if(menuItems > 11){
            e.preventDefault();
            e.stopPropagation();
            alert(alert1);
            return false; 
        }
    }
});



var menuItems = $('.menu li.menu-item').length;
if($('body').hasClass('wpcm-menu-active')){
    $('#menu-instructions').before('<div class="wpcm-notice"><ul><li>'+submenu_message+'</li><li>'+save_message+'</li></ul></div>');
    if(menuItems > 11){
        $('#menu-instructions').before('<div class="wpcm-notice">'+max_error+'<span class="wpcm-close-notice notice-dismiss"></span></div>');
        
    }
}



$('body.wpcm-menu-active').on('click', '.wpcm-close-notice', function(event) {
    $(this).closest('.wpcm-notice').fadeOut();
});

/*Permission Settings JS*/
/*Show/ Hide User roles*/
$('.wpcm_permission').on('change',function(){
    var permission_selector = $(this); 
    var selected_permission = $('option:selected',this).val();
    console.log(selected_permission);
    if(selected_permission == 'wpcm_loggedin'){
        permission_selector.closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-fields.wpcm-user-roles').show();
    }else{
        permission_selector.closest('.wpcm-postbox-fields').siblings('.wpcm-postbox-fields.wpcm-user-roles').hide();
    }
});

/*Show/ Hide Single Page Options*/
$('input#wpcm_single_pages').on('change', function() {
    var checked_value = $('input#wpcm_single_pages:checked').val();
    if(checked_value == 'on'){
        $(this).closest('.wpcm-postbox-section').find('.wpcm-hide-singular').fadeOut();
    }else{
        $(this).closest('.wpcm-postbox-section').find('.wpcm-hide-singular').fadeIn();
    }
});

/*Shortcode Click Copy to Clipboard*/
$('.wpcm-copy-to-clipboard input').on('click',function() {
    $(this).focus();
    $(this).select();
    document.execCommand('copy');
    $(this).after('<span class="wpcm-copied">Copied</span>')
    $(this).siblings('.wpcm-copied').hide('slow');
});


});

