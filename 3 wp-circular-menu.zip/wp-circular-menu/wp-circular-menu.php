<?php

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
/*
  Plugin Name: WP Circular Menu - Responsive Circular Menu Plugin for WordPress
  Plugin URI:  https://accesspressthemes.com/wordpress-plugins/wp-circular-menu/ ‎
  Description: WP Circular menu is a premium circular structure menu for easy and quick navigation within your site.
  Version:     1.0.0
  Author:      AccessPress Themes
  Author URI:  https://accesspressthemes.com
  License:     GPL2 or later
  Domain Path: /languages/
  Text Domain: wp-circular-menu
 */

  /* Created on 8/7/2017 */

  if ( !class_exists( 'WpCircularMenu' ) ) {
    /* Create WpCircularMenu Class */

    class WpCircularMenu {

      function __construct() {
        /* Define file paths */
        $this->define_constants();
        add_action( 'init', array( $this, 'wpcm_init' ) );
        register_activation_hook( __FILE__, array( $this, 'wpcm_load_defaults'));

        /*Support Link*/
        add_filter( 'plugin_action_links', array( $this, 'wpcm_plugin_action_link' ), 10, 5 );

        /* Enqueue Scripts and style */
        add_action( 'admin_enqueue_scripts', array( $this, 'wpcm_backend_assets' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'wpcm_frontend_assets' ) );

        /*Register post Types*/
        add_action( 'init', array( $this, 'wpcm_register_post_type' ) );
        add_action( 'init', array( $this, 'wpcm_fonts_array' ) );
        
        /*Metabox hooks for WP Circular Menu CPT*/
        add_action( 'add_meta_boxes', array( $this, 'wpcm_add_metabox' ) );
        add_action( 'save_post', array( $this, 'wpcm_save_settings' ) );

        /*Add preview meta*/
        add_action( 'add_meta_boxes', array( $this, 'wpcm_add_preview_metabox' ) );

        /*Shortcode*/
        add_action( 'add_meta_boxes', array( $this, 'wpcm_shortcode_info' ) );        

        /*Register Admin Menu items to Custom post type*/
        add_action( 'admin_menu', array( $this, 'wpcm_sub_menu_extra' ) );
        add_action( 'admin_menu', array( $this, 'wpcm_sub_menu_how_to' ) );
        add_action( 'admin_menu', array( $this, 'wpcm_sub_menu_about' ) );


        /*Metabox hooks for nav-menu.php*/
        add_action( 'load-nav-menus.php', array( $this, 'wpcm_register_menu_meta_box' ) );

        /*Metabox select menu as wpcm-menu*/
        add_action( 'wp_ajax_wpcm_selected_menu', array( $this, 'wpcm_select_menued' ) );
        add_action( 'wp_ajax_wpcm_unselect_menu', array( $this, 'wpcm_unselect_menu' ) );

        add_action( 'wp_ajax_wpcm_disable_flat_design', array( $this, 'wpcm_disable_flat_design' ) );

        /*Load pop-up module in nav-menu.php*/
        add_action( 'admin_footer', array( $this, 'wpcm_admin_footer_function' ) );
        add_action( 'wp_ajax_wpcm_show_lightbox_html', array( $this, 'wpcm_lightbox_content' ) );
        add_action( 'wp_ajax_wpcm_menu_item_save', array( $this, 'wpcm_menu_item_save' ) );

        /*Load menu to frontend header*/
        add_action( 'wp_head', array( $this, 'wpcm_circular_menu' ) );

        add_action( "load-edit.php",array( $this, 'wpcm_help_tabs' )  );
        add_action( "load-post-new.php", array( $this, 'wpcm_help_tabs' ) );
        add_action( "load-post.php", array( $this, 'wpcm_help_tabs' ) );

        /*Shortcode*/
        add_shortcode( 'circular_menu', array( $this, 'circular_menu_shortcode' ) );
      }
      
      /* Define Text Domain */
      function wpcm_init() {
        load_plugin_textdomain( 'wp-circular-menu', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
      }

      /*Load defaults*/
      function wpcm_load_defaults(){
        $wpcm_disable_flat_design = get_option( 'wpcm_disable_flat_design');
        $wpcm_disable_flat_design = !empty($wpcm_disable_flat_design)? $wpcm_disable_flat_design : 0;
        update_option( 'wpcm_disable_flat_design', $wpcm_disable_flat_design );
      }

     /*Add Contextual Help*/
     function wpcm_help_tabs() {

      $screen = get_current_screen();
      $screen_ids = array('wpcm_menu','edit-wpcm_menu' );

      if ( ! in_array( $screen->id, $screen_ids ) ) {
        return;
      }

      $screen->add_help_tab(
        array(
          'id'      => 'wpcm_overview',
          'title'   => 'Overview',
          'content' => '<p><strong>WP Circular menu</strong> is a premium circular structure menu for easy and quick navigation within your site.</p><p><strong>WP Circular menu</strong> makes use of the default WordPress menu function to create menus. You can add upto 12 menu items and can include additional elements to the default menu items such as Menu Icons and Tooltip.</p><p>To create a circular menu, click <a href="'.admin_url().'nav-menus.php" target="_blank">here.</a>'
        )
      );

      /*Add a sidebar to contextual help.*/
      $screen->set_help_sidebar( '<p><strong>For more information:</strong></p><p><a href="https://accesspressthemes.com/documentation/wp-circular-menu/" target="_blank">Documentation</a></p><p><a href="https://codecanyon.net/user/accesskeys#contact" target="_blank">Support</a></p>' );
    }

    /*Support link*/
    function wpcm_plugin_action_link( $actions, $plugin_file ) {
      static $plugin;
      if ( !isset( $plugin ) )
        $plugin = plugin_basename( __FILE__ );
      if ( $plugin == $plugin_file ) {
        $settings = array( 'settings' => '<a href="edit.php?post_type=wpcm_menu">' . __( 'Settings', 'wp-circular-menu' ) . '</a>' );
        $site_link = array( 'support' => '<a href="https://codecanyon.net/user/accesskeys#contact" target="_blank">' . __( 'Support', 'wp-circular-menu' ) . '</a>' );
        $actions = array_merge( $settings, $actions );
        $actions = array_merge( $site_link, $actions );
      }
      return $actions;
    }

    /* Custom Utility Print Function */

    function print_array( $array ) {
     echo "<pre>";
     print_r( $array );
     echo "</pre>";
   }

   /* Define Constants */

   function define_constants() {
     defined( 'WPCM_CSS_DIR' ) or define( 'WPCM_CSS_DIR', plugin_dir_url( __FILE__ ) . 'css' );
     defined( 'WPCM_JS_DIR' ) or define( 'WPCM_JS_DIR', plugin_dir_url( __FILE__ ) . 'js' );
     defined( 'WPCM_IMG_DIR' ) or define( 'WPCM_IMG_DIR', plugin_dir_url( __FILE__ ) . 'images' );
     defined( 'WPCM_PATH' ) or define( 'WPCM_PATH', plugin_dir_path( __FILE__ ) );
     defined( 'WPCM_VERSION' ) or define( 'WPCM_VERSION', '1.0.9' );
   }

   function wpcm_backend_assets() {

     /* Enqueue Font icons */
     wp_enqueue_style( 'wpcm-font-awesome-style', WPCM_CSS_DIR . '/font-awesome.min.css', array(), WPCM_VERSION );
     wp_enqueue_style( 'wpcm-icon-picker-genericons-css', WPCM_CSS_DIR . '/genericons.css', WPCM_VERSION );
     wp_enqueue_style( 'wpcm-icon-picker-css', WPCM_CSS_DIR . '/icon-picker.css', WPCM_VERSION );
     wp_enqueue_script( 'wpcm-linearicons', 'https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js' );
     wp_enqueue_style( 'wpcm-linearicons-css', 'https://cdn.linearicons.com/free/1.0.0/icon-font.min.css' );
       //wp_enqueue_style( 'wpcm-materialdesign', '//cdn.materialdesignicons.com/1.9.32/css/materialdesignicons.min.css' );
     wp_enqueue_style( 'wpcm-themify-css', WPCM_CSS_DIR . '/themify-icons.css', WPCM_VERSION );


     /* Enqueue codemirror css for Custom CSS editor */
     wp_enqueue_style( 'wpcm-codemirror-css', WPCM_CSS_DIR . '/codemirror.css', array(), WPCM_VERSION );

     /* Enqueue backend.css */
     wp_enqueue_style( 'wpcm-backend-style', WPCM_CSS_DIR . '/backend.css', array(), WPCM_VERSION );

     /* Enqueue media for custom image upload */
     wp_enqueue_media();

     /* For color picker */
     wp_enqueue_style( 'wp-color-picker' );
     wp_enqueue_script( 'wpcm-color-picker-js', WPCM_JS_DIR . '/wp-color-picker-alpha.js', array( 'jquery', 'wp-color-picker' ), WPCM_VERSION );

     /* For dynamic font change in backend preview */
     wp_enqueue_script( 'wpcm-webfont', '//ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js' );

     /* For Custom CSS editor */
     wp_enqueue_script( 'wpcm-codemirror-js', WPCM_JS_DIR . '/codemirror.js', array( 'jquery' ), WPCM_VERSION );
     wp_enqueue_script( 'wpcm-codemirror-css-js', WPCM_JS_DIR . '/css.js', array( 'jquery', 'wpcm-codemirror-js' ), WPCM_VERSION );

     /* For default icon picker */
     wp_enqueue_script( 'wpcm-icon-picker-script', WPCM_JS_DIR . '/icon-picker.js', array( 'jquery'), WPCM_VERSION );

     /* Enqueue backend.js */
     wp_enqueue_script( 'wpcm-backend-script', WPCM_JS_DIR . '/backend.js', array( 'jquery','wp-color-picker','wpcm-icon-picker-script','wpcm-codemirror-js','jquery-ui-sortable'), WPCM_VERSION );

     /*Send php values to JS script*/
     wp_localize_script( 'wpcm-backend-script', 'wpcm_admin_js_obj', array(
      'template_image_src' => WPCM_IMG_DIR,
      'delete_confirmation' => __('Are you sure you want to remove Menu from Circular Menu List?','wp-circular-menu'),
      'delete_cancelation'=>__('Good Choice!','wp-circular-menu'),
      'button_name'=> __('WP Circular Menu','wp-circular-menu'),
      'alert1'=>__('WP Circular menu can support only upto 12 elements','wp-circular-menu'),
      'submenu_message'=>__('WP Circular Menu does not support sub-menus','wp-circular-menu'),
      'save_message'=>__('Click save after adding new menu items to get circular menu options for that item.','wp-circular-menu'),
      'max_error'=>__('Max reached, WP Circular menu can support only upto 12 elements. Template 9 supports only 8 items the last 4 items will be dropped.','wp-circular-menu'),
      'wpcm_ajaxurl' => admin_url( 'admin-ajax.php' ),
      'wpcm_ajax_nonce' => wp_create_nonce( 'wpcm-ajax-nonce' )
      ) );

   }

   function wpcm_frontend_assets() {

     /* Enqueue frontend.css */
     wp_enqueue_style( 'wpcm-frontend-style', WPCM_CSS_DIR . '/frontend.css', array(), WPCM_VERSION );

     $wpcm_disable_flat_design = get_option( 'wpcm_disable_flat_design');
     $wpcm_disable_flat_design = !empty($wpcm_disable_flat_design)? $wpcm_disable_flat_design : 0;
     if(!$wpcm_disable_flat_design){
      wp_enqueue_style( 'wpcm-responsive-style', WPCM_CSS_DIR . '/wpcm-responsive.css', array(), WPCM_VERSION);
     }
     /* Enqueue fonts and icons */
     wp_enqueue_style( 'wpcm-icon-picker-genericons-css', WPCM_CSS_DIR . '/genericons.css', WPCM_VERSION );
     wp_enqueue_style( 'dashicons' );
     wp_enqueue_style( 'wpcm-font-awesome-style', WPCM_CSS_DIR . '/font-awesome.min.css', array(), WPCM_VERSION );
     wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Amatic+SC|Merriweather|Roboto+Slab|Montserrat:400,700|Lato|Italianno|PT+Sans|PT+Sans+Narrow|Raleway:400,500,600,800|Roboto:300,400,500,700|Open+Sans|Great+Vibes|Varela+Round|Roboto+Condensed|Fira+Sans|Lora|Signika|Cabin|Arimo|Droid+Serif|Arvo|Rubik' );
     wp_enqueue_style( 'wpcm-themify-css', WPCM_CSS_DIR . '/themify-icons.css', WPCM_VERSION );
     wp_enqueue_script( 'wpcm-linearicons', 'https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js' );
     wp_enqueue_style( 'wpcm-linearicons-css', 'https://cdn.linearicons.com/free/1.0.0/icon-font.min.css' );
       //wp_enqueue_style( 'wpcm-materialdesign', '//cdn.materialdesignicons.com/1.9.32/css/materialdesignicons.min.css' );

     /* Enqueue frontend.js */
     /*wp_enqueue_script( 'wpcm-interact', 'https://cdnjs.cloudflare.com/ajax/libs/interact.js/1.2.8/interact.min.js' );*/
     wp_enqueue_script( 'wpcm-jquery-pep', WPCM_JS_DIR . '/jquery.pep.js',array( 'jquery'));
     
     /*wp_enqueue_script( 'wpcm-touch-punch', WPCM_JS_DIR . '/jquery.ui.touch-punch.js', array( 'wpcm-frontend-script'),  '0.2.3' );*/

     /*Running loop foreach Circular menu and sending required setting from php to js*/
     $query = new WP_Query( array('post_type' => 'wpcm_menu', 'posts_per_page' => -1 )); 


     $wpcm_settings_js = array();

     if ( $query->have_posts() ) : 
      wp_enqueue_script( 'wpcm-frontend-script', WPCM_JS_DIR . '/frontend.js', array( 'jquery','wpcm-jquery-pep'), WPCM_VERSION );
      while ( $query->have_posts() ) : 
        $query->the_post(); 
        $postid = get_the_ID();           
        $wpcm_settings = get_post_meta($postid,'_wpcm_settings'); 
        if(!empty($wpcm_settings)){
          $wpcm_initial_top = isset( $wpcm_settings[0]['wpcm_initial_top'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_initial_top'] ) : '';
          $wpcm_initial_left = isset( $wpcm_settings[0]['wpcm_initial_left'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_initial_left'] ) : '';
          $wpcm_menu_fixed = isset( $wpcm_settings[0]['wpcm_menu_fixed'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_menu_fixed'] ) : 0;
          $wpcm_disable_draggable = isset( $wpcm_settings[0]['wpcm_disable_draggable'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_disable_draggable'] ) : 0;
          $wpcm_select_template = isset( $wpcm_settings[0]['wpcm_select_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_template'] ) : 'wpcm-template-1';
          $wpcm_settings_js[$postid] = array(
            'wpcm_postid'=>$postid,
            'wpcm_select_template'=>$wpcm_select_template,
            'wpcm_initial_top' => $wpcm_initial_top,
            'wpcm_initial_left'=>$wpcm_initial_left,
            'wpcm_disable_draggable'=>$wpcm_disable_draggable,
            'wpcm_menu_fixed'=>$wpcm_menu_fixed

          );
        }
      endwhile; 

      $wpcm_json_str = json_encode($wpcm_settings_js);

      wp_localize_script( 'wpcm-frontend-script', 'wpcm_settings', array(
        'wpcm_arr' => $wpcm_json_str
      ));

      wp_reset_postdata();
    endif;
  }

  /* Backend Extra Option*/
  function wpcm_sub_menu_extra(){
    add_submenu_page(
      'edit.php?post_type=wpcm_menu', __( 'Extra', 'wp-circular-menu' ), __( 'Extra', 'wp-circular-menu' ), 'manage_options', 'wpcm-extra', array( $this, 'wpcm_extra' )
    );
  }
  function wpcm_extra() {
    include(WPCM_PATH . '/inc/backend/boards/wpcm-extra.php');
  }

  /* Backend How to use Page */
  function wpcm_sub_menu_how_to() {
    add_submenu_page(
      'edit.php?post_type=wpcm_menu', __( 'How to use', 'wp-circular-menu' ), __( 'How to use', 'wp-circular-menu' ), 'manage_options', 'wpcm-how-to', array( $this, 'wpcm_how_to' )
    );
  }



  /* WP Circular Menu - How to callback function */
  function wpcm_how_to() {
    include(WPCM_PATH . '/inc/backend/boards/wpcm-how-to.php');
  }

  /* Backend About Page */
  function wpcm_sub_menu_about() {
    add_submenu_page(
      'edit.php?post_type=wpcm_menu', __( 'About', 'wp-circular-menu' ), __( 'About', 'wp-circular-menu' ), 'manage_options', 'wpcm-about', array( $this, 'wpcm_about' )
    );
  }

  /* WP Circular Menu - About page callback function */
  function wpcm_about() {
    include(WPCM_PATH . '/inc/backend/boards/wpcm-about.php');
  }

  /*Register Custom Post Type*/
  function wpcm_register_post_type() {
   include(WPCM_PATH . 'inc/backend/custom-post-type/wpcm-custom-post-type.php');
 }

 /*Meta Box For Custom Post Type*/
 function wpcm_add_metabox() {
   add_meta_box( 'wpcm_menu', __( 'WP Circular Menu Settings', 'wp-circular-menu' ), array( $this, 'wpcm_meta_callback' ), 'wpcm_menu', 'normal', 'core' );
 }

 /*Meta Box Callback Function*/
 function wpcm_meta_callback( $post ) {
   include(WPCM_PATH . 'inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-box.php');
 }

 /* WP Circular Menu - Save Meta values */
 function wpcm_save_settings($post_id){
  include(WPCM_PATH . 'inc/backend/custom-post-type/wpcm-meta-box/wpcm-meta-saves/wpcm-meta-saves.php');
}

/*Meta box for preview*/
function wpcm_add_preview_metabox(){
  add_meta_box( 'wpcm_menu_preview', __( 'Preview', 'wp-circular-menu' ), array( $this, 'wpcm_meta_preview_callback' ), 'wpcm_menu', 'side', 'default' );
}

/*Meta Box Callback Function for preview*/
function wpcm_meta_preview_callback( $post ) {
  $wpcm_settings = get_post_meta($post->ID,'_wpcm_settings');
  $wpcm_select_template = isset( $wpcm_settings[0]['wpcm_select_template'] ) ? sanitize_text_field( $wpcm_settings[0]['wpcm_select_template'] ) : 'wpcm-template-1';
  ?>
  <div class="wpcm-template-preview">
    <img src="<?php esc_attr_e(WPCM_IMG_DIR.'/templates/'.$wpcm_select_template.'.png');?>"/>
  </div>
  <?php
}

/*wpcm_shortcode_info*/
function wpcm_shortcode_info(){
  add_meta_box( 'wpcm_shortcode_info', __( 'Shortcode Information', 'wp-circular-menu' ), array( $this, 'wpcm_shortcode_info_callback' ), 'wpcm_menu', 'side', 'default' );
}

function wpcm_shortcode_info_callback($post){
  $post_id = $post->ID;
  ?>
  <p>Use the shortcode for Draggable templates</p><div class="wpcm-copy-to-clipboard"><input readonly type="text" value="<?php _e('[circular_menu id=&quot;'.$post_id.'&quot;]');?>"></div><p>in any page or post.</p>
  <?php
  
}

/* Creating Meta box for nav-menu.php */

function wpcm_register_menu_meta_box() {
 add_meta_box(
  'wpcm-menu-meta-box-id', esc_html__( 'WP Circular Menu', 'wp-circular-menu' ), array( $this, 'wpcm_render_menu_meta_box' ), 'nav-menus', 'side', 'high'
);
}

/* WP Circular Menu - Nav.php Mets Box */
function wpcm_render_menu_meta_box() {
 $nav_menus = wp_get_nav_menus();
 if(!empty($nav_menus)){
  $wpcm_current_menu_id = $this->wpcm_current_menu_id();
  $menu_object = wp_get_nav_menu_object( $wpcm_current_menu_id );
  $menu_name = !empty( $menu_object ) ? $menu_object->name : '';
  $menu_slug = !empty( $menu_object ) ? $menu_object->slug : '';
  $wpcm_selected_menu = get_option('wpcm_selected_menu');
  if(!empty($wpcm_selected_menu)){
   $wpcm_selected_menu = get_option('wpcm_selected_menu'); 
 }else{
   $wpcm_selected_menu = array();
 }

 /*$this->print_array($wpcm_selected_menu);*/
 ?>
 <input type="hidden" id="wpcm_current_menu_id" value="<?php esc_attr_e($wpcm_current_menu_id);?>"/>
 <input type="hidden" id="wpcm_menu_name" value="<?php esc_attr_e($menu_name);?>"/>
 <input type="hidden" id="wpcm_menu_slug" value="<?php esc_attr_e($menu_slug);?>"/>

 <input type="checkbox" id="wpcm_select_menu" <?php if(in_array($wpcm_current_menu_id, $wpcm_selected_menu)) _e('checked');?>/>
 <label for="wpcm_select_menu"><?php _e( 'Use as circular menu?'); ?><span class="spinner is-active wpcm-spinner"></span></label>
 <p class="wpcm-menu-meta"><?php _e('Please check here to make ', 'wp-circular-menu' ); ?><strong><?php _e( $menu_name ); ?></strong><?php _e( ' work as WP Circular Menu.');?></p>
 <div class="wpcm-meta-info"><i class="fa fa-info-circle"></i><p><?php _e('Checking this will will enable you to configure circular menu item settings.')?></p></div>
 <?php
}else{
  _e( 'No Menu Created.', 'wp-circular-menu' );
}
}

/*Get current menu id for nav-menu.php metabox.*/
function wpcm_current_menu_id() {
 /*Get List of registered menus*/
 $nav_menus = wp_get_nav_menus( array( 'orderby' => 'name' ) );

 /*Count numbr of Menus*/
 $menu_count = count( $nav_menus );

 $wpcmSelectedID = isset( $_REQUEST['menu'] ) ? (int) $_REQUEST['menu'] : 0;

 $wpcmAddNewScreen = ( isset( $_GET['menu'] ) && 0 == $_GET['menu'] ) ? true : false;
 $page_count = wp_count_posts( 'page' );
 $one_theme_location_no_menus = ( 1 == count( get_registered_nav_menus() ) && !$wpcmAddNewScreen && empty( $nav_menus ) && !empty( $page_count->publish ) ) ? true : false;

 /* Get recently edited nav menu*/
 $recently_edited = absint( get_user_option( 'nav_menu_recently_edited' ) );

 if ( empty( $recently_edited ) && is_nav_menu( $wpcmSelectedID ) ) {
  $recently_edited = $wpcmSelectedID;
}

/* Use $recently_edited if none are selected*/
if ( empty( $wpcmSelectedID ) && !isset( $_GET['menu'] ) && is_nav_menu( $recently_edited ) ) {
  $wpcmSelectedID = $recently_edited;
}

/* On deletion of menu, if another menu exists, show it*/
if ( !$wpcmAddNewScreen && 0 < $menu_count && isset( $_GET['action'] ) && 'delete' == $_GET['action'] ) {
  $wpcmSelectedID = $nav_menus[0]->term_id;
}

/* Set $wpcmSelectedID to 0 if no menus*/
if ( $one_theme_location_no_menus ) {
  $wpcmSelectedID = 0;
} elseif ( empty( $wpcmSelectedID ) && !empty( $nav_menus ) && !$wpcmAddNewScreen ) {
  /* if we have no selection yet, and we have menus, set to the first one in the list*/
  $wpcmSelectedID = $nav_menus[0]->term_id;
}

return $wpcmSelectedID;
}

/* WP Circular Menu - Set Menu as Circular Menu */
function wpcm_select_menued(){
  /*Check nonce*/
  if ( check_ajax_referer( 'wpcm-ajax-nonce', 'wp_nonce' ) ) {
    /*Check if id is empty*/
    if( ! empty($_POST['menu_id'])){
      /*Check previous value in option table*/
      $wpcm_selected_menu = get_option('wpcm_selected_menu');
      /*If not empty push new value*/
      if(! empty($wpcm_selected_menu)){
        $wpcm_selected_menu_id = sanitize_text_field($_POST['menu_id']);
        $wpcm_selected_menu[] = $wpcm_selected_menu_id;
      }else{
        $wpcm_selected_menu[] = $_POST['menu_id'];
      }
      update_option('wpcm_selected_menu', $wpcm_selected_menu);
      wp_send_json_success();
    }
  }else {
    die( 'No script kiddies please!' );
  }
  wp_die();
}

/* WP Circular Menu - Unset Menu as Circular Menu */
function wpcm_unselect_menu(){
  /*Check nonce*/
  if ( check_ajax_referer( 'wpcm-ajax-nonce', 'wp_nonce' ) ) {
    /*Check if id is empty*/
    if( ! empty($_POST['menu_id'])){

      /*Save parameter*/
      $wpcm_selected_menu_id = $_POST['menu_id'];
      
      /*Get reference from option table*/
      $wpcm_selected_menu = get_option('wpcm_selected_menu');
      
      /*Get menu object*/
      $nav_menus = wp_get_nav_menus();

      /*Set empty array*/
      $all_nav_menu =array();

      /*Extract menu ID from menu object*/
      if(!empty($nav_menus)){
        foreach($nav_menus as $nav_menu){
          $all_nav_menu[] = $nav_menu->term_id;
        }
      }

      /*
      foreach($wpcm_selected_menu as $junk_id => $junk_value){
        
        if(!in_array($junk_id,$all_nav_menu)){
          $pos = array_search($junk_value, $wpcm_selected_menu);
          unset($wpcm_selected_menu[$pos]);
        }
      }*/

      if(in_array($wpcm_selected_menu_id,$wpcm_selected_menu)){
        $pos = array_search($wpcm_selected_menu_id, $wpcm_selected_menu);
        unset($wpcm_selected_menu[$pos]);
      }

      update_option('wpcm_selected_menu', $wpcm_selected_menu);
      wp_send_json_success();
    }
  }else {
    die( 'No script kiddies please!' );
  }
  wp_die();
}

/*nav-menu.php footer*/
function wpcm_admin_footer_function() {
 echo "<div class='wpcm_menu_wrapper'><div class='wpcm_overlay'></div>";
 echo "<div id='wpcm_menu_settings_frame' style='display:none;'><div class='wpcm_frame_header'>";
 echo "<button type='button' class='media-modal-close'><span class='media-modal-icon wpcm_close_btn'><span class='screen-reader-text'>Close menu panel</span></span></div>";
 echo "<div class='wpcm_main_content'></div></div></div>";
}

/*nav-menu.php footer ajax pop-up response*/
function wpcm_lightbox_content() {
 if ( check_ajax_referer( 'wpcm-ajax-nonce', 'wp_nonce' ) ) {
  include(WPCM_PATH . 'inc/backend/nav-menu-settings/wpcm-nav-menu-popup-settings.php');
}
wp_die();
}

/*Ajax menu item settings save.*/
function wpcm_menu_item_save() {
 if ( check_ajax_referer( 'wpcm-ajax-nonce', 'wp_nonce' ) ) {
  $wpcm_menu_item_id = absint( $_POST['menu_item_id'] );
  if ( isset( $_POST['wpcm_menu_item_save'] ) && !empty( $_POST['wpcm_menu_item_save'] ) ) {
   $wpcm_menu_item_settings = array();
   parse_str( $_POST['wpcm_menu_item_save'], $wpcm_menu_item_settings );

   /*Menu Name tab*/
   $wpcm_menu_item_settings['wpcm_popup_show_title'] = isset( $wpcm_menu_item_settings['wpcm_popup_show_title'] ) ? 1 : 0;
   $wpcm_menu_item_settings['wpcm_tooltip_text'] = isset( $wpcm_menu_item_settings['wpcm_tooltip_text'] ) ? sanitize_text_field( $wpcm_menu_item_settings['wpcm_tooltip_text'] ) : '';
   
   /*Icon Menu*/
   $wpcm_menu_item_settings['wpcm_icon_type'] = isset( $wpcm_menu_item_settings['wpcm_icon_type'] ) ? sanitize_text_field( $wpcm_menu_item_settings['wpcm_icon_type'] ) : 'wpcm_none';
   $wpcm_menu_item_settings['wpcm_font_icon'] = isset( $wpcm_menu_item_settings['wpcm_font_icon'] ) ? sanitize_text_field( $wpcm_menu_item_settings['wpcm_font_icon'] ) : '';
   $wpcm_menu_item_settings['wpcm_custom_icon'] = isset( $wpcm_menu_item_settings['wpcm_custom_icon'] ) ? sanitize_text_field( $wpcm_menu_item_settings['wpcm_custom_icon'] ) : '';
   
   /*Background color*/
   $wpcm_menu_item_settings['wpcm_bg_image'] = isset( $wpcm_menu_item_settings['wpcm_bg_image'] ) ? sanitize_text_field( $wpcm_menu_item_settings['wpcm_bg_image'] ) : '';

   /*Notification Label*/
   $wpcm_menu_item_settings['wpcm_notification_text'] = isset( $wpcm_menu_item_settings['wpcm_notification_text'] ) ? sanitize_text_field( $wpcm_menu_item_settings['wpcm_notification_text'] ) : '';
   
   $get_existing_settings = get_post_meta( $wpcm_menu_item_id, '_wpcmItemSettings', true );
   if ( is_array( $get_existing_settings ) ) {
    $wpcm_menu_item_settings = array_merge( $get_existing_settings, $wpcm_menu_item_settings );
  }
  update_post_meta( $wpcm_menu_item_id, '_wpcmItemSettings', $wpcm_menu_item_settings );
  wp_send_json_success();
}
} else {
  die( 'No script kiddies please!' );
}
wp_die();
}

/* Load Menu on Header */
function wpcm_circular_menu() {
  include(WPCM_PATH . '/inc/frontend/wpcm-circular-menu.php');
}

/*Disable resposive ajax callback*/
function wpcm_disable_flat_design(){
  if ( check_ajax_referer( 'wpcm-ajax-nonce', 'wp_nonce' ) ) {
    $wpcm_disable_flat_design = isset($_POST['wpcm_disable_flat_design'])?sanitize_text_field($_POST['wpcm_disable_flat_design']):0;
    echo $wpcm_disable_flat_design;
    update_option( 'wpcm_disable_flat_design', $wpcm_disable_flat_design );
  }
  wp_die();
}

function circular_menu_shortcode($attr){
  ob_start();
  include(WPCM_PATH . '/inc/frontend/wpcm-shortcode.php');
  $wpcm_menu_shortcode = ob_get_contents();
  ob_end_clean();
  return $wpcm_menu_shortcode;
}

/*Get font list from google fonts */
function wpcm_fonts_array(){
  include(WPCM_PATH . '/inc/backend/google-font/wpcm-google-fonts.php');
}

    /* Get all editable roles */

    function get_editable_roles() {
      global $wp_roles;
      $all_roles = $wp_roles->roles;
      return $all_roles;
    }




    } //End of class WpCircularMenu

    /* Create WpCircularMenu Object */
    $wp_circular_menu_obj = new WpCircularMenu();
  }

